/* ═══════════════ PLUS (ধাপ ২): সংরক্ষণ (টাইপভিত্তিক) · মনে রাখার ট্রিকস · রঙিন হাইলাইট · নতুন থিম · ছোট উদযাপন
   app.js এর BOOT() ক্লোজারের ভিতরে plus.js এর পরে বসে — S, VIEWS, ACT, render, LMAP, SMAP, MCQ ইত্যাদি সরাসরি পাওয়া যায়। ═══════════════ */

/* ---------- একবার: গ্লাস অরোরা ডিফল্ট ---------- */
if ((S.thv || 0) < 2) { S.theme = 'glass'; S.thv = 2; try { save({ cloud: false }); } catch (e) { } try { applyTheme(); } catch (e) { } }

/* ---------- সংরক্ষণ (★) ---------- */
const SV = () => S.sv || (S.sv = {}), TK = () => S.trk || (S.trk = {});
const SVT = [['m', 'MCQ', 'q'], ['c', 'সৃজনশীল', 'pen'], ['v', 'চিত্র', 'atom'], ['f', 'ফ্ল্যাশকার্ড', 'cards'], ['x', 'সূত্র', 'sigma'], ['t', 'ট্রিকস', 'bulb']];
const svKey = (ty, ref) => ty + ':' + ref;
const svOn = (ty, ref) => !!SV()[svKey(ty, ref)];
function svBtn(ty, ref, label) {
  const on = svOn(ty, ref);
  return `<button type="button" class="sv-btn ${on ? 'on' : ''}" data-act="sv" data-ty="${ty}" data-ref="${esc(ref)}" aria-pressed="${on}" title="${on ? 'সংরক্ষিত — সরাতে চাপো' : 'সংরক্ষণ করো'}">${ico(on ? 'bmf' : 'bm')}${label ? `<span>${on ? 'সংরক্ষিত' : label}</span>` : ''}</button>`;
}
let VCH = null;
function svCh(ty, ref) {
  if (ty === 'm') return MCQ[ref] && SMAP[MCQ[ref].sid] ? SMAP[MCQ[ref].sid].ch : null;
  if (ty === 'c' || ty === 'x') { const s = SMAP[ref.split('#')[0]]; return s ? s.ch : null; }
  if (ty === 'f') { const s = SMAP[ref.replace(/f\d+$/, '')]; return s ? s.ch : null; }
  if (ty === 't') { if (LMAP[ref]) return LMAP[ref].ch; return ref.split('#')[0]; }
  if (ty === 'v') { if (!VCH) { VCH = {}; CHAPTERS.forEach(c => figList(c).forEach(f => { VCH[f.k] = c.id; })); } return VCH[ref] || null; }
  return null;
}
ACT.sv = b => {
  const k = svKey(b.dataset.ty, b.dataset.ref), on = !SV()[k];
  if (on) SV()[k] = Date.now(); else delete SV()[k];
  save();
  $$(`.sv-btn[data-ty="${b.dataset.ty}"]`).filter(x => x.dataset.ref === b.dataset.ref).forEach(x => { x.classList.toggle('on', on); x.setAttribute('aria-pressed', on); const lab = x.querySelector('span'); x.innerHTML = ico(on ? 'bmf' : 'bm') + (lab ? `<span>${on ? 'সংরক্ষিত' : (lab.dataset.l || 'সংরক্ষণ')}</span>` : ''); });
  toast(on ? `★ সংরক্ষিত — লাইব্রেরির "${(SVT.find(t => t[0] === b.dataset.ty) || [, ''])[1]}" ট্যাবে পাবে` : 'সংরক্ষণ থেকে সরানো হলো');
  if (on) { pop(b); try { msCheck(); } catch (e) { } }
};
const svCount = ty => Object.keys(SV()).filter(k => !ty || k.startsWith(ty + ':')).length;

/* ---------- ছোট উদযাপন (বাধাহীন কনফেটি) ---------- */
function pop(el) {
  if (document.documentElement.dataset.motion === 'reduce' || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const r = el && el.getBoundingClientRect ? el.getBoundingClientRect() : { left: innerWidth / 2, top: innerHeight / 2, width: 0, height: 0 };
  const w = document.createElement('div'); w.className = 'pop-burst'; w.style.left = (r.left + r.width / 2) + 'px'; w.style.top = (r.top + r.height / 2) + 'px';
  const C = ['#FF6B6B', '#FFD43B', '#51CF66', '#339AF0', '#CC5DE8', '#FF922B'];
  for (let i = 0; i < 14; i++) { const a = i / 14 * Math.PI * 2, d = 26 + Math.random() * 26; w.innerHTML += `<i style="background:${C[i % 6]};--x:${Math.cos(a) * d}px;--y:${Math.sin(a) * d}px"></i>`; }
  document.body.appendChild(w); setTimeout(() => w.remove(), 750);
}

/* ---------- মনে রাখার ট্রিকস: অধ্যায়ভিত্তিক বাছাই করা ---------- */
// [শিরোনাম, ট্রিক (HTML), খোঁজার শব্দ — সংশ্লিষ্ট পাঠ খুঁজে লিংক করতে]
const TRICKS = { /* অধ্যায়ভিত্তিক ট্রিকস: id: [[শিরোনাম, html, কীওয়ার্ড], …] — কনটেন্ট লেখার সময় যোগ হবে */ };
function trickLesson(ch, kw) {
  const c = CHMAP[ch]; if (!c || !kw) return null; const k = kw.toLowerCase();
  return c.L.find(l => strip(l.t).toLowerCase().includes(k)) || c.L.find(l => strip((l.dp || '') + ' ' + (l.ov || '')).toLowerCase().includes(k)) || null;
}
const lessonTricks = l => [].concat(l.mh || [], l.sn || []).filter(Boolean);
function trickStats(ch) {
  const c = CHMAP[ch]; let tot = 0, got = 0;
  (TRICKS[ch] || []).forEach((t, i) => { tot++; if (TK()[ch + '#' + i]) got++; });
  c.L.forEach(l => { if (lessonTricks(l).length) { tot++; if (TK()[l.id]) got++; } });
  return { tot, got };
}
function trickCard(key, head, body, link, sub) {
  const on = !!TK()[key];
  return `<div class="card trick ${on ? 'got' : ''}" data-tk="${esc(key)}"><div class="row" style="gap:8px;align-items:flex-start;flex-wrap:nowrap"><span class="tk-i">💡</span><div style="flex:1;min-width:0"><b>${head}</b>${sub ? `<div class="small muted">${sub}</div>` : ''}<div class="tk-b">${body}</div></div></div>
  <div class="row" style="gap:6px;margin-top:8px"><button type="button" class="btn sm ${on ? 'soft' : ''}" data-act="trk" data-k="${esc(key)}">${ico('check')}${on ? 'মনে আছে' : 'মনে রাখলাম'}</button>${svBtn('t', key, 'সংরক্ষণ')}${link ? `<span class="sp"></span><button type="button" class="btn sm ghost" data-act="lesson" data-id="${link.id}">${ico('book')}পাঠে যাও</button>` : ''}</div></div>`;
}
VIEWS.tricks = ({ q = '' }) => {
  const ch = CH.id, st = trickStats(ch), cur2 = TRICKS[ch] || [];
  const top = cur2.map((t, i) => trickCard(ch + '#' + i, t[0], t[1], trickLesson(ch, t[2]), 'সেরা ট্রিক')).join('');
  const secs = SECS.map(s => { const ls = s.L.filter(l => lessonTricks(l).length); if (!ls.length) return ''; return `<section class="stack" style="gap:8px"><h2 class="h-card"><span class="mono small muted">${s.no}</span> ${s.st || s.t}</h2>${ls.map(l => trickCard(l.id, l.t, `<ul class="tk-ul">${lessonTricks(l).map(x => `<li>${x}</li>`).join('')}</ul>`, l, l.no || '')).join('')}</section>`; }).join('');
  return {
    title: 'মনে রাখার ট্রিকস', nav: 'tools',
    html: `<div class="wrap stack"><div><span class="eyebrow">ছন্দ, সংক্ষেপ ও গল্পে মনে রাখো</span><h1 class="h-sec">মনে রাখার ট্রিকস</h1></div>
    <div class="card stack" style="gap:6px"><div class="row"><b>🧠 মনে রাখা হয়েছে ${bn(st.got)}/${bn(st.tot)}</b><span class="sp"></span><span class="chip acc">প্রতিটি +৩ XP</span></div>${bar(st.tot ? st.got / st.tot * 100 : 0, 'ok')}<span class="small muted">ট্রিকটি জোরে একবার বলো, চোখ বন্ধ করে আবার মনে করো — তারপর "মনে রাখলাম" চাপো। পরে লাইব্রেরির "ট্রিকস" ট্যাবে সংরক্ষিতগুলো পাবে।</span></div>
    ${top ? `<section class="stack" style="gap:8px"><h2 class="h-card">⭐ এই অধ্যায়ের সেরা ট্রিকস</h2>${top}</section>` : ''}${secs}</div>`
  };
};
ACT.trk = b => { const k = b.dataset.k, on = !TK()[k]; if (on) TK()[k] = Date.now(); else delete TK()[k]; save(); const card = b.closest('.trick'); if (card) card.classList.toggle('got', on); b.classList.toggle('soft', on); b.innerHTML = ico('check') + (on ? 'মনে আছে' : 'মনে রাখলাম'); if (on) { pop(b); toast('+৩ XP · দারুণ!'); try { msCheck(); } catch (e) { } } };

/* ---------- লাইব্রেরি: টাইপ ও অধ্যায়ভিত্তিক ---------- */
function chGroups(items, chOf, rend) {
  return CHAPTERS.map(c => { const it = items.filter(x => chOf(x) === c.id); if (!it.length) return ''; return `<section class="stack" style="gap:8px"><h2 class="h-card lib-ch">${c.paper || ''} · অধ্যায় ${c.no}: ${c.t} <span class="chip">${bn(it.length)}</span></h2>${it.map(rend).join('')}</section>`; }).join('');
}
function svItems(ty) { return Object.keys(SV()).filter(k => k.startsWith(ty + ':')).sort((a, b) => SV()[b] - SV()[a]).map(k => k.slice(ty.length + 1)); }
VIEWS.library = ({ tab = 'all' }) => {
  const E = s => `<div class="empty">${s}</div>`;
  let body = '';
  if (tab === 'bm') { const l = LESSONS_ALL.filter(x => S.bm[x.id]); body = l.length ? chGroups(l, x => x.ch, x => `<div class="lesson-list">${lessonRow(x)}</div>`) : E('কোনো পাঠ বুকমার্ক নেই। পাঠের উপরের "বুকমার্ক" বোতামে চাপ দাও।'); }
  else if (tab === 'm') { const ids = svItems('m').filter(id => MCQ[id]); body = ids.length ? chGroups(ids, id => svCh('m', id), id => mcqHTML(MCQ[id], 0, { label: SMAP[MCQ[id].sid].no })) : E('কোনো MCQ সংরক্ষিত নেই। যেকোনো প্রশ্নের কোণার ★ চাপো।'); }
  else if (tab === 'c') { const ids = svItems('c').filter(r => { const [sid, i] = r.split('#'); return SMAP[sid] && SMAP[sid].Q.cq[+i]; }); body = ids.length ? chGroups(ids, r => svCh('c', r), r => { const [sid, i] = r.split('#'); return cqHTML(SMAP[sid].Q.cq[+i], +i, { label: `${SMAP[sid].no} · সৃজনশীল ${bn(+i + 1)}`, svk: r }); }) : E('কোনো সৃজনশীল প্রশ্ন সংরক্ষিত নেই। প্রশ্নব্যাংকের সৃজনশীল প্রশ্নে ★ চাপো।'); }
  else if (tab === 'v') { const ks = svItems('v').filter(k => VIS[k]); body = ks.length ? chGroups(ks, k => svCh('v', k), k => `<details class="blk figi lib-fig" data-fk="${k}"><summary><span class="bi">${ico('atom')}</span>${figNo(k) ? `<span class="mono small muted">${figNo(k)}</span> ` : ''}${strip(VIS[k].t).slice(0, 110)}<span class="chev">${ico('chev')}</span></summary><div class="bd">${figHTML(k)}</div></details>`) : E('কোনো চিত্র সংরক্ষিত নেই। চিত্রের শিরোনামের পাশের ★ চাপো।'); }
  else if (tab === 'f') { const ids = svItems('f').filter(id => { const s = SMAP[id.replace(/f\d+$/, '')]; return s && s.F[+id.match(/f(\d+)$/)[1]]; }); body = ids.length ? chGroups(ids, id => svCh('f', id), id => { const s = SMAP[id.replace(/f\d+$/, '')], f = s.F[+id.match(/f(\d+)$/)[1]]; return `<div class="card"><div class="row"><span class="chip">${s.no}</span><span class="sp"></span>${svBtn('f', id)}</div><div style="margin-top:6px"><b>${f[0]}</b></div><button class="btn sm soft reveal-btn" data-act="reveal">${ico('eye')}উত্তর দেখো</button><div class="ans" hidden>${f[1]}</div></div>`; }) : E('কোনো ফ্ল্যাশকার্ড সংরক্ষিত নেই। ফ্ল্যাশকার্ডের নিচের ★ চাপো।'); }
  else if (tab === 'x') { const ids = svItems('x').filter(r => { const [sid, i] = r.split('#'); return SMAP[sid] && SMAP[sid].FM[+i]; }); body = ids.length ? chGroups(ids, r => svCh('x', r), r => { const [sid, i] = r.split('#'); return formulaCards([SMAP[sid].FM[+i]], SMAP[sid]); }) : E('কোনো সূত্র সংরক্ষিত নেই। ফর্মুলা শিটে সূত্রের পাশের ★ চাপো।'); }
  else if (tab === 't') { const ks = svItems('t'); body = ks.length ? chGroups(ks, k => svCh('t', k), k => { if (LMAP[k]) { const l = LMAP[k]; return trickCard(k, l.t, `<ul class="tk-ul">${lessonTricks(l).map(x => `<li>${x}</li>`).join('')}</ul>`, l, l.no || ''); } const [ch, i] = k.split('#'), t = (TRICKS[ch] || [])[+i]; return t ? trickCard(k, t[0], t[1], trickLesson(ch, t[2]), 'সেরা ট্রিক') : ''; }) : E('কোনো ট্রিক সংরক্ষিত নেই। "মনে রাখার ট্রিকস" পাতায় বা পাঠের "মনে রাখার কৌশল" অংশে ★ চাপো।') + `<button class="btn primary" data-act="go" data-v="tricks">${ico('bulb')}মনে রাখার ট্রিকস খোলো</button>`; }
  else if (tab === 'notes') { const l = LESSONS_ALL.filter(x => S.notes[x.id]); body = l.length ? chGroups(l, x => x.ch, x => `<button class="card" style="text-align:left;color:inherit;width:100%" data-act="lesson" data-id="${x.id}"><div class="small muted">${x.no || ''} ${x.t}</div><div style="white-space:pre-wrap;margin-top:4px">${esc(S.notes[x.id])}</div></button>`) : E('কোনো নোট নেই। পাঠের নিচের "আমার নোট" বক্সে লেখো।'); }
  else if (tab === 'hl') { const l = LESSONS_ALL.filter(x => (S.hl[x.id] || []).length); body = l.length ? chGroups(l, x => x.ch, x => `<div class="card stack" style="gap:6px"><button class="btn ghost sm" style="justify-content:flex-start;padding:0;color:var(--accent)" data-act="lesson" data-id="${x.id}">${x.no || ''} ${x.t}</button>${S.hl[x.id].map((h, i) => { const t = typeof h === 'string' ? h : h.t, c = typeof h === 'string' ? 'y' : (h.c || 'y'); return `<div class="row" style="flex-wrap:nowrap;align-items:flex-start"><mark class="hl hl-${c}" style="flex:1">${esc(t)}</mark><button class="icon-btn" style="width:34px;height:34px" data-act="hlDel" data-id="${x.id}" data-i="${i}" aria-label="মুছো">${ico('trash')}</button></div>`; }).join('')}</div>`) : E('কোনো হাইলাইট নেই। পাঠের লেখা নির্বাচন করে রং বেছে নাও।'); }
  else if (tab === 'wrong') { const ids = wrongIds(); body = ids.length ? `<button class="btn primary" data-act="quiz" data-id="wrong" data-mode="wrong">${ico('repeat')}এগুলো দিয়ে কুইজ</button>` + chGroups(ids, id => svCh('m', id), id => mcqHTML(MCQ[id], 0, { label: SMAP[MCQ[id].sid].no })) : E('কোনো ভুল প্রশ্ন নেই — দারুণ!'); }
  const tabs = libTabs();
  const nz = tabs.filter(t => t[2] > 0), zero = tabs.filter(t => !t[2]);
  if (tab === 'all') body = libOverview(nz, zero);
  const shown = [['all', 'সব', nz.reduce((a, t) => a + t[2], 0)], ...nz, ...zero.filter(t => t[0] === tab)];
  return {
    title: 'সংরক্ষিত', nav: 'saved',
    html: `<div class="wrap stack"><div><span class="eyebrow">তোমার সংরক্ষণ · টাইপ ও অধ্যায়ভিত্তিক</span><h1 class="h-sec">আমার লাইব্রেরি</h1></div>
    <div class="lib-chips" role="tablist">${shown.map(([k, n, c]) => `<button role="tab" class="${tab === k ? 'on' : ''}" data-act="libTab" data-tab="${k}">${n}<span class="ct">${bn(c)}</span></button>`).join('')}</div>
    <div class="stack" style="gap:12px">${body}</div></div>`,
    after() { $$('.lib-fig').forEach(d => d.addEventListener('toggle', () => { if (d.open) setTimeout(() => window.APP_mountFigs && window.APP_mountFigs(), 30); })); }
  };
};

/* ---------- হোম: আজকের ট্রিক ---------- */
HSEC.splice(Math.max(0, HSEC.findIndex(x => x[0] === 'fact') + 1), 0, ['trick', 'আজকের মনে রাখার ট্রিক']);
HS.trick = () => {
  const list = TRICKS[CH.id] || []; if (!list.length) return '';
  let h = 0; const k = dkey() + CH.id; for (let i = 0; i < k.length; i++) h = (h * 31 + k.charCodeAt(i)) % 9973;
  const i = (h + trickOff) % list.length, t = list[i], key = CH.id + '#' + i, st = trickStats(CH.id);
  return `<div class="card stack trick ${TK()[key] ? 'got' : ''}" style="gap:6px;padding:14px"><div class="row"><b>💡 আজকের ট্রিক: ${t[0]}</b><span class="sp"></span><span class="chip">${bn(st.got)}/${bn(st.tot)}</span></div><div class="tk-b">${t[1]}</div>
  <div class="row" style="gap:6px"><button type="button" class="btn sm ${TK()[key] ? 'soft' : ''}" data-act="trk" data-k="${key}">${ico('check')}${TK()[key] ? 'মনে আছে' : 'মনে রাখলাম'}</button>${svBtn('t', key)}<button type="button" class="btn sm ghost" data-act="trickNext">${ico('repeat')}আরেকটি</button><span class="sp"></span><button type="button" class="btn sm ghost" data-act="go" data-v="tricks">সব ট্রিকস ›</button></div></div>`;
};
let trickOff = 0;
ACT.trickNext = () => { trickOff++; render(true); };

/* ---------- দৈনিক লক্ষ্য: হোম থেকে সরাসরি বদলানো ---------- */
function goalSheetHTML() {
  const g = S.goal, td = S.days[dkey()] || {};
  const pm = [10, 15, 20, 30, 45, 60, 90, 120, 180], pl = [1, 2, 3, 4, 5, 6, 8, 10];
  return `<div class="stack" style="gap:14px"><h2 class="h-card">🎯 দৈনিক লক্ষ্য ঠিক করো</h2>
  <div class="stack" style="gap:8px"><div class="row"><b>প্রতিদিন পড়ার সময়</b><span class="sp"></span><span class="chip acc">${bn(g.m)} মিনিট</span></div>
    <div class="goal-chips">${pm.map(v => `<button type="button" class="${g.m === v ? 'on' : ''}" data-act="goalSet" data-k="m" data-v="${v}">${v >= 60 ? (v % 60 ? bn(Math.floor(v / 60)) + ' ঘ. ' + bn(v % 60) + ' মি.' : bn(v / 60) + ' ঘণ্টা') : bn(v) + ' মিনিট'}</button>`).join('')}</div>
    <div class="row" style="justify-content:center;gap:10px"><button class="btn sm" data-act="goalSet" data-k="m" data-v="${g.m - 5}">− ৫</button><b class="mono" style="min-width:70px;text-align:center">${bn(g.m)} মি.</b><button class="btn sm" data-act="goalSet" data-k="m" data-v="${g.m + 5}">+ ৫</button></div></div>
  <div class="stack" style="gap:8px"><div class="row"><b>প্রতিদিন সম্পন্ন পাঠ</b><span class="sp"></span><span class="chip acc">${bn(g.l)}টি</span></div>
    <div class="goal-chips">${pl.map(v => `<button type="button" class="${g.l === v ? 'on' : ''}" data-act="goalSet" data-k="l" data-v="${v}">${bn(v)}টি</button>`).join('')}</div></div>
  <p class="small muted" style="margin:0">আজ এ পর্যন্ত: ${bn(Math.round(td.m || 0))} মিনিট, ${bn(td.l || 0)}টি পাঠ। ছোট লক্ষ্য দিয়ে শুরু করে ধারা (স্ট্রিক) ধরে রাখা, বড় লক্ষ্যের চেয়ে বেশি কার্যকর।</p>
  <button class="btn primary block" data-act="closeSheet">ঠিক আছে</button></div>`;
}
ACT.goalSheet = () => openSheet(goalSheetHTML());
ACT.goalSet = b => {
  const k = b.dataset.k; S.goal[k] = clamp(+b.dataset.v, k === 'l' ? 1 : 5, k === 'l' ? 15 : 300); save();
  const sh = $('#sheetWrap .sheet'); if (sh) sh.innerHTML = '<div class="grab"></div>' + goalSheetHTML();
  if (cur.name === 'home') render(true);
};

/* নিচের বারের ২য় বোতাম বদলানো */
ACT.navSlot = b => { S.nav2 = b.dataset.k; save(); const o = document.querySelector('#bnav [data-n="saved"],#bnav [data-n="chapter"]'); if (o) o.outerHTML = navSlotHTML(); b.parentElement.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); toast(S.nav2 === 'chapter' ? 'নিচের বারে এখন “অধ্যায়”' : 'নিচের বারে এখন “সংরক্ষিত”'); };

/* ---------- টুলস: পরিসর বদল ---------- */
ACT.scope = b => { const k = b.dataset.k; S.tsc = k; save(); cur.args.sc = k; cur.args.q = ''; render(); };

/* ---------- মিনিমাল হোম ---------- */
HS.recent = () => {
  const ids = (S.rl || []).filter(x => LMAP[x]); const last = lastLesson(); if (last && !ids.includes(last.id)) ids.unshift(last.id);
  const L = ids.slice(0, 3).map(x => [LMAP[x], 1]);
  for (const l of LESSONS) { if (L.length >= 3) break; if (!S.done[l.id] && !L.some(y => y[0] === l)) L.push([l, 0]); }
  if (!L.length) return '';
  return `<div class="ptable-head"><h2 class="h-sec">সাম্প্রতিক পাঠ</h2><span class="small muted">শেষ পড়া ৩টি</span></div>
  <div class="rec-row">${L.map(([l, seen]) => { const c = CHMAP[l.ch]; return `<button class="rec card" data-act="lesson" data-id="${l.id}"><span class="rec-k">${seen ? (S.done[l.id] ? '✓ পড়া' : '↻ চলছে') : '▶ পরের'}</span><b>${l.t}</b><small>অধ্যায় ${c.no} · ${SMAP[l.sid].no}</small></button>`; }).join('')}</div>`;
};
{ const i = HSEC.findIndex(x => x[0] === 'saved'); if (i >= 0) HSEC.splice(i, 1); }
HSEC.push(['recent', 'সাম্প্রতিক ৩টি পাঠ']);
const HOME_MIN = ['subj', 'chap', 'sub', 'recent', 'week', 'level'];
HSEC.sort((a, b) => { const ia = HOME_MIN.indexOf(a[0]), ib = HOME_MIN.indexOf(b[0]); return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib); });
const homeMinHidden = () => { const h = {}; HSEC.forEach(([k]) => { if (!HOME_MIN.includes(k)) h[k] = 1; }); return h; };
SET_DEF.homeHidden = homeMinHidden();
if ((S.hmv || 0) < 1) { const st = SET(); st.homeOrder = []; st.homeHidden = homeMinHidden(); S.hmv = 1; save(); }
ACT.homeReset = () => { const st = SET(); st.homeOrder = []; st.homeHidden = homeMinHidden(); save(); render(true); toast('হোম ডিফল্ট (মিনিমাল) সাজানোয় ফিরেছে'); };

/* ---------- পড়া হয়েছে: একক টগল, উপ-অধ্যায় একসাথে, নির্বাচন মোড ---------- */
function rrKeep() { const open = $$('details.sa[open]').map(d => d.dataset.sid); render(true); open.forEach(id => { const d = document.querySelector(`details.sa[data-sid="${id}"]`); if (d) d.open = true; }); selBar(); }
const SELF = () => S.self || (S.self = {});
/* on: 1 = আয়ত্ত (যাচাই পাস), 's' = নিজে চিহ্নিত "পড়েছি", 0 = চিহ্ন মুছো */
function markIds(ids, on) { let n = 0; ids.forEach(id => { if (!LMAP[id]) return; if (on === 1) { if (!S.done[id]) { S.done[id] = Date.now(); n++; } delete SELF()[id]; } else if (on === 's') { if (!S.done[id] && !SELF()[id]) { SELF()[id] = Date.now(); n++; } } else { if (S.done[id] || SELF()[id]) n++; delete S.done[id]; delete SELF()[id]; } }); save(); return n; }
ACT.selStart = () => { SEL = new Set(); rrKeep(); toast('যে পাঠগুলো পড়েছ সেগুলোতে চাপ দাও'); };
ACT.selEnd = () => { SEL = null; rrKeep(); };
ACT.selPick = b => { const id = b.dataset.id; if (SEL.has(id)) SEL.delete(id); else SEL.add(id); b.classList.toggle('sel', SEL.has(id)); const bx = b.querySelector('.selbox'); if (bx) bx.innerHTML = SEL.has(id) ? ico('check') : ''; const d = b.closest('details.sa'), x = d && SMAP[d.dataset.sid]; if (x) { const o = d.querySelector('[data-act="selSec"]'); if (o) o.outerHTML = secDoneBtn(x); } selBar(); };
ACT.selSec = b => { const x = SMAP[b.dataset.id]; if (!x) return; const ids = x.L.map(l => l.id), all = ids.every(i => SEL.has(i)); ids.forEach(i => all ? SEL.delete(i) : SEL.add(i)); rrKeep(); };
function selBar() {
  let el = document.getElementById('selbar');
  if (!SEL || !document.querySelector('.li.selm')) { if (SEL && !document.querySelector('.li.selm')) SEL = null; if (el) el.remove(); return; }
  if (!el) { el = document.createElement('div'); el.id = 'selbar'; el.className = 'selbar'; document.body.appendChild(el); }
  const n = SEL.size;
  el.innerHTML = `<b>${bn(n)}টি নির্বাচিত</b><span class="sp"></span><button class="btn sm primary" data-act="selApply" data-on="1" ${n ? '' : 'disabled'}>${ico('check')}যাচাই করে শেষ</button><button class="btn sm" data-act="selApply" data-on="s" ${n ? '' : 'disabled'}>শুধু পড়েছি</button><button class="btn sm" data-act="selApply" data-on="0" ${n ? '' : 'disabled'}>মুছো</button><button class="btn sm ghost" data-act="selEnd" aria-label="বাতিল">✕</button>`;
}

/* ---------- যাচাই: টিক দিলেই পাঠের অনুশীলনী থেকে ছোট কুইজ ---------- */
let LQI = null, VQ = null;
function lessonPool(l) {
  if (!LQI) { LQI = {}; Object.values(MCQ).forEach(m => { const mm = /^(.*)x\d+$/.exec(m.id), lid = m.l && LMAP[m.l] ? m.l : mm && LMAP[mm[1]] ? mm[1] : null; if (lid) (LQI[lid] = LQI[lid] || []).push(m.id); }); }
  let p = (LQI[l.id] || []).slice();
  if (p.length < 3) { const s = SMAP[l.sid]; Object.values(MCQ).forEach(m => { if (m.sid === l.sid && !p.includes(m.id)) { try { if (readRef(m).l === l) p.push(m.id); } catch (e) { } } }); }
  if (p.length < 2) Object.values(MCQ).forEach(m => { if (m.sid === l.sid && !p.includes(m.id)) p.push(m.id); });
  return p;
}
const shuf = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const VQ_MAX = 15;
function vqOpen(lids, o = {}) {
  lids = lids.filter(id => LMAP[id] && !S.done[id]);
  if (!lids.length) { toast('এগুলো আগেই আয়ত্ত ✓'); return; }
  let extra = 0; if (lids.length > VQ_MAX) { extra = lids.length - VQ_MAX; lids = lids.slice(0, VQ_MAX); }
  const k = lids.length === 1 ? 3 : lids.length <= 5 ? 2 : 1, need = k === 3 ? 2 : k;
  const qs = []; const noQ = [];
  lids.forEach(id => { const p = shuf(lessonPool(LMAP[id])).slice(0, k); if (!p.length) noQ.push(id); p.forEach(q => qs.push({ id: q, lid: id })); });
  if (!qs.length) { markIds(lids, 's'); SEL = null; rrKeep(); toast('এখানে এখনো যাচাইয়ের প্রশ্ন যোগ হয়নি — "পড়েছি" চিহ্ন দেওয়া হলো'); return; }
  VQ = { lids, qs, ans: {}, need, k, o, noQ };
  const one = lids.length === 1, l0 = LMAP[lids[0]];
  openSheet(`<div class="vq"><h2 class="h-card" style="margin:0 0 4px">${ico('check')} ${one ? 'পড়া শেষ? ছোট যাচাই' : `${bn(lids.length)}টি পাঠের যাচাই`}</h2>
  <p class="small muted" style="margin:0 0 10px">${one ? `<b>${l0.no || ''} ${l0.t}</b> — ${bn(k)}টির মধ্যে ${bn(need)}টি ঠিক হলে পাঠটি <b>আয়ত্ত ✓</b> হবে।` : `প্রতি পাঠ থেকে ${bn(k)}টি প্রশ্ন${k > 1 ? ' — সবগুলো ঠিক হলে' : ' — ঠিক হলে'} সেই পাঠ <b>আয়ত্ত ✓</b>; ভুল হলে শুধু "পড়েছি" থাকবে।`}${extra ? ` (একবারে সর্বোচ্চ ${bn(VQ_MAX)}টি পাঠ — বাকি ${bn(extra)}টি পরের রাউন্ডে)` : ''}</p>
  <div class="stack" style="gap:10px">${qs.map((q, i) => mcqHTML(MCQ[q.id], i, { act: 'vqAns', label: `প্রশ্ন ${bn(i + 1)}${one ? '' : ' · ' + (LMAP[q.lid].no || '')}` })).join('')}</div>
  <div id="vqRes"></div>
  <div class="row vq-foot" style="gap:6px;flex-wrap:wrap;margin-top:12px"><button class="btn sm" data-act="vqSelf">${ico('book')}এখন না, শুধু "পড়েছি" দাও</button>${o.allowClear ? '<button class="btn sm ghost" data-act="vqClear">চিহ্ন মুছো</button>' : ''}<span class="sp"></span><button class="btn sm ghost" data-act="vqClose">বাতিল</button></div></div>`);
}
ACT.vqAns = b => {
  const card = b.closest('.qcard'); if (!VQ || card.dataset.done) return; card.dataset.done = 1;
  const m = MCQ[b.dataset.q], pick = +b.dataset.i, ok = pick === m.a; recordQ(m.id, ok); VQ.ans[m.id] = ok;
  $$('.opt', card).forEach((x, i) => { x.disabled = true; if (i === m.a) x.classList.add('right'); if (i === pick && !ok) x.classList.add('wrong'); });
  $('.fb', card).innerHTML = `<div class="feedback ${ok ? 'ok' : 'bad'}"><b>${ok ? '✓ সঠিক' : `✗ সঠিক উত্তর: (${OL[m.a]}) ${m.o[m.a]}`}</b>${!ok && m.x ? `<div class="small">${m.x}</div>` : ''}</div>`;
  if (Object.keys(VQ.ans).length >= VQ.qs.length) vqFinish();
};
function vqFinish() {
  const { lids, qs, ans, need, k, o, noQ } = VQ;
  const pass = [], fail = [];
  lids.forEach(id => { const mine = qs.filter(q => q.lid === id); if (!mine.length) { fail.push(id); return; } const c = mine.filter(q => ans[q.id]).length; (c >= Math.min(need, mine.length) ? pass : fail).push(id); });
  markIds(pass, 1); markIds(fail, 's');
  const tot = qs.length, cor = qs.filter(q => ans[q.id]).length;
  const r = $('#vqRes');
  if (r) r.innerHTML = `<div class="card vq-res ${fail.length ? '' : 'ok'}" style="margin-top:12px"><b>${fail.length ? (pass.length ? '👍 ভালো চেষ্টা!' : '📖 আরেকবার পড়ে নাও') : '🎉 দারুণ! সব আয়ত্ত'}</b> <span class="small muted">${bn(cor)}/${bn(tot)} সঠিক</span>
  ${pass.length ? `<div class="small" style="margin-top:6px">✓ আয়ত্ত: ${pass.map(id => LMAP[id].no || LMAP[id].t).join(', ')}</div>` : ''}
  ${fail.length ? `<div class="small" style="margin-top:6px">↻ আবার পড়ো (এখন "পড়েছি" চিহ্ন):</div><div class="row" style="gap:6px;flex-wrap:wrap;margin-top:4px">${fail.map(id => `<button class="linkbtn" data-act="vqGo" data-id="${id}">${LMAP[id].no || ''} ${LMAP[id].t}</button>`).join('')}</div>` : ''}
  <button class="btn sm primary" style="margin-top:10px" data-act="vqClose">ঠিক আছে</button></div>`;
  const f = $('.vq-foot'); if (f) f.remove();
  if (r) r.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  VQ.done = { pass, fail };
  if (pass.length) { try { pop(r.querySelector('b')); } catch (e) { } try { msCheck(); } catch (e) { } }
}
ACT.vqClose = () => { const v = VQ; VQ = null; closeSheet(); if (v && v.done && v.o.lesson && v.done.pass.length) { const id = v.lids[0]; delete S.done[id]; save(); const b = document.querySelector(`[data-act="done"][data-id="${id}"]`); if (b && ACT._done0) { ACT._done0(b); return; } S.done[id] = Date.now(); save(); } SEL = null; rrKeep(); };
ACT.vqSelf = () => { if (!VQ) return; const n = markIds(VQ.lids, 's'); VQ = null; closeSheet(); SEL = null; rrKeep(); toast(`"পড়েছি" চিহ্ন দেওয়া হলো — পরে যাচাই করে আয়ত্ত করো`); };
ACT.vqClear = () => { if (!VQ) return; markIds(VQ.lids, 0); VQ = null; closeSheet(); SEL = null; rrKeep(); toast('চিহ্ন মুছে দেওয়া হলো'); };
ACT.vqGo = b => { VQ = null; closeSheet(); go('lesson', { id: b.dataset.id }); };

ACT.ckToggle = b => { const id = b.dataset.id; if (S.done[id]) { markIds([id], 0); rrKeep(); toast('চিহ্ন মুছে দেওয়া হলো'); return; } vqOpen([id], { allowClear: !!SELF()[id] }); };
ACT.secDone = b => { const x = SMAP[b.dataset.id]; if (!x) return; const ids = x.L.map(l => l.id); if (ids.every(i => S.done[i])) { markIds(ids, 0); rrKeep(); toast(`${x.no} — চিহ্ন মুছে দেওয়া হলো`); return; } vqOpen(ids); };
ACT.selApply = b => { if (!SEL || !SEL.size) return; const on = b.dataset.on, ids = [...SEL]; if (on === '1') { vqOpen(ids); return; } const n = markIds(ids, on === 's' ? 's' : 0); SEL = null; rrKeep(); toast(on === 's' ? `${bn(n)}টি পাঠে "পড়েছি" চিহ্ন — যাচাই করলে আয়ত্ত হবে` : `${bn(n)}টি পাঠের চিহ্ন মুছে দেওয়া হলো`); };

/* পাঠের ভেতরের "পাঠ শেষ": যথেষ্ট সময় ও শেষ পর্যন্ত স্ক্রল করলে সরাসরি, নইলে যাচাই */
addEventListener('scroll', () => { if (!LVW || !cur || cur.name !== 'lesson') return; const h = document.documentElement.scrollHeight - innerHeight; const f = h > 0 ? scrollY / h : 1; if (f > LVW.sc) LVW.sc = f; }, { passive: true });
ACT._done0 = ACT.done;
ACT.done = b => {
  const id = b.dataset.id, l = LMAP[id]; if (!l) return;
  if (S.done[id]) return ACT._done0(b);
  const need = readMin(l) * 60000 / 3, ok = LVW && LVW.id === id && (Date.now() - LVW.t0) >= need && LVW.sc >= 0.8;
  if (ok) { delete SELF()[id]; return ACT._done0(b); }
  vqOpen([id], { lesson: true });
};

/* অগ্রগতি পাতায়: আয়ত্ত বনাম নিজে চিহ্নিত */
{ const _st = VIEWS.stats; VIEWS.stats = a => { const o = _st(a); try { const dn = LESSONS_ALL.filter(l => S.done[l.id]).length, sf = LESSONS_ALL.filter(l => !S.done[l.id] && SELF()[l.id]).length; const card = `<section class="card stack" style="gap:6px"><h2 class="h-card">পড়ার সততা রিপোর্ট</h2><div class="row" style="gap:16px;flex-wrap:wrap"><span><b class="ok-t">${bn(dn)}</b> <span class="small muted">পাঠ আয়ত্ত (যাচাই করে)</span></span><span><b>${bn(sf)}</b> <span class="small muted">পাঠ নিজে চিহ্নিত — যাচাই বাকি</span></span></div><p class="small muted" style="margin:0">অগ্রগতি, XP ও ব্যাজ শুধু আয়ত্ত পাঠ গোনে। বৃত্তে চাপ দিয়ে ছোট যাচাই পাস করলেই আয়ত্ত।</p></section>`; o.html = o.html.replace(/<\/div>\s*$/, card + '</div>'); } catch (e) { } return o; }; }

/* ---------- লাইব্রেরি: সারসংক্ষেপ — বেশি কনটেন্ট যেখানে, সেটা আগে ---------- */
const LIBI = { bm: 'bm', m: 'q', c: 'pen', v: 'atom', f: 'cards', x: 'sigma', t: 'bulb', hl: 'pen', notes: 'note', wrong: 'alert' };
function libTabs() {
  const hlN = LESSONS_ALL.reduce((a, x) => a + (S.hl[x.id] || []).length, 0);
  const t = [['bm', 'পাঠ', LESSONS_ALL.filter(x => S.bm[x.id]).length], ...SVT.map(([k, n]) => [k, n, svCount(k)]), ['hl', 'হাইলাইট', hlN], ['notes', 'নোট', LESSONS_ALL.filter(x => S.notes[x.id]).length], ['wrong', 'ভুল প্রশ্ন', wrongIds().length]];
  return t.map((x, i) => [...x, i]).sort((a, b) => (b[2] - a[2]) || (a[3] - b[3]));
}
function libPeek(k) {
  const cut = (x, n = 70) => { x = strip(x).replace(/\s+/g, ' ').trim(); return esc(x.length > n ? x.slice(0, n) + '…' : x); };
  try {
    if (k === 'bm') return LESSONS_ALL.filter(x => S.bm[x.id]).slice(0, 2).map(x => cut(x.t));
    if (k === 'm') return svItems('m').filter(id => MCQ[id]).slice(0, 2).map(id => cut(MCQ[id].q));
    if (k === 'wrong') return wrongIds().slice(0, 2).map(id => cut(MCQ[id].q));
    if (k === 'c') return svItems('c').slice(0, 2).map(r => { const [sid, i] = r.split('#'); return SMAP[sid] ? `${SMAP[sid].no} · সৃজনশীল ${bn(+i + 1)}` : ''; });
    if (k === 'v') return svItems('v').filter(x => VIS[x]).slice(0, 2).map(x => cut(VIS[x].t));
    if (k === 'f') return svItems('f').slice(0, 2).map(id => { const s = SMAP[id.replace(/f\d+$/, '')], f = s && s.F[+id.match(/f(\d+)$/)[1]]; return f ? cut(f[0]) : ''; });
    if (k === 'x') return svItems('x').slice(0, 2).map(r => { const [sid, i] = r.split('#'), f = SMAP[sid] && SMAP[sid].FM[+i]; return f ? cut(f[0]) : ''; });
    if (k === 't') return svItems('t').slice(0, 2).map(x => LMAP[x] ? cut(LMAP[x].t) : (() => { const [ch, i] = x.split('#'), t = (TRICKS[ch] || [])[+i]; return t ? cut(t[0]) : ''; })());
    if (k === 'hl') { const o = []; LESSONS_ALL.forEach(x => (S.hl[x.id] || []).forEach(h => o.push(typeof h === 'string' ? h : h.t))); return o.slice(-2).reverse().map(x => cut(x)); }
    if (k === 'notes') return LESSONS_ALL.filter(x => S.notes[x.id]).slice(0, 2).map(x => cut(S.notes[x.id]));
  } catch (e) { }
  return [];
}
function libOverview(nz, zero) {
  if (!nz.length) return `<div class="empty">এখনো কিছু সংরক্ষণ করোনি। যেকোনো প্রশ্ন, চিত্র, সূত্র বা ট্রিকের ★ চাপো — এখানে টাইপ অনুযায়ী জমা হবে।</div>`;
  return `<div class="lib-grid">${nz.map(([k, n, c]) => `<button class="card lib-card" data-act="libTab" data-tab="${k}"><span class="lib-top"><span class="ti">${ico(LIBI[k] || 'star')}</span><b>${n}</b><span class="sp"></span><span class="lib-n">${bn(c)}</span></span><span class="lib-peek">${libPeek(k).filter(Boolean).map(x => `<span>${x}</span>`).join('')}</span><span class="lib-more">সব দেখো ›</span></button>`).join('')}</div>
  ${zero.length ? `<p class="small muted" style="margin:0">খালি: ${zero.map(t => t[1]).join(' · ')}</p>` : ''}`;
}

/* সেটিংস: শেষ করা পাঠ/উপ-অধ্যায়ের শিরোনামে স্ট্রাইক */
ACT.strikeSet = b => { const st = SET(); st.strike = b.dataset.k === 'on'; save(); applyStrike(); b.parentElement.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); toast(st.strike ? 'শেষ করা অংশে দাগ কাটা দেখাবে' : 'স্ট্রাইক বন্ধ'); };
applyStrike();

/* ---------- হোম সাজাও: শিট থেকে সরাসরি — দেখাও/লুকাও ও ক্রম বদল সঙ্গে সঙ্গে প্রযোজ্য ---------- */
const HOME_DEF2 = ['tools', 'outline'];
HOME_MIN.push(...HOME_DEF2);
HSEC.sort((a, b) => { const ia = HOME_MIN.indexOf(a[0]), ib = HOME_MIN.indexOf(b[0]); return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib); });
SET_DEF.homeHidden = homeMinHidden();
if ((S.hmv || 0) < 2) { const st = SET(); HOME_DEF2.forEach(k => { delete st.homeHidden[k]; }); if (st.homeOrder && st.homeOrder.length) { st.homeOrder = st.homeOrder.filter(k => !HOME_DEF2.includes(k)); const i = st.homeOrder.indexOf('level'); st.homeOrder.splice(i < 0 ? st.homeOrder.length : i + 1, 0, ...HOME_DEF2); } S.hmv = 2; save(); }
function homeSheetHTML() {
  const s = SET(), o = homeOrder();
  return `<div class="hsheet"><div class="row" style="align-items:center;margin-bottom:6px"><h2 class="h-card" style="margin:0">হোম সাজাও</h2><span class="sp"></span><button class="icon-btn" data-act="closeSheet" aria-label="বন্ধ">✕</button></div>
  <p class="small muted" style="margin:0 0 8px">সুইচে চাপলে অংশটি দেখাবে/লুকাবে, ▲▼ দিয়ে ক্রম বদলাও — সবকিছু সঙ্গে সঙ্গে হোমে বসে যায়, আলাদা করে নিশ্চিত করতে হয় না।</p>
  <div class="hs-list">${o.map((id, i) => { const lab = (HSEC.find(x => x[0] === id) || [])[1] || id, on = !s.homeHidden[id]; return `<div class="hs-item ${on ? '' : 'off'}"><button class="hs-mv" data-act="hsMv" data-id="${id}" data-d="-1" ${i ? '' : 'disabled'} aria-label="উপরে">▲</button><button class="hs-mv" data-act="hsMv" data-id="${id}" data-d="1" ${i < o.length - 1 ? '' : 'disabled'} aria-label="নিচে">▼</button><span class="hs-lab">${lab}</span><button class="sw-tg ${on ? 'on' : ''}" data-act="hsTg" data-id="${id}" role="switch" aria-checked="${on}" aria-label="${lab}"><i></i></button></div>`; }).join('')}</div>
  <button class="btn sm ghost" style="margin-top:10px" data-act="hsDef">${ico('repeat')}ডিফল্টে ফেরাও</button></div>`;
}
function hsRefresh() { if (cur && cur.name === 'home') render(true); const sh = document.querySelector('#sheetWrap .hsheet'); if (sh) sh.outerHTML = homeSheetHTML(); }
ACT.homeEdit = () => { HEDIT = false; openSheet(homeSheetHTML()); const w = $('#sheetWrap'); if (w) w.classList.add('lite'); };
ACT.homeEditGo = () => { HEDIT = false; stack.length = 0; go('home', {}, { replace: true }); setTimeout(ACT.homeEdit, 60); };
ACT.hsTg = b => { const s = SET(), id = b.dataset.id; if (s.homeHidden[id]) delete s.homeHidden[id]; else s.homeHidden[id] = 1; save(); hsRefresh(); };
ACT.hsMv = b => { const o = homeOrder(), s = SET(), i = o.indexOf(b.dataset.id), j = i + (+b.dataset.d); if (i < 0 || j < 0 || j >= o.length) return; [o[i], o[j]] = [o[j], o[i]]; s.homeOrder = o; save(); hsRefresh(); };
ACT.hsDef = () => { const st = SET(); st.homeOrder = []; st.homeHidden = homeMinHidden(); save(); hsRefresh(); toast('হোম ডিফল্ট সাজানোয় ফিরেছে'); };

/* ---------- অগ্রগতি মুছা: ৪৮ ঘণ্টা অপেক্ষা, মাঝে বাতিল করা যায় ---------- */
function resetLeft() { return S.resetAt ? Math.max(0, S.resetAt - Date.now()) : 0; }
function fmtLeft(ms) { const h = Math.floor(ms / 36e5), m = Math.floor(ms % 36e5 / 6e4); return h ? `${bn(h)} ঘণ্টা ${bn(m)} মিনিট` : `${bn(m)} মিনিট`; }
function resetCardBody() {
  if (S.resetAt) { const d = new Date(S.resetAt); return `<p style="margin:0"><b style="color:var(--bad)">⏳ অগ্রগতি মুছে ফেলার অনুরোধ চালু আছে।</b></p><p class="small muted" style="margin:0">আর ${fmtLeft(resetLeft())} পর (${bn(d.getDate())} ${MON[d.getMonth()]}, ${bn(d.getHours())}:${bn(String(d.getMinutes()).padStart(2, '0'))}) সব মুছে যাবে। মত বদলালে এখনই বাতিল করো — কিছুই হারাবে না।</p><button class="btn primary" data-act="resetCancel">${ico('repeat')}মুছে ফেলা বাতিল করো</button>`; }
  return `<p class="small muted" style="margin:0">সব অধ্যায়ের সম্পন্ন পাঠ, নোট, হাইলাইট, কুইজ ও স্ট্রিক মুছে যাবে। ভুল করে চাপলেও চিন্তা নেই — মুছবে <b>৪৮ ঘণ্টা পরে</b>, এর মধ্যে বাতিল করা যাবে।</p><button class="btn" id="resetBtn" data-act="reset" style="color:var(--bad);border-color:var(--bad)">${ico('trash')}সব অগ্রগতি মুছো (৪৮ ঘণ্টা পরে)</button>`;
}
const RESET_DELAY = 48 * 36e5;
ACT.resetCancel = () => { delete S.resetAt; save(); toast('✓ বাতিল হয়েছে — তোমার সব অগ্রগতি থাকছে'); render(true); };
function resetDue() { if (S.resetAt && Date.now() >= S.resetAt) { const th = S.theme, ch = S.ch, set = S.set; S = DEF(); S.theme = th; S.ch = ch; S.set = set; S.hmv = 2; S.thv = 2; save(); toast('নির্ধারিত সময় পার হওয়ায় সব অগ্রগতি মুছে ফেলা হয়েছে'); try { go('home', {}, { replace: true }); } catch (e) { } return true; } return false; }
const HS_resetWarn = () => S.resetAt ? `<div class="card reset-warn"><span>⏳ <b>${fmtLeft(resetLeft())} পর</b> সব অগ্রগতি মুছে যাবে।</span><button class="btn sm primary" data-act="resetCancel">বাতিল করো</button></div>` : '';
{ const _h = VIEWS.home; VIEWS.home = a => { const o = _h(a); const w = HS_resetWarn(); if (w) o.html = o.html.replace('<div class="hello-row">', w + '<div class="hello-row">'); return o; }; }
if (S.resetAt && Date.now() >= S.resetAt) { const th = S.theme, ch = S.ch, set = S.set; S = DEF(); S.theme = th; S.ch = ch; S.set = set; S.hmv = 2; S.thv = 2; save(); setTimeout(() => toast('নির্ধারিত সময় পার হওয়ায় সব অগ্রগতি মুছে ফেলা হয়েছে'), 1200); }
setInterval(resetDue, 60000);

/* ═══════════ লাইভ ইন্টারঅ্যাকশন (সব পাতায়) ═══════════
   - মাউসে: কার্ডগুলো কার্সরের দিকে হালকা ঝোঁকে + কার্সরের নিচে আলো; বোতাম সামান্য কার্সরের দিকে টানে
   - টাচে: চাপের জায়গা থেকে রিপল
   - পাতা খুললে অংশগুলো স্তরে স্তরে ভেসে ওঠে, অগ্রগতির বার ভরে ওঠে, সংখ্যা গুনে ওঠে
   সব কাজ rAF-এ একবার, শুধু transform/opacity; "অ্যানিমেশন কমাও" দিলে বন্ধ। */
const FXrm = () => { const m = document.documentElement.dataset.motion; return m === 'reduce' || (m !== 'full' && matchMedia('(prefers-reduced-motion: reduce)').matches); };
const FX_TILT = '.tool,.qk,.mini,.prow,.ch-item,.lib-card,.rec,.pbtn,.theme-opt,.lv,.wk,.resume,.cd-card,.tile,button.card';
const FX_MAG = '.btn,.xc,.schip,.lgi,.lib-chips button,.goal-chips button,.seg button';
const FX_GLOW = FX_TILT + ',.qcard,.sa>summary,.trick,.fact-card';
if (matchMedia('(hover:hover) and (pointer:fine)').matches) {
  let fxEl = null, mgEl = null, glEl = null, fxRaf = 0, px = 0, py = 0, tgt = null;
  const clr = (el, ...ks) => { if (el) ks.forEach(k => el.style.removeProperty(k)); };
  const run = () => {
    fxRaf = 0; if (FXrm()) return; const t = tgt; if (!t || !t.closest) return;
    if (t.closest('.xpt .xg')) { clr(fxEl, '--rx', '--ry'); clr(mgEl, '--tx', '--ty'); if (glEl) glEl.classList.remove('glow'); fxEl = mgEl = glEl = null; return; }
    const a = t.closest(FX_TILT), m = t.closest(FX_MAG), g = t.closest(FX_GLOW);
    if (a !== fxEl) { clr(fxEl, '--rx', '--ry'); fxEl = a; }
    if (m !== mgEl) { clr(mgEl, '--tx', '--ty'); mgEl = m; }
    if (g !== glEl) { if (glEl) glEl.classList.remove('glow'); glEl = g; if (g) g.classList.add('glow'); }
    if (a) { const r = a.getBoundingClientRect(), x = (px - r.left) / r.width - 0.5, y = (py - r.top) / r.height - 0.5, k = Math.min(1, 220 / Math.max(r.width, 1)) * 5; a.style.setProperty('--rx', (-y * k).toFixed(2) + 'deg'); a.style.setProperty('--ry', (x * k).toFixed(2) + 'deg'); }
    if (m) { const r = m.getBoundingClientRect(), x = px - r.left - r.width / 2, y = py - r.top - r.height / 2; m.style.setProperty('--tx', (x * 0.12).toFixed(1) + 'px'); m.style.setProperty('--ty', (y * 0.18).toFixed(1) + 'px'); }
    if (g) { const r = g.getBoundingClientRect(); g.style.setProperty('--mx', (px - r.left).toFixed(0) + 'px'); g.style.setProperty('--my', (py - r.top).toFixed(0) + 'px'); }
  };
  document.addEventListener('pointermove', e => { if (e.pointerType !== 'mouse') return; px = e.clientX; py = e.clientY; tgt = e.target; if (!fxRaf) fxRaf = requestAnimationFrame(run); }, { passive: true });
  document.addEventListener('pointerleave', () => { tgt = null; clr(fxEl, '--rx', '--ry'); clr(mgEl, '--tx', '--ty'); if (glEl) glEl.classList.remove('glow'); fxEl = mgEl = glEl = null; });
}
/* রিপল — বোতাম ও কার্ডে চাপের জায়গা থেকে */
const FX_RPL = '.btn,.opt,.qk,.tool,.pbtn,.lib-card,.rec,.prow,.schip,.xc,.seg button,.ch-item,.bottomnav button,.theme-opt,.goal-chips button,.lib-chips button,.li';
document.addEventListener('pointerdown', e => {
  if (FXrm() || e.button > 0) return; const h = e.target.closest && e.target.closest(FX_RPL); if (!h || h.disabled || h.closest('.xpt .xg')) return;
  const r = h.getBoundingClientRect(), d = Math.max(r.width, r.height) * 2.2, s = document.createElement('span');
  s.className = 'rpl'; s.style.cssText = `width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px`;
  h.classList.add('rpl-host'); h.appendChild(s); setTimeout(() => s.remove(), 600);
}, { passive: true });
/* পাতা খোলার প্রবেশ-অ্যানিমেশন + সংখ্যা গুনে ওঠা */
const BND2 = '০১২৩৪৫৬৭৮৯';
function countUp(host) {
  const el = host.firstChild && host.firstChild.nodeType === 3 ? host.firstChild : null; if (!el) return;
  const raw = el.textContent.trim(), lat = raw.replace(/[০-৯]/g, d => BND2.indexOf(d)), m = /^(\d+(?:\.\d+)?)$/.exec(lat); if (!m) return;
  const to = +m[1], dec = (m[1].split('.')[1] || '').length, bnOut = /[০-৯]/.test(raw); if (!to) return;
  host.classList.add('cu'); const t0 = performance.now(), D = 700;
  const st = t => { const f = Math.min(1, (t - t0) / D), v = to * (1 - Math.pow(1 - f, 3)); const s = v.toFixed(dec); el.textContent = bnOut ? s.replace(/\d/g, d => BND2[d]) : s; if (f < 1) requestAnimationFrame(st); else el.textContent = raw; };
  requestAnimationFrame(st);
}
let fxT = 0;
function enterFx(quiet) {
  const v = document.getElementById('view'); if (!v) return;
  if (quiet || FXrm()) return;
  clearTimeout(fxT); v.classList.remove('fx-in');
  const w = v.querySelector(':scope>.wrap'); if (!w) return;
  [...w.children].forEach((c, i) => c.style.setProperty('--i', Math.min(i, 10)));
  [...v.querySelectorAll('.prow,.sa,.tool,.qk,.lib-card,.rec,.qcard,.hs-item,.pbtn,.ch-item,.trick,.tile')].slice(0, 18).forEach((c, j) => { c.classList.add('fx-item'); c.style.setProperty('--j', j); });
  void v.offsetWidth; v.classList.add('fx-in');
  v.querySelectorAll('.prog .pct,.lib-n,.lv-badge,.cd-n,.stat-strip .mini>b,.st-big,.big-n').forEach(countUp);
  fxT = setTimeout(() => { v.classList.remove('fx-in'); v.querySelectorAll('.fx-item').forEach(c => c.classList.remove('fx-item')); }, 1300);
}

/* ---------- সম্পূর্ণ সূচিপত্র: সব বিষয় ও অধ্যায়, অনুচ্ছেদ-উপ-অনুচ্ছেদসহ (খোঁজা যায়) ---------- */
VIEWS.toc = ({ q = '' }) => {
  const all = (HSC.chapters || []).filter(c => c.outline && c.outline.length);
  const subs = SUBJ.filter(x => all.some(c => c.subject === x.id));
  const body = () => {
    const ql = (cur.args.q || '').trim();
    const out = subs.map(sb => {
      const chs = all.filter(c => c.subject === sb.id).sort((a, b) => a.order - b.order);
      const html = chs.map(c => {
        let inner = outlineHTML(c);
        if (ql) { const keep = c.outline.filter(o => strip(o[1]).includes(ql)); if (!keep.length) return ''; inner = outlineHTML(Object.assign({}, c, { outline: keep })); }
        const n = c.outline.filter(o => o[0]).length, open = ql || c.id === CH.id, anyS = all.some(x => x.syl);
        if (anyS && S.sylOnly && !c.syl) return '';
        return `<details class="card toc-ch ${anyS && !c.syl ? 'nosyl' : ''}" ${open ? 'open' : ''}><summary><span class="toc-no">${c.no}</span><span class="toc-t"><b>${c.t}</b><small>${sylTag(c, anyS)}${bn(n)}টি অনুচ্ছেদ${c.partial ? ' · সূচি অসম্পূর্ণ' : ''}</small></span><span class="chev">${ico('chev')}</span></summary><div class="toc-bd">${inner}${CHMAP[c.id] && c.id !== CH.id ? `<button class="btn sm" data-act="chOpen" data-id="${c.id}" style="margin-top:8px">${ico('book')}এই অধ্যায় খোলো</button>` : ''}</div></details>`;
      }).join('');
      return html ? `<section class="stack" style="gap:8px"><h2 class="h-sec">${sb.t}</h2>${html}</section>` : '';
    }).join('');
    return out || '<div class="empty">কিছু মেলেনি।</div>';
  };
  return {
    title: 'সম্পূর্ণ সূচিপত্র', nav: 'tools',
    html: `<div class="wrap stack"><div><span class="eyebrow">বইয়ের ক্রম অনুযায়ী</span><h1 class="h-sec">সম্পূর্ণ সূচিপত্র</h1><p class="muted small" style="margin:4px 0 0">অনুচ্ছেদে চাপ দিলে সেই পাঠ খুলবে। “শীঘ্রই” = কাঠামো তৈরি, বিস্তারিত বিষয়বস্তু পরে যোগ হবে।</p></div>
    ${sylBar(all)}
    <div class="search-box">${ico('search', 'muted')}<input id="tocQ" type="search" placeholder="সূচিতে খোঁজো (যেমন: কার্নো, ধারক, প্রাস)" value="${esc(q)}"></div>
    <div id="tocList" class="stack">${body()}</div></div>`,
    after() { const i = $('#tocQ'); i.addEventListener('input', () => { cur.args.q = i.value; $('#tocList').innerHTML = body(); }); }
  };
};
VIEWS.contents = VIEWS.toc;

ACT.sylOnly = b => { S.sylOnly = b.dataset.k === '1'; save(); if (document.querySelector('#sheetWrap')) { ACT.chPickSheet(); return; } render(true); toast(S.sylOnly ? 'শুধু সিলেবাসের অধ্যায় দেখানো হচ্ছে' : 'সব অধ্যায় দেখানো হচ্ছে'); };
