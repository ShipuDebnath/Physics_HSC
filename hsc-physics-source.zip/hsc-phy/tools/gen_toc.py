"""docs/toc.txt থেকে প্রতিটি অধ্যায়ের কাঠামো তৈরি করে (src/chapters/<id>/chapter.js ও content/sNN.js)।

শুধু সেই অধ্যায়গুলো নতুন করে লেখে যেগুলোর content ফোল্ডার এখনো ফাঁকা বা শুধু স্বয়ংক্রিয় খসড়া
(ফাইলের প্রথম লাইনে AUTO-TOC চিহ্ন) — হাতে লেখা কনটেন্ট কখনো মুছে না।
ব্যবহার:  python3 tools/gen_toc.py   তারপর   python3 build.py
"""
import json, os, re, glob
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BN = '০১২৩৪৫৬৭৮৯'
bn = lambda n: ''.join(BN[int(c)] if c.isdigit() else c for c in str(n))
AUTO = '/* AUTO-TOC: docs/toc.txt থেকে তৈরি খসড়া — কনটেন্ট লেখার সময় এই লাইনটি মুছে দাও */'
CATS = {'A': 'মৌলিক ধারণা', 'B': 'সূত্র ও প্রতিপাদন', 'C': 'প্রয়োগ ও গাণিতিক সমস্যা', 'D': 'ব্যবহারিক ও যন্ত্র', 'E': 'পুনরালোচনা'}
END = [('প্রয়োজনীয় গাণিতিক সূত্রাবলি', []), ('বিশ্লেষণাত্মক ও মূল্যায়নধর্মী গাণিতিক সমস্যাবলির সমাধান', []), ('সার-সংক্ষেপ', []),
       ('বহুনির্বাচনি প্রশ্নের উত্তরের জন্য প্রয়োজনীয় বিষয়াবলির সার-সংক্ষেপ', []),
       ('অনুশীলনী', ['(ক) বহুনির্বাচনি প্রশ্ন', '(খ) সৃজনশীল প্রশ্ন', '(গ) সংক্ষিপ্ত-উত্তর প্রশ্ন', '(ঘ) কাঠামোবদ্ধ ও বর্ণনামূলক প্রশ্ন', '(ঙ) ক্রিয়াকর্ম', '(চ) কাজ (গাণিতিক সমস্যা)'])]

def parse():
    chs, ch, sec, les = [], None, None, None
    for raw in open(os.path.join(ROOT, 'docs', 'toc.txt'), encoding='utf-8'):
        line = raw.rstrip('\n')
        if not line.strip() or line.lstrip().startswith('#') and not line.startswith('##'):
            continue
        s = line.strip()
        if s.startswith('@'):
            f = [x.strip() for x in s[1:].split('|')]
            ch = dict(id=f[0], subject=f[1], paper=f[2], no=f[3], order=int(f[4]), t=f[5], en=f[6], partial=f[7] == '1', S=[]); chs.append(ch)
        elif s.startswith('##'):
            f = [x.strip() for x in s[2:].split('|')]
            sec = dict(sym=f[0], cat=f[1], w=int(f[2]), st=f[3], t=f[4], L=[]); ch['S'].append(sec)
        elif s.startswith('- '):
            les = dict(t=s[2:].strip(), sub=[]); sec['L'].append(les)
        elif s.startswith('+ '):
            les['sub'].append(('t', s[2:].strip()))
        elif s.startswith('! '):
            les['sub'].append(('x', s[2:].strip()))
        else:
            raise SystemExit('বুঝতে পারিনি: ' + line)
    return chs

def lesson_html(l):
    subs = [t for k, t in l['sub'] if k == 't']; exs = [t for k, t in l['sub'] if k == 'x']
    h = '<div class="todo-box"><b>এই পাঠের বিস্তারিত বিষয়বস্তু শীঘ্রই যুক্ত হবে</b><span>বইয়ের সূচি অনুযায়ী পাঠটির কাঠামো তৈরি আছে — ব্যাখ্যা, চিত্র, সূত্র, উদাহরণ ও অনুশীলনী পরে যোগ হবে।</span></div>'
    if subs:
        h += '<h4>এই পাঠে যা থাকবে</h4><ul>' + ''.join(f'<li>{t}</li>' for t in subs) + '</ul>'
    if exs:
        h += '<h4>গাণিতিক উদাহরণ</h4><p>' + ', '.join('উদাহরণ ' + x for x in exs) + '</p>'
    return h

def main():
    chs = parse()
    for ch in chs:
        d = os.path.join(ROOT, 'src', 'chapters', ch['id']); cd = os.path.join(d, 'content'); os.makedirs(cd, exist_ok=True)
        own = [f for f in glob.glob(os.path.join(cd, '*.js')) if not open(f, encoding='utf-8').read().startswith(AUTO)]
        secs = ch['S'] + [dict(sym='∑', cat='E', w=3, st='সারসংক্ষেপ ও অনুশীলনী', t='অধ্যায়ের সূত্রাবলি, সার-সংক্ষেপ ও অনুশীলনী', L=[dict(t=t, sub=[('t', x) for x in sub]) for t, sub in END])]
        outline = []
        cno = ''.join(str(BN.index(c)) if c in BN else c for c in ch['no'])
        for k, s in enumerate(secs, 1):
            s['id'] = f"{ch['id']}s{k}"; s['no'] = bn(f'{cno}.{k}')
            outline.append([s['no'], s['t'], 0])
            for j, l in enumerate(s['L'], 1):
                l['id'] = s['id'] + 'abcdefghijklmnopqrstuvwxyz'[j - 1]; l['no'] = bn(f'{cno}.{k}.{j}')
                outline.append([l['no'], l['t'], 1])
                for kind, t in l['sub']:
                    outline.append(['', ('গাণিতিক উদাহরণ ' + t) if kind == 'x' else t, 2])
        desc = ', '.join(s['st'] for s in ch['S'])
        meta = dict(id=ch['id'], subject=ch['subject'], paper=ch['paper'], no=ch['no'], order=ch['order'], t=ch['t'], en=ch['en'], desc=desc, cats=CATS, outline=outline)
        if ch['partial']:
            meta['partial'] = True
        js = f"/* {ch['paper']} · অধ্যায় {ch['no']} · {ch['t']} — সূচি docs/toc.txt থেকে */\nHSC.chapter({json.dumps(meta, ensure_ascii=False)});\n"
        open(os.path.join(d, 'chapter.js'), 'w', encoding='utf-8').write(js)
        if own:
            print(ch['id'], ': হাতে লেখা কনটেন্ট আছে — content ফাইল বদলানো হয়নি'); continue
        for f in glob.glob(os.path.join(cd, '*.js')):
            os.remove(f)
        for k, s in enumerate(secs, 1):
            L = [dict(id=l['id'], no=l['no'], t=l['t'], todo=True, ov=lesson_html(l)) for l in s['L']]
            obj = dict(id=s['id'], no=s['no'], sym=s['sym'], cat=s['cat'], w=s['w'], t=s['t'], st=s['st'],
                       intro='এই অংশে: ' + '; '.join(l['t'] for l in s['L']) + '।', exam={}, L=L, Q={}, F=[], FM=[])
            open(os.path.join(cd, f's{k:02d}.js'), 'w', encoding='utf-8').write(AUTO + '\nSEC.push(' + json.dumps(obj, ensure_ascii=False, indent=1) + ');\n')
        print(ch['id'], ch['t'], ':', len(secs), 'অংশ,', sum(len(s['L']) for s in secs), 'পাঠ')

main()
