const APP = require('path').resolve(__dirname, '../../dist/hsc-physics.html');
const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:375,height:780}});let errs=[];p.on('pageerror',e=>errs.push('PE '+e.message));p.on('console',m=>{if(m.type()==='error'&&!/ERR_TUNNEL|Failed to load resource/.test(m.text()))errs.push('CE '+m.text().slice(0,300))});
await p.goto('file://'+APP);await p.waitForTimeout(2000);
const act=(o)=>p.evaluate(o=>{const b=document.createElement('button');for(const k in o)b.dataset[k]=o[k];document.body.appendChild(b);b.click();b.remove()},o);
const clean=()=>p.evaluate(()=>{const c=document.getElementById('celebrate');c&&c.remove();const s=document.getElementById('sheetWrap');s&&s.remove()});
const V='toc badges chapters compare contents cqLab figures flash formulas games home library mega mistakes practice revision search settings stats study testBuild testHistory tools tricks xp'.split(' ');
const bad=[];const CHS=await p.evaluate(()=>HSC.chapters.map(c=>c.id));
for(const ch of CHS){await act({act:'chOpen',id:ch});await p.waitForTimeout(300);
 for(const v of V){errs=[];await act({act:'go',v});await p.waitForTimeout(200);const t=await p.evaluate(()=>document.querySelector('#tbTitle').textContent);await clean();if(t==='ত্রুটি'||errs.length)bad.push([ch,v,t,errs.join('|').slice(0,300)]);}
 for(const [a,extra] of [['quiz',{id:'daily',mode:'daily'}],['quiz',{id:'wrong',mode:'wrong'}]]){errs=[];await act(Object.assign({act:a},extra));await p.waitForTimeout(200);const t=await p.evaluate(()=>document.querySelector('#tbTitle').textContent);await clean();if(t==='ত্রুটি'||errs.length)bad.push([ch,a+extra.id,t,errs.join('|').slice(0,300)]);}
 errs=[];await act({act:'go',v:'home'});await p.waitForTimeout(200);await p.click('details.sa summary');await p.waitForTimeout(200);await p.click('details.sa[open] .li .ck');await p.waitForTimeout(300);await clean();if(errs.length)bad.push([ch,'ck',errs.join('|')]);
}
console.log(JSON.stringify(bad,null,1));await b.close()})()
