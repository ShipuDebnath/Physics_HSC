const APP = require('path').resolve(__dirname, '../../dist/hsc-physics.html');
const { chromium } = require('playwright');
(async () => {
  const ch = process.argv[2];
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 390, height: 844 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.route(/fonts\.(googleapis|gstatic)/, r => r.abort());
  await p.goto('file://' + APP); await p.waitForTimeout(400);
  const ids = await p.evaluate(ch => APP.LESSONS.filter(l => l.ch === ch).map(l => l.id), ch);
  for (const id of ids) { const n = errs.length; await p.evaluate(id => { const l = APP.LESSONS.find(x => x.id === id); APP.setCh(l.ch); APP.go('lesson', { id }); }, id); await p.waitForTimeout(350); await p.evaluate(() => window.scrollTo(0, document.body.scrollHeight)); await p.waitForTimeout(250); if (errs.length > n) console.log(id, errs.slice(n)); }
  console.log(ch, ids.length, 'lessons; errors', errs.length);
  await b.close();
})();
