/* ═══════════════════════════════════════════════════════════════════════
   CORE · অ্যাপ ইঞ্জিন — সব অধ্যায়ের জন্য একটিই ইঞ্জিন
   পৃষ্ঠা পুরো লোড হলে (DOMContentLoaded) চালু হয়; তাই এই স্ক্রিপ্টের পরে,
   ফাইলের একেবারে শেষে যোগ করা অধ্যায়গুলোও অ্যাপে অন্তর্ভুক্ত হয়।
   ═══════════════════════════════════════════════════════════════════════ */
(function () {
'use strict';
function BOOT() {
const HSC = window.HSC || { chapters: [], problems: [] };
const VIS = window.VIS || {};
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const BN = '০১২৩৪৫৬৭৮৯';
const bn = x => String(x).replace(/\d/g, d => BN[d]);
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const unTex = s => String(s).replace(window.TX && TX.MARK ? new RegExp(TX.MARK.source, 'g') : /\{(?:ce|m|CE|M)\|([^{}]*)\}/g, (_, k, b) => b === undefined ? k : b.replace(/\\(?:frac|dfrac|tfrac)\{([^{}]*)\}\{([^{}]*)\}/g, '($1)/($2)').replace(/\\(?:text|mathrm|ce)\{([^{}]*)\}/g, '$1').replace(/\\[a-zA-Z]+/g, ' ').replace(/[{}_^]/g, '').replace(/->/g, '→').replace(/<=>/g, '⇌'));
const strip = s => unTex(String(s || '')).replace(/<[^>]+>/g, ' ').replace(/&[a-z]+;/g, ' ');
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const pct = x => Math.round(clamp(x, 0, 1) * 100);
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const OL = ['ক', 'খ', 'গ', 'ঘ'];
const DL = { e: 'সহজ', m: 'মাঝারি', h: 'কঠিন' };
window.bn = bn;

/* ---------------- icons ---------------- */
const I = {
  back: '<path d="M15 18l-6-6 6-6"/>', pic: '<rect x="3.5" y="4.5" width="17" height="15" rx="2.2"/><circle cx="9" cy="10" r="1.8"/><path d="M20.5 16l-5-5-8.5 8.5"/>', menu: '<path d="M4 7h16M4 12h16M4 17h10"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/>',
  theme: '<circle cx="12" cy="12" r="8.5"/><path d="M12 3.5v17a8.5 8.5 0 0 0 0-17z" fill="currentColor"/>',
  home: '<path d="M4 11l8-7 8 7v8.5a1 1 0 0 1-1 1h-4.5v-6h-5v6H5a1 1 0 0 1-1-1z"/>',
  book: '<path d="M4 5.5A1.5 1.5 0 0 1 5.5 4H11v16H5.5A1.5 1.5 0 0 1 4 18.5z"/><path d="M20 5.5A1.5 1.5 0 0 0 18.5 4H13v16h5.5a1.5 1.5 0 0 0 1.5-1.5z"/>',
  target: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1" fill="currentColor"/>',
  grid: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
  chart: '<path d="M4 20h16"/><path d="M7 16v-5M12 16V7M17 16v-8"/>',
  bm: '<path d="M7 4h10a1 1 0 0 1 1 1v15l-6-4-6 4V5a1 1 0 0 1 1-1z"/>',
  bmf: '<path d="M7 4h10a1 1 0 0 1 1 1v15l-6-4-6 4V5a1 1 0 0 1 1-1z" fill="currentColor"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>', play: '<path d="M8 5.5v13l10.5-6.5z"/>', pause: '<path d="M8 5v14M16 5v14"/>',
  flask: '<path d="M9.5 3.5h5M10.5 3.5v5.5L5 18.5A1.5 1.5 0 0 0 6.3 21h11.4a1.5 1.5 0 0 0 1.3-2.5L13.5 9V3.5"/><path d="M7.5 15h9"/>',
  bulb: '<path d="M9 18h6M10 21h4"/><path d="M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2V16h5v-.1c0-.8.4-1.5 1-2A6 6 0 0 0 12 3z"/>',
  alert: '<path d="M12 4l9 16H3z"/><path d="M12 10v4.5M12 17.5v.5"/>',
  star: '<path d="M12 4l2.4 5 5.4.6-4 3.7 1.1 5.4L12 16l-4.9 2.7 1.1-5.4-4-3.7 5.4-.6z"/>',
  note: '<path d="M6 3.5h9l4 4V20a.5.5 0 0 1-.5.5h-12A.5.5 0 0 1 6 20z"/><path d="M9 11h6M9 15h6"/>',
  spark: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M18 6l-2.5 2.5M8.5 15.5L6 18"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  fire: '<path d="M12 21c3.6 0 6-2.4 6-5.8 0-3.6-2.7-5.6-3.6-8.7-.3 1.9-1.3 3.1-2.4 3.6.2-2.6-.7-5.1-3-6.6.3 3-1.4 4.8-2.7 6.5A7.2 7.2 0 0 0 6 15.2C6 18.6 8.4 21 12 21z"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>', chev: '<path d="M6 9l6 6 6-6"/>', next: '<path d="M9 6l6 6-6 6"/>', prev: '<path d="M15 6l-6 6 6 6"/>',
  sigma: '<path d="M17 5H7l6 7-6 7h10"/>',
  cards: '<rect x="3.5" y="7" width="13" height="13" rx="2"/><path d="M8 4h10.5a2 2 0 0 1 2 2v10.5"/>',
  repeat: '<path d="M4 12a8 8 0 0 1 13.7-5.6L20 8.5"/><path d="M20 4v4.5h-4.5"/><path d="M20 12a8 8 0 0 1-13.7 5.6L4 15.5"/><path d="M4 20v-4.5h4.5"/>',
  trophy: '<path d="M8 4h8v5a4 4 0 0 1-8 0z"/><path d="M8 6H5a3 3 0 0 0 3 4M16 6h3a3 3 0 0 1-3 4M12 13v4M8.5 20h7M10 17h4"/>',
  pen: '<path d="M4 20l1-4L16 5l3 3L8 19z"/><path d="M14 7l3 3"/>',
  eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>',
  atom: '<circle cx="12" cy="12" r="1.6" fill="currentColor"/><ellipse cx="12" cy="12" rx="9" ry="3.6"/><ellipse cx="12" cy="12" rx="9" ry="3.6" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="9" ry="3.6" transform="rotate(-60 12 12)"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
  hl: '<path d="M4 20h6"/><path d="M14.5 4.5l5 5L11 18H6v-5z"/>',
  trash: '<path d="M5 7h14M10 7V4.5h4V7M7 7l1 13h8l1-13"/>',
  q: '<circle cx="12" cy="12" r="8.5"/><path d="M9.6 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.3-1.1.9-1.1 1.7v.5M12 17v.5"/>',
  layers: '<path d="M12 4l8.5 4.5L12 13 3.5 8.5z"/><path d="M3.5 12.5L12 17l8.5-4.5"/><path d="M3.5 16.5L12 21l8.5-4.5"/>',
  list: '<path d="M9 6h11M9 12h11M9 18h11"/><circle cx="4.5" cy="6" r="1" fill="currentColor"/><circle cx="4.5" cy="12" r="1" fill="currentColor"/><circle cx="4.5" cy="18" r="1" fill="currentColor"/>'
};
const ico = (n, cls = '') => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" class="i ${cls}">${I[n] || ''}</svg>`;
window.ico = ico;

/* ---------------- index ---------------- */
const LMAP = {}, SMAP = {}, MCQ = {}, SECS_ALL = [], LESSONS_ALL = [];
const PROB = HSC.problems || (HSC.problems = []);
const CATS = ['A', 'B', 'C', 'D', 'E'];
const okM = (m, where) => {
  if (Array.isArray(m) && Array.isArray(m[1]) && m[1].length >= 2 && Number.isInteger(m[2]) && m[2] >= 0 && m[2] < m[1].length) return true;
  PROB.push(where + ': MCQ এর গঠন ভুল (অপশনের তালিকা বা উত্তরের সূচক) — বাদ দেওয়া হলো'); return false;
};
(window.SEC || []).forEach(s => {
  if (!s || !s.id) { PROB.push('id ছাড়া একটি অংশ (section) উপেক্ষা করা হলো'); return; }
  if (SMAP[s.id]) { PROB.push(`অংশ id "${s.id}" একাধিকবার আছে — পরেরটি উপেক্ষা করা হলো`); return; }
  if (!CATS.includes(s.cat)) { if (s.cat) PROB.push(`অংশ ${s.id}: cat "${s.cat}" অজানা — 'A' ধরা হলো`); s.cat = 'A'; }
  s.L = (Array.isArray(s.L) ? s.L : []).filter(l => {
    if (!l || !l.id) { PROB.push(`অংশ ${s.id}: id ছাড়া একটি পাঠ উপেক্ষা করা হলো`); return false; }
    if (LMAP[l.id]) { PROB.push(`পাঠ id "${l.id}" একাধিকবার আছে — পরেরটি উপেক্ষা করা হলো`); return false; }
    LMAP[l.id] = l; return true;
  });
  SMAP[s.id] = s; s.si = SECS_ALL.length; SECS_ALL.push(s);
  s.Q = Object.assign({ mcq: [], sq: [], cq: [], bq: [], aq: [], nq: [], hq: [], wp: [] }, s.Q || {});
  s.F = s.F || []; s.FM = s.FM || []; s.exam = s.exam || {};
  s.L.forEach((l, li) => {
    l.sid = s.id; l.li = li; l.ch = s.ch; LESSONS_ALL.push(l);
    (l.v || []).forEach(k => { if (!VIS[k]) PROB.push(`পাঠ ${l.id}: চিত্র "${k}" নিবন্ধিত নেই`); });
  });
  s.allM = [];
  s.Q.mcq.forEach((m, i) => { if (!okM(m, s.id + ' · MCQ ' + (i + 1))) return; const id = s.id + 'm' + i; MCQ[id] = { id, sid: s.id, q: m[0], o: m[1], a: m[2], d: m[3] || 'm', x: m[4] || '', l: m[5] || null }; s.allM.push(id); });
  s.L.forEach(l => (l.xm || []).forEach((m, i) => { if (!okM(m, l.id + ' · অনুশীলনী MCQ ' + (i + 1))) return; const id = l.id + 'x' + i; MCQ[id] = { id, sid: s.id, q: m[0], o: m[1], a: m[2], d: m[3] || 'm', x: m[4] || '', l: l.id }; s.allM.push(id); }));
  s.Q.sq = s.Q.sq.concat(...s.L.map(l => (l.xs || []).map(q => [q[0], q[1], l.id])));
});

/* ---------------- chapters ---------------- */
const CHAPTERS = (HSC.chapters || []).filter(c => SECS_ALL.some(s => s.ch === c.id)).sort((a, b) => (a.paperNo - b.paperNo) || (a.order - b.order));
const SOON = (HSC.chapters || []).filter(c => !CHAPTERS.includes(c));
const CHMAP = {};
CHAPTERS.forEach(c => {
  CHMAP[c.id] = c; c.S = SECS_ALL.filter(s => s.ch === c.id); c.L = [];
  c.S.forEach(s => s.L.forEach(l => { l.gi = c.L.length; c.L.push(l); }));
});
SECS_ALL.filter(s => !CHMAP[s.ch]).forEach(s => PROB.push(`অংশ ${s.id}: অধ্যায় "${s.ch}" পাওয়া যায়নি`));
/* ---------------- subjects (বিষয় → অধ্যায় → উপ-অধ্যায় → পাঠ) ---------------- */
const SUBJ = (HSC.subjects || []).slice();
(HSC.chapters || []).forEach(c => { if (!SUBJ.find(x => x.id === c.subject)) SUBJ.push({ id: c.subject, t: c.paper, order: 99 }); });
SUBJ.forEach(x => { x.chs = CHAPTERS.concat(SOON).filter(c => c.subject === x.id).sort((a, b) => a.order - b.order); x.L = []; x.chs.forEach(c => { if (CHMAP[c.id]) x.L.push(...c.L); }); });
const SUBJECTS = SUBJ.filter(x => x.chs.length).sort((a, b) => a.order - b.order);
const SUBMAP = {}; SUBJECTS.forEach(x => { SUBMAP[x.id] = x; });
const subjOf = c => SUBMAP[c && c.subject] || SUBJECTS[0];
const p2 = x => bn((clamp(x, 0, 1) * 100).toFixed(2));   /* দশমিকের পর দুই ঘর */
const fracL = L => L.length ? L.filter(l => S.done[l.id]).length / L.length : 0;
const CATDEF = { A: 'বিষয়-ক', B: 'বিষয়-খ', C: 'বিষয়-গ', D: 'বিষয়-ঘ', E: 'পুনরালোচনা' };
const catOf = s => { const c = CHMAP[s.ch] || {}; return [s.cat.toLowerCase(), (c.cats || {})[s.cat] || CATDEF[s.cat]]; };
const chLabel = c => `${(SUBMAP[c.subject] || {}).t || c.paper} · অধ্যায় ${c.no}`;
let CH = null, SECS = [], LESSONS = [];
const lessonM = l => SMAP[l.sid].allM.filter(id => MCQ[id].l === l.id);
const BLOCKS = [
  ['ov', 'সহজ ভাষায় ধারণা', 'bulb', 1], ['dp', 'বিশদ ব্যাখ্যা', 'book', 1], ['sc', 'বৈজ্ঞানিক বিশ্লেষণ: সূত্র, উৎপত্তি, গাণিতিক দিক ও ব্যতিক্রম', 'sigma', 1],
  ['fx', 'গুরুত্বপূর্ণ তথ্য', 'star', 1, 'facts'], ['ap', 'বাস্তব জীবনে প্রয়োগ', 'flask'], ['cm', 'সাধারণ ভুল', 'alert', 0, 'warnb'],
  ['tr', 'পরীক্ষার কৌশল', 'target'], ['sn', 'সংক্ষিপ্ত নোট', 'note'], ['mh', 'মনে রাখার কৌশল', 'spark'],
  ['mf', 'MCQ ফোকাস পয়েন্ট', 'check', 0, 'okb'], ['cf', 'CQ ফোকাস পয়েন্ট', 'pen'], ['ho', 'উচ্চতর চিন্তন দক্ষতা (HOTS)', 'q']
];
const RT = {};
function readMin(l) {
  if (RT[l.id]) return RT[l.id];
  let t = '';
  BLOCKS.forEach(([k]) => { const v = l[k]; if (!v) return; t += ' ' + (Array.isArray(v) ? v.map(x => Array.isArray(x) ? x.join(' ') : x).join(' ') : v); });
  const w = strip(t).split(/\s+/).filter(Boolean).length;
  return (RT[l.id] = Math.max(2, Math.round(w / 105)));
}

/* ---------------- state & storage ---------------- */
const KEY = 'hsc-phy-state-v1'; /* পুরোনো নাম রাখা হয়েছে যাতে আগের অগ্রগতি হারিয়ে না যায়; সব অধ্যায়ের অগ্রগতি এখানেই থাকে */
const DEF = () => ({ v: 1, done: {}, bm: {}, notes: {}, hl: {}, qs: {}, quiz: {}, wrong: {}, fc: {}, days: {}, secDays: {}, goal: { l: 3, m: 30 }, mega: null, megaRun: null, megaBy: {}, ch: null, last: null, theme: 'glass', updatedAt: 0 });
let S = DEF();
try { const raw = localStorage.getItem(KEY); if (raw) S = Object.assign(DEF(), JSON.parse(raw)); } catch (e) { }
function save(opts) {
  S.updatedAt = Date.now();
  try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { }
  if (!opts || opts.cloud !== false) cloud.schedule();
}
const cloud = {
  ref: null, busy: false, dirty: false, timer: null, fails: 0, on: false,
  async init() {
    try {
      if (!window.claude || typeof window.claude.use !== 'function') return;
      const [db, user] = await Promise.all([window.claude.use('db'), window.claude.use('user')]);
      if (!db || !user) return;
      const uid = await user.id(); if (!uid) return;
      this.ref = db.doc('data/users/' + uid + '/state');
      const snap = await this.ref.get();
      let remoteAt = 0;
      if (snap.exists) { const d = snap.data(); if (d && d.json) { try { const r = JSON.parse(d.json); remoteAt = r.updatedAt || 0; merge(r); } catch (e) { } } }
      this.on = true; syncBadge();
      if ((S.updatedAt || 0) > remoteAt) this.schedule();
    } catch (e) { this.ref = null; this.on = false; syncBadge(); }
  },
  schedule() { if (!this.ref) return; this.dirty = true; clearTimeout(this.timer); this.timer = setTimeout(() => this.flush(), 2500); },
  async flush() {
    if (!this.ref || this.busy || !this.dirty) return;
    this.busy = true; this.dirty = false;
    try { await this.ref.set({ json: JSON.stringify(S), updatedAt: S.updatedAt }); this.fails = 0; this.on = true; }
    catch (e) {
      const c = e && e.code;
      if (c === 'unavailable' && this.fails < 1) { this.fails++; this.dirty = true; }
      else if (c !== 'unavailable') { this.ref = null; this.on = false; }
    } finally {
      this.busy = false; syncBadge();
      if (this.dirty && this.ref) this.timer = setTimeout(() => this.flush(), 3000 + Math.random() * 2000);
    }
  }
};
function merge(r) {
  const R = Object.assign(DEF(), r);
  const newer = (R.updatedAt || 0) > (S.updatedAt || 0);
  const base = newer ? R : S, other = newer ? S : R;
  base.done = Object.assign({}, other.done, base.done);
  for (const d in other.days) { const a = base.days[d] || {}, b = other.days[d] || {}; base.days[d] = { l: Math.max(a.l || 0, b.l || 0), m: Math.max(a.m || 0, b.m || 0), q: Math.max(a.q || 0, b.q || 0) }; }
  for (const s in other.secDays) base.secDays[s] = Object.assign({}, other.secDays[s], base.secDays[s] || {});
  for (const q in other.qs) { if (!base.qs[q] || (other.qs[q].t || 0) > (base.qs[q].t || 0)) base.qs[q] = other.qs[q]; }
  S = base; S.megaBy = S.megaBy || {};
  try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { }
  CH = null; setCh(S.ch);
  applyTheme(); render(true);
}
function syncBadge() { const d = $('#syncDot'); if (d) { d.classList.toggle('cloud', cloud.on); d.title = cloud.on ? 'অগ্রগতি তোমার অ্যাকাউন্টে সংরক্ষিত হচ্ছে' : 'অগ্রগতি এই ডিভাইসে সংরক্ষিত হচ্ছে'; } }

/* ---------------- dates & activity ---------------- */
const dkey = (d = new Date()) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const daysAgo = k => { const [y, m, d] = k.split('-').map(Number); const a = new Date(y, m - 1, d); const b = new Date(); b.setHours(0, 0, 0, 0); return Math.round((b - a) / 864e5); };
function touch(kind, sid, n = 1, cloudSave = true) {
  const t = dkey(); const d = S.days[t] || (S.days[t] = { l: 0, m: 0, q: 0 });
  d[kind] = (d[kind] || 0) + n;
  if (sid) { (S.secDays[sid] || (S.secDays[sid] = {}))[t] = 1; }
  save({ cloud: cloudSave });
}
function activeDay(d) { return d && ((d.l || 0) > 0 || (d.q || 0) >= 3 || (d.m || 0) >= 5); }
function streak() {
  let n = 0; const now = new Date();
  for (let i = 0; i < 400; i++) {
    const d = new Date(now); d.setDate(now.getDate() - i);
    const k = dkey(d), a = activeDay(S.days[k]) || !!(S.frz && S.frz.used && S.frz.used[k]);
    if (a) n++; else if (i === 0) continue; else break;
  }
  return n;
}
function daysActive(win) { let n = 0; const now = new Date(); for (let i = 0; i < win; i++) { const d = new Date(now); d.setDate(now.getDate() - i); if (activeDay(S.days[dkey(d)])) n++; } return n; }
let lastInteract = Date.now();
['pointerdown', 'keydown', 'scroll', 'touchstart'].forEach(e => addEventListener(e, () => { lastInteract = Date.now(); }, { passive: true }));
setInterval(() => {
  if (document.visibilityState === 'visible' && Date.now() - lastInteract < 120000) {
    const sid = cur && cur.args && (cur.args.sid || (cur.args.id && LMAP[cur.args.id] && LMAP[cur.args.id].sid));
    touch('m', sid || null, 0.5, false);
    const m = $('#todayMin'); if (m) m.textContent = bn(Math.round(S.days[dkey()].m)) + '/' + bn(S.goal.m);
  }
}, 30000);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') { cloud.dirty = true; cloud.flush(); } });

/* ---------------- stats ---------------- */
function secStats(s) {
  const total = s.L.length, done = s.L.filter(l => S.done[l.id]).length, comp = total ? done / total : 0;
  let att = 0, cor = 0, n = s.allM.length;
  for (const id of s.allM) { const r = S.qs[id]; if (r) { att++; if (r.last) cor++; } }
  const acc = att ? cor / att : 0, cov = n ? Math.min(1, att / Math.max(1, n * 0.6)) : 0;
  const mastery = Math.round(100 * (n ? 0.3 * comp + 0.7 * acc * cov : comp));
  const qz = S.quiz[s.id] || null;
  const minsLeft = s.L.filter(l => !S.done[l.id]).reduce((a, l) => a + readMin(l), 0) + (qz || !n ? 0 : 8);
  const days = Object.keys(S.secDays[s.id] || {});
  const last7 = days.filter(d => daysAgo(d) < 7).length;
  return { total, done, rem: total - done, comp, att, cor, acc, n, mastery, quiz: qz ? qz.last : null, best: qz ? qz.best : null, tries: qz ? qz.n : 0, minsLeft, days: days.length, last7 };
}
function globalStats() {
  const total = LESSONS.length, done = LESSONS.filter(l => S.done[l.id]).length;
  let m = 0, att = 0, cor = 0; SECS.forEach(s => { const st = secStats(s); m += st.mastery; att += st.att; cor += st.cor; });
  return { total, done, pct: total ? Math.round(done / total * 100) : 0, mastery: SECS.length ? Math.round(m / SECS.length) : 0, acc: att ? Math.round(cor / att * 100) : 0, att };
}

function chStats(c) { const t = c.L.length, d = c.L.filter(l => S.done[l.id]).length; return { t, d, pct: t ? Math.round(d / t * 100) : 0 }; }
/* বর্তমান অধ্যায় বদলানো — মেগা টেস্টের ফলাফল প্রতিটি অধ্যায়ের জন্য আলাদা রাখা হয় */
function setCh(id) {
  const c = CHMAP[id] || CHAPTERS[0]; if (!c || CH === c) return;
  S.megaBy = S.megaBy || {};
  const owner = S.ch || c.id;
  if (owner !== c.id) { S.megaBy[owner] = { m: S.mega, r: S.megaRun }; const b = S.megaBy[c.id] || {}; S.mega = b.m || null; S.megaRun = b.r || null; delete S.megaBy[c.id]; }
  S.ch = c.id; CH = c; SECS = c.S; LESSONS = c.L; FC = null; S.chBy = S.chBy || {}; S.chBy[c.subject] = c.id;
}
const wrongIds = () => Object.keys(S.wrong).filter(id => MCQ[id] && SMAP[MCQ[id].sid].ch === CH.id);

/* ---------------- theme ---------------- */
const THEMES = [
  ['glass', 'গ্লাস অরোরা', 'স্বচ্ছ কাচ, ধীরে ভেসে চলা রঙিন অরোরা — ডিফল্ট', ['linear-gradient(135deg,#8FB8FF,#C9A8FF)', 'linear-gradient(135deg,#FFB3D6,#FFD9A8)', 'rgba(255,255,255,.75)', '#0071E3']],
  ['aurora', 'অরোরা নাইট', 'রাতের আকাশে মেরুজ্যোতি — গাঢ় কাচ', ['linear-gradient(135deg,#0B1530,#1B1050)', 'linear-gradient(135deg,#2EE8AA,#7A5CFF)', 'rgba(22,28,52,.8)', '#6EE7C8'], 2],
  ['sunset', 'সানসেট', 'গোধূলির উষ্ণ কমলা-গোলাপি কাচ', ['linear-gradient(135deg,#FFB070,#FF6E9A)', 'linear-gradient(135deg,#FFD978,#B47CFF)', 'rgba(255,255,255,.75)', '#D9480F'], 3],
  ['neon', 'নিয়ন ল্যাব', 'অন্ধকার ল্যাবে সায়ান-ম্যাজেন্টা নিয়ন', ['#06060D', '#0E0F1C', '#22E5FF', '#FF4FD8'], 4],
  ['vanilla', 'ভ্যানিলা', 'উষ্ণ কাগজের মতো, দীর্ঘ পড়ার জন্য', ['#F7F3EA', '#FFFDF8', '#1F4E8C', '#A86400']],
  ['ocean', 'লাইট ওশান', 'শীতল নীলাভ, উজ্জ্বল আলোয়', ['#EDF5F7', '#FFFFFF', '#0B6E8A', '#C0430D']],
  ['sakura', 'সাকুরা', 'নরম গোলাপি ও প্লাম, কোমল উষ্ণতা', ['#FBF0F3', '#FFFFFF', '#B0275A', '#6A4BA8']],
  ['matcha', 'মাচা', 'সবুজ চায়ের হালকা রং, প্রশান্ত', ['#EDF1E4', '#FBFCF7', '#3D6B21', '#8A4B14']],
  ['contrast', 'হাই কনট্রাস্ট', 'সাদা-কালো, মোটা রেখা, সর্বোচ্চ পাঠযোগ্যতা', ['#FFFFFF', '#000000', '#0033CC', '#FFE600']],
  ['dark', 'মডার্ন ডার্ক', 'নিরপেক্ষ গাঢ়, রাতে ও OLED স্ক্রিনে আরাম', ['#0E0F13', '#16181E', '#8DB6FF', '#FFB65C']],
  ['lagoon', 'লেগুন গ্লাস', 'ফিরোজা-পুদিনা জলের মতো স্বচ্ছ কাচ — চোখে শীতল', ['linear-gradient(135deg,#63E6BE,#74C0FC)', 'linear-gradient(135deg,#99E9F2,#FFE066)', 'rgba(255,255,255,.75)', '#0A7EA4']],
  ['cherry', 'চেরি ব্লসম', 'বসন্তের গোলাপি-পিচ কাচ, ভাসমান পাপড়ির আলো', ['linear-gradient(135deg,#FF92B4,#FFC8A0)', 'linear-gradient(135deg,#FFB4C8,#C896FF)', 'rgba(255,255,255,.75)', '#C2185B'], 5],
  ['galaxy', 'গ্যালাক্সি', 'তারাভরা মহাকাশ ও নীহারিকার আভা — গাঢ় কাচ', ['linear-gradient(135deg,#05040F,#2A1660)', 'linear-gradient(135deg,#7C3AED,#EC4899)', 'rgba(20,16,44,.8)', '#A78BFA'], 6],
  ['emerald', 'পান্না রাত', 'গাঢ় সবুজ কাচে সোনালি ঝিলিক', ['linear-gradient(135deg,#03140F,#0B3D2E)', 'linear-gradient(135deg,#10B981,#FCD34D)', 'rgba(10,40,32,.8)', '#34D399'], 8],
];
/* নিচের বারের ২য় বোতাম: সংরক্ষিত (ডিফল্ট) বা অধ্যায় */
const navSlot = () => (S.nav2 === 'chapter' ? 'chapter' : 'saved');
function navSlotHTML() { return navSlot() === 'chapter' ? `<button data-act="go" data-v="chapters" data-n="chapter">${ico('book')}<span>অধ্যায়</span></button>` : `<button data-act="go" data-v="library" data-n="saved">${ico('star')}<span>সংরক্ষিত</span></button>`; }
const strikeOn = () => !!(S.set && S.set.strike);
function strikeOpts() { const k = strikeOn() ? 'on' : 'off'; return `<div class="goal-chips">${[['off', 'বন্ধ'], ['on', '<s>স্ট্রাইক</s> চালু']].map(([v, n]) => `<button type="button" class="${k === v ? 'on' : ''}" data-act="strikeSet" data-k="${v}">${n}</button>`).join('')}</div>`; }
function applyStrike() { document.documentElement.toggleAttribute('data-strike', strikeOn()); }
function navSlotOpts() { const k = navSlot(); return `<div class="goal-chips">${[['saved', '★ সংরক্ষিত'], ['chapter', '📖 অধ্যায়']].map(([v, n]) => `<button type="button" class="${k === v ? 'on' : ''}" data-act="navSlot" data-k="${v}">${n}</button>`).join('')}</div>`; }
const GLASSY = new Set(['glass', 'aurora', 'sunset', 'lagoon', 'cherry', 'galaxy', 'emerald']);
const themeLock = k => 0; /* সব থিম সবসময় খোলা */
const themeOpen = k => { const lv = themeLock(k); if (!lv) return true; try { return xpInfo().L >= lv; } catch (e) { return true; } };
const TH_OK = new Set(THEMES.map(t => t[0]));
/* থিম বেছে না নিলে ডিভাইস/অ্যাপের আলো-অন্ধকার অনুযায়ী ভ্যানিলা বা ডার্ক */
function themeKey() {
  if (TH_OK.has(S.theme) && themeOpen(S.theme)) return S.theme;
  if (S.theme === 'forest') return 'dark';
  return 'glass';
}
function applyTheme() {
  const r = document.documentElement;
  const k = themeKey(); r.setAttribute('data-skin', k); if (GLASSY.has(k)) r.setAttribute('data-glass', ''); else r.removeAttribute('data-glass');
  const m = $('meta[name="theme-color"]'); const cs = getComputedStyle(document.body);
  let bg = cs.getPropertyValue('--surface').trim(); if (/rgba|transparent/.test(bg)) bg = cs.getPropertyValue('--bg').trim();
  if (m && bg) m.setAttribute('content', bg);
}
try {  } catch (e) { }

/* ---------------- shell ---------------- */
const app = document.getElementById('app');
if (!CHAPTERS.length) { app.innerHTML = '<div style="padding:24px;font:16px system-ui,sans-serif">কোনো অধ্যায় লোড হয়নি। ফাইলে অন্তত একটি <code>HSC.chapter({...})</code> ও <code>SEC.push({...})</code> থাকতে হবে।</div>'; console.warn('[HSC]', PROB); return; }
app.innerHTML = `
<header class="topbar">
  <button class="icon-btn" id="btnBack" data-act="back" aria-label="পিছনে">${ico('back')}</button>
  <button class="icon-btn" id="btnMenu" data-act="drawer" aria-label="অধ্যায় তালিকা">${ico('menu')}</button>
  <div class="tb-title"><small><span class="sync-dot" id="syncDot"></span><span id="tbEye">HSC পদার্থবিজ্ঞান</span></small><strong id="tbTitle">রসায়ন সহায়িকা</strong></div>
  <button class="icon-btn" data-act="go" data-v="search" aria-label="খোঁজো">${ico('search')}</button>
  <button class="icon-btn" data-act="themeSheet" aria-label="থিম বদলাও">${ico('theme')}</button>
</header>
<div class="readbar"><i id="readBar"></i></div>
<div class="shell">
  <div class="scrim" id="scrim" data-act="drawer"></div>
  <aside class="drawer" id="drawer" aria-label="অধ্যায় তালিকা"></aside>
  <main class="main" id="view" tabindex="-1"></main>
</div>
<nav class="bottomnav" id="bnav" aria-label="প্রধান নেভিগেশন">
  <button data-act="go" data-v="home" data-n="home">${ico('home')}<span>হোম</span></button>
  ${navSlotHTML()}
  <button data-act="go" data-v="practice" data-n="practice">${ico('target')}<span>অনুশীলন</span></button>
  <button data-act="go" data-v="tools" data-n="tools">${ico('grid')}<span>টুলস</span></button>
  <button data-act="go" data-v="stats" data-n="stats">${ico('chart')}<span>অগ্রগতি</span></button>
</nav>
<div class="hlbar" id="hlbar" hidden><div class="in" id="hlIn"></div></div>
<div class="toast" id="toast" role="status"></div>`;
const viewEl = $('#view');

let toastT;
function toast(msg, actLabel, actFn) {
  const t = $('#toast'); t.innerHTML = `<span>${msg}</span>` + (actLabel ? `<button id="toastAct">${actLabel}</button>` : '');
  t.classList.add('on'); clearTimeout(toastT);
  if (actLabel) $('#toastAct').onclick = () => { t.classList.remove('on'); actFn && actFn(); };
  toastT = setTimeout(() => t.classList.remove('on'), actLabel ? 6000 : 2600);
}

/* drawer */
function renderDrawer() {
  const d = $('#drawer'), sb = subjOf(CH), f = fracL(sb.L);
  const openSec = cur && ((cur.args.sid && SMAP[cur.args.sid]) || (cur.args.id && LMAP[cur.args.id] && SMAP[LMAP[cur.args.id].sid]));
  d.innerHTML = `<div class="drawer-head">${subjChip()}<div class="dh-row"><h3>অধ্যায়</h3><span class="pp">${p2(f)}%</span></div>${bar(f * 100, 'thin')}</div>
  <div class="drawer-body">${sb.chs.map(c => {
    if (!CHMAP[c.id]) return `<div class="dj-ch soon"><button ${c.outline ? `data-act="outline" data-id="${c.id}"` : 'disabled'}><span class="dj-no">${c.no}</span><span class="dj-t">${c.t}<small>শীঘ্রই আসছে</small></span></button></div>`;
    const cf = fracL(c.L), open = c === CH;
    return `<div class="dj-ch ${open ? 'open' : ''}"><button data-act="djToggle"><span class="dj-no">${c.no}</span><span class="dj-t">${c.t}<span class="bar thin"><i style="width:${cf * 100}%"></i></span></span><span class="dj-pct">${p2(cf)}%</span><span class="dj-chev">${ico('chev')}</span></button>
    <div class="dj-secs"><button class="dj-home" data-act="chOpen" data-id="${c.id}">${ico('home')}<b>অধ্যায়ের হোম</b></button>${c.S.map(x => { const sf = secStats(x).comp; return `<button class="${openSec === x ? 'on' : ''}" data-act="sec" data-id="${x.id}"><span class="dj-sno">${x.cat === 'E' ? '★' : x.no}</span><span class="dj-st">${x.t}</span><span class="dj-spct">${p2(sf)}%</span></button>`; }).join('')}</div></div>`;
  }).join('')}</div>`;
}
function toggleDrawer(force) {
  if (matchMedia('(min-width:1080px)').matches) return;
  const on = force != null ? force : !$('#drawer').classList.contains('on');
  $('#drawer').classList.toggle('on', on); $('#scrim').classList.toggle('on', on);
  if (on) renderDrawer();
}

/* ---------------- router ---------------- */
let cur = null; const stack = [];
const NOPERSIST = { quiz: 1, megaA: 1 };   /* বাকি সব পাতা মনে রাখা হয় — আবার খুললে সেখান থেকেই শুরু */
const TOP = !!(window.top === window.self);
function go(name, args = {}, opts = {}) {
  if (cur && !opts.replace) { cur.args.y = window.scrollY; stack.push(cur); if (stack.length > 40) stack.shift(); }
  SEL = null;
  cur = { name, args: Object.assign({}, args) };
  if (TOP && !opts.replace) { try { history.pushState({ d: stack.length }, ''); } catch (e) { } }
  render();
  toggleDrawer(false);
}
function back() { const p = stack.pop(); cur = p || { name: 'home', args: {} }; render(false, true); }
if (TOP) addEventListener('popstate', () => { if (stack.length) back(); });
function chOfArgs(a) {
  if (!a) return null;
  const s = SMAP[a.sid] || SMAP[a.id] || (LMAP[a.id] && SMAP[LMAP[a.id].sid]);
  return s ? s.ch : (a.ch && CHMAP[a.ch] ? a.ch : null);
}
let cleanups = [];
function render(keepScroll, restoring) {
  cleanups.forEach(f => { try { f(); } catch (e) { } }); cleanups = [];
  const want = chOfArgs(cur.args); if (want && want !== CH.id) setCh(want);
  const V = VIEWS[cur.name] || VIEWS.home;
  const y = keepScroll ? window.scrollY : (cur.args.y || 0);
  let out;
  try { out = V(cur.args); } catch (e) { console.error(e); out = { title: 'ত্রুটি', html: `<div class="wrap"><div class="empty">এই পাতাটি খুলতে সমস্যা হয়েছে। হোমে ফিরে চেষ্টা করো।</div></div>` }; }
  $('#tbTitle').textContent = out.title || CH.t;
  $('#tbEye').textContent = out.eye || chLabel(CH);
  $('#btnBack').style.display = cur.name === 'home' ? 'none' : '';
  viewEl.innerHTML = out.html;
  if (cur.name === 'lesson' && cur.args.id && LMAP[cur.args.id]) { if (!LVW || LVW.id !== cur.args.id) LVW = { id: cur.args.id, t0: Date.now(), sc: 0 }; const r = (S.rl || []).filter(x => x !== cur.args.id && LMAP[x]); r.unshift(cur.args.id); S.rl = r.slice(0, 6); }
  let nav = out.nav || cur.name; if (nav === 'chapter' && navSlot() !== 'chapter') nav = 'home'; if (nav === 'saved' && navSlot() !== 'saved') nav = 'tools';
  $$('#bnav button').forEach(b => b.classList.toggle('on', b.dataset.n === nav));
  $('#readBar').style.width = '0';
  if (out.after) out.after();
  mountFigs();
  if (matchMedia('(min-width:1080px)').matches) renderDrawer();
  requestAnimationFrame(() => window.scrollTo(0, (keepScroll || restoring || cur.args.y) ? y : 0));
  if (!NOPERSIST[cur.name]) { const a = {}; for (const k in cur.args) if (k !== 'y' && cur.args[k] != null && typeof cur.args[k] !== 'object') a[k] = cur.args[k]; a.ch = CH.id; S.last = { name: cur.name, args: a, y: (keepScroll || restoring) ? Math.round(y) : 0 }; if (cur.name === 'lesson') S.lastL = cur.args.id; save({ cloud: !keepScroll }); }
  hideHl();
  try { selBar(); } catch (e) { }
  try { enterFx(keepScroll); } catch (e) { }
}
let scrollT;
addEventListener('scroll', () => {
  if (!cur) return;
  if (cur.name === 'lesson') {
    const h = document.documentElement.scrollHeight - innerHeight;
    $('#readBar').style.width = (h > 0 ? clamp(scrollY / h, 0, 1) * 100 : 0) + '%';
  }
  clearTimeout(scrollT);
  scrollT = setTimeout(() => { if (cur && !NOPERSIST[cur.name] && S.last) { S.last.y = Math.round(scrollY); save({ cloud: false }); } }, 400);
}, { passive: true });

/* ---------------- figures (visuals) ---------------- */
const VTYPE = { '2d': '২D চিত্র', '3d': '৩D মডেল', 'anim': 'অ্যানিমেশন', 'int': 'ইন্টারঅ্যাকটিভ', 'calc': 'ক্যালকুলেটর', 'info': 'ইনফোগ্রাফিক' };
/* চিত্রসূচি: প্রতিটি অধ্যায়ের চিত্র প্রথম ব্যবহারের ক্রমে নম্বর পায় (চিত্র ৪.৩) */
function figList(c) {
  if (!c || !c.L) return [];
  if (c._figs) return c._figs;
  const out = [], seen = {};
  c.L.forEach(l => (l.v || []).forEach(k => { if (!VIS[k] || seen[k]) return; seen[k] = 1; out.push({ k, l, n: out.length + 1 }); }));
  return (c._figs = out);
}
let FIGNO = null;
function figNo(key) {
  if (!FIGNO) { FIGNO = {}; CHAPTERS.forEach(c => figList(c).forEach(f => { FIGNO[f.k] = 'চিত্র ' + c.no + '.' + bn(f.n); })); }
  return FIGNO[key] || '';
}
function figHTML(key) {
  const v = VIS[key]; if (!v) return '';
  let body = ''; try { body = typeof v.html === 'function' ? v.html() : (v.html || ''); } catch (e) { console.error(e); }
  return `<figure class="fig" data-vis="${key}" style="margin:0"><div class="fig-head">${figNo(key) ? `<span class="fig-no">${figNo(key)}</span>` : ''}<b>${v.t}</b>${(v.k || []).map(k => `<span class="chip ${k === '3d' || k === 'anim' ? 'acc' : ''}">${VTYPE[k] || k}</span>`).join('')}${svBtn('v', key)}</div><div class="fig-body">${body}</div>${v.cap ? `<figcaption class="fig-cap">${v.cap}</figcaption>` : ''}</figure>`;
}
function withFigs(html) { return String(html || '').replace(/\{\{v:([\w-]+)\}\}/g, (_, k) => figHTML(k)); }
let figIO = null;
function mountFigs() {
  if (figIO) figIO.disconnect();
  const figs = $$('.fig[data-vis]', viewEl).filter(f => VIS[f.dataset.vis] && VIS[f.dataset.vis].mount && !f._m);
  if (!figs.length) return;
  const start = f => { if (f._m) return; f._m = 1; try { const c = VIS[f.dataset.vis].mount(f.querySelector('.fig-body'), f); if (typeof c === 'function') cleanups.push(c); } catch (e) { console.error(e); } };
  if (!('IntersectionObserver' in window)) { figs.forEach(start); return; }
  figIO = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { start(e.target); figIO.unobserve(e.target); } }), { rootMargin: '300px 0px' });
  figs.forEach(f => figIO.observe(f));
  cleanups.push(() => figIO && figIO.disconnect());
}
window.APP_mountFigs = mountFigs;

/* ---------------- shared bits ---------------- */
function ring(p, size = 132, stroke = 11, label = '') {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r;
  return `<div class="score-ring" style="width:${size}px;height:${size}px"><svg viewBox="0 0 ${size} ${size}"><circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="var(--surface-3)" stroke-width="${stroke}"/><circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="var(--accent)" stroke-width="${stroke}" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - clamp(p, 0, 100) / 100)}"/></svg><div class="ring-in"><b>${bn(Math.round(p))}%</b>${label ? `<br><span>${label}</span>` : ''}</div></div>`;
}
const bar = (p, cls = '') => `<div class="bar ${cls}"><i style="width:${clamp(p, 0, 100)}%"></i></div>`;
function listHTML(v) {
  if (!v) return '';
  if (Array.isArray(v)) return `<ul class="pts">${v.map(x => `<li>${x}</li>`).join('')}</ul>`;
  return withFigs(v);
}
function qaHTML(items, prefix = '') {
  return items.map((it, i) => `<div class="qa"><div class="q">${prefix ? `<b>${prefix}${bn(i + 1)}.</b> ` : ''}${it[0]}</div><button class="btn sm soft reveal-btn" data-act="reveal">${ico('eye')}উত্তর দেখো</button><div class="ans" hidden>${it[1]}</div></div>`).join('');
}
function tileHTML(s, extra = '') {
  const st = secStats(s);
  return `<button class="tile cat-${catOf(s)[0]} ${st.comp === 1 ? 'done' : ''}" data-act="sec" data-id="${s.id}" ${extra} aria-label="${s.no} ${s.t}"><span class="tn"><span>${s.no}</span><span>${bn(st.mastery)}</span></span><span class="sym">${s.sym}</span><span class="tt">${s.st || s.t}</span><span class="tb"><i style="width:${st.comp * 100}%"></i></span></button>`;
}
/* বিষয় বাছাই */
function subjChip() {
  const sb = subjOf(CH);
  return `<button class="ch-chip" data-act="subjSheet" aria-label="বিষয় বদলাও"><span class="ch-no">বিষয়</span><span class="ch-t" style="color:var(--fg)">${sb.t}</span>${ico('chev')}</button>`;
}
const chChip = subjChip;
function subjPills() {
  if (SUBJECTS.length < 2) return '';
  const on = subjOf(CH);
  return `<div class="subj-pills" role="tablist" aria-label="বিষয়">${SUBJECTS.map(x => `<button role="tab" class="${x === on ? 'on' : ''}" data-act="subj" data-id="${x.id}"><b>${x.t}</b><small>${x.L.length ? p2(fracL(x.L)) + '%' : 'শীঘ্রই'}</small></button>`).join('')}</div>`;
}
function catLegend() {
  const used = new Set(SECS.map(s => s.cat));
  return CATS.filter(k => used.has(k)).map(k => { const c = k.toLowerCase(); return `<span class="cat-${c}"><i></i>${(CH.cats || {})[k] || CATDEF[k]}</span>`; }).join('');
}
/* বইয়ের পূর্ণ সূচিপত্র (অধ্যায় ঘোষণার outline থেকে) — কোন অনুচ্ছেদ লেখা হয়েছে আর কোনটি আসছে */
function outlineHTML(c) {
  const ol = c.outline || []; if (!ol.length) return '';
  const secBy = {}, lesBy = {};
  if (CHMAP[c.id]) { c.S.forEach(s => { if (s.no && !secBy[s.no]) secBy[s.no] = s; }); c.L.forEach(l => { if (l.no && !lesBy[l.no]) lesBy[l.no] = l; }); }
  const wr = (l, s) => l ? !l.todo : s ? s.L.some(x => !x.todo) : false;
  const done = ol.filter(([n]) => n && wr(lesBy[n], secBy[n])).length, tot = ol.filter(([n]) => n).length;
  return `<div class="small muted" style="margin:0 0 8px">লেখা হয়েছে ${bn(done)}/${bn(tot)}টি অনুচ্ছেদ${c.partial ? ' · <b>সূচি অসম্পূর্ণ — বাকি অনুচ্ছেদ পরে যোগ হবে</b>' : ''}</div><div class="ol-list">${ol.map(([n, t, lv]) => {
    const l = n && lesBy[n], s = n && secBy[n], ok = !!(l || s), w = wr(l, s);
    const inner = `<span class="ol-no">${n || (lv >= 2 ? '·' : '•')}</span><span class="ol-t">${t}</span>${n ? `<span class="ol-st ${w ? 'ok' : ''}">${w ? ico('check') : 'শীঘ্রই'}</span>` : ''}`;
    return ok ? `<button class="ol-row lv${lv}" data-act="${l ? 'lesson' : 'sec'}" data-id="${(l || s).id}">${inner}</button>` : `<div class="ol-row lv${lv} todo">${inner}</div>`;
  }).join('')}</div>`;
}
function chSheetHTML() {
  const groups = [...new Set(SUBJECTS.map(x => x.group || x.t))];
  return `<h2 class="h-card" style="margin-bottom:4px">বিষয় বেছে নাও</h2><p class="small muted" style="margin:0 0 12px">প্রতিটি বিষয় ও অধ্যায়ের অগ্রগতি আলাদাভাবে সংরক্ষিত থাকে।</p>
  ${groups.map(gname => `<div class="eyebrow" style="margin:10px 0 6px">${gname}</div><div class="ch-list">${SUBJECTS.filter(x => (x.group || x.t) === gname).map(x => {
    const f = fracL(x.L), on = x === subjOf(CH);
    return `<button class="ch-item ${on ? 'on' : ''}" data-act="subj" data-id="${x.id}"><span class="ch-n">${ico('book')}</span><span class="ch-b"><b>${x.t}</b><small>${bn(x.chs.filter(c => CHMAP[c.id]).length)}/${bn(x.chs.length)}টি অধ্যায় · ${bn(x.L.length)}টি পাঠ · সম্পন্ন ${p2(f)}%</small><span class="bar thin" style="margin-top:6px"><i style="width:${f * 100}%"></i></span></span>${on ? ico('check') : ico('next')}</button>`;
  }).join('')}</div>`).join('')}
  <button class="btn block" style="margin-top:14px" data-act="closeSheet">বন্ধ করো</button>`;
}
function greet() { const h = new Date().getHours(); return h < 5 ? 'শুভ রাত্রি' : h < 12 ? 'শুভ সকাল' : h < 16 ? 'শুভ দুপুর' : h < 19 ? 'শুভ বিকেল' : 'শুভ সন্ধ্যা'; }
const MON = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
const WD = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];
const dateBn = (d = new Date()) => `${WD[d.getDay()]}, ${bn(d.getDate())} ${MON[d.getMonth()]} ${bn(d.getFullYear())}`;

/* ---------------- views ---------------- */
const VIEWS = {};

const lastLesson = () => { const id = S.lastL || (S.last && S.last.name === 'lesson' && S.last.args.id); return id && LMAP[id]; };
function resumeCard(L, scope) {
  const last = lastLesson(), inScope = last && (!L || L.includes(last));
  const l = inScope ? last : (L || LESSONS).find(x => !S.done[x.id]);
  if (!l) return `<div class="card"><b>অভিনন্দন!</b> ${scope || 'এই অংশের'} সব পাঠ শেষ। এখন মেগা টেস্ট দিয়ে নিজেকে যাচাই করো।</div>`;
  const c = CHMAP[l.ch];
  return `<button class="card resume raised" data-act="lesson" data-id="${l.id}" style="text-align:left;color:inherit"><span class="ico">${ico(inScope ? 'repeat' : 'play')}</span>
    <span class="txt"><span class="small muted">${inScope ? 'যেখানে থেমেছিলে' : 'পরের পাঠ'} · অধ্যায় ${c.no} · ${SMAP[l.sid].no}</span><b>${l.no ? l.no + ' ' : ''}${l.t}</b><span class="small muted">${bn(readMin(l))} মিনিট পড়া${S.done[l.id] ? ' · সম্পন্ন' : ''}</span></span>${ico('next')}</button>`;
}
function progCard(f, done, tot, extra) {
  return `<section class="prog"><div class="prog-top"><div><div class="lbl">সম্পন্ন</div><div class="pct">${p2(f)}<small>%</small></div></div><div class="lbl" style="text-align:right">${bn(done)}/${bn(tot)} পাঠ${extra ? '<br>' + extra : ''}</div></div>${bar(f * 100)}</section>`;
}
function prow(o) {
  return `<button class="prow ${o.cls || ''}" ${o.attrs}><span class="pr-no">${o.no}</span><span class="pr-b"><span class="pr-t">${o.t}</span><span class="pr-m">${o.meta}</span>${o.f == null ? '' : `<span class="bar thin"><i style="width:${o.f * 100}%"></i></span>`}</span><span class="pr-p">${o.f == null ? (o.tag || '') : p2(o.f) + '%'}</span>${ico('next')}</button>`;
}

function chRows(sb) {
  return `<div class="prows">${sb.chs.map(c => CHMAP[c.id]
    ? prow({ no: c.no, t: c.t, meta: `${bn(c.S.length)}টি উপ-অধ্যায় · ${bn(c.L.length)}টি পাঠ`, f: fracL(c.L), cls: c === CH ? 'cur' : '', attrs: `data-act="chOpen" data-id="${c.id}"` })
    : prow({ no: c.no, t: c.t, meta: c.outline ? `শীঘ্রই আসছে · সূচিপত্রে ${bn(c.outline.filter(o => o[0]).length)}টি অনুচ্ছেদ` : 'শীঘ্রই আসছে', tag: 'শীঘ্রই', cls: 'soon', attrs: c.outline ? `data-act="outline" data-id="${c.id}"` : 'disabled' })).join('')}</div>`;
}
function chPick() {
  return `<button class="ch-pick" data-act="chPickSheet" aria-label="অধ্যায় বদলাও"><span class="cp-no">${CH.no}</span><span class="cp-b"><small>অধ্যায় · ${subjOf(CH).t}</small><b>${CH.t}</b></span>${ico('chev')}</button>`;
}
VIEWS.home = () => {
  const c = CH, f = fracL(LESSONS), done = LESSONS.filter(l => S.done[l.id]).length, g = globalStats(), td = S.days[dkey()] || {}, sk = streak();
  const lp = Math.round(clamp((td.l || 0) / S.goal.l, 0, 1) * 100), mp = Math.round(clamp((td.m || 0) / S.goal.m, 0, 1) * 100);
  const last = lastLesson(), openSid = last && last.ch === c.id ? last.sid : null;
  const tools = [['figures', 'pic', 'চিত্রসূচি', `${bn(figList(c).length)}টি চিত্র ও সিমুলেশন`], ['formulas', 'sigma', 'ফর্মুলা শিট', 'সব সূত্র এক জায়গায়'], ['flash', 'cards', 'ফ্ল্যাশকার্ড', 'দ্রুত মুখস্থ যাচাই'], ['mega', 'trophy', 'মেগা টেস্ট', 'পূর্ণ অধ্যায় মূল্যায়ন'], ['compare', 'layers', 'পার্থক্য সারণি', 'ধারণার তুলনা'], ['revision', 'repeat', 'রিভিশন মোড', 'নোট ও তথ্য']];
  return {
    title: c.t, eye: chLabel(c), nav: 'home',
    html: `<div class="wrap stack">
    <div class="hello"><span class="date">${dateBn()}</span><h1 class="h-display">${greet()}!</h1></div>
    ${subjPills()}
    ${chPick()}
    ${resumeCard(LESSONS, 'এই অধ্যায়ের')}
    ${progCard(f, done, LESSONS.length, `গড় মাস্টারি ${bn(g.mastery)}% · MCQ নির্ভুলতা ${bn(g.acc)}%`)}
    <div class="stat-strip">
      <div class="mini">${ico('fire', 'muted')}<b>${bn(sk)}</b><span>দিনের ধারাবাহিকতা</span></div>
      <button type="button" class="mini goal-tile" data-act="goalSheet" aria-label="দৈনিক পাঠ লক্ষ্য বদলাও"><b>${bn(td.l || 0)}/${bn(S.goal.l)}</b><span>আজকের পাঠ লক্ষ্য ✎</span>${bar(lp, 'thin a2')}</button>
      <button type="button" class="mini goal-tile" data-act="goalSheet" aria-label="দৈনিক মিনিট লক্ষ্য বদলাও"><b id="todayMin">${bn(Math.round(td.m || 0))}/${bn(S.goal.m)}</b><span>আজ পড়ার মিনিট ✎</span>${bar(mp, 'thin')}</button>
    </div>
    <section class="stack" style="gap:8px"><div class="ptable-head"><h2 class="h-sec">উপ-অধ্যায়</h2><span class="sp"></span>${selBtn()}</div>
    <div class="sec-acc">${SECS.map(x => { const st = secStats(x); return `<details class="sa ${st.done === st.total && st.total ? 'all-done' : ''}" data-sid="${x.id}" ${x.id === openSid ? 'open' : ''}><summary><span class="pr-no">${x.cat === 'E' ? '★' : x.no}</span><span class="pr-b"><span class="pr-t">${x.t}</span><span class="pr-m">${bn(st.done)}/${bn(st.total)} পাঠ · মাস্টারি ${bn(st.mastery)}%</span><span class="bar thin"><i style="width:${st.comp * 100}%"></i></span></span><span class="pr-p">${p2(st.comp)}%</span><span class="chev">${ico('chev')}</span></summary>
      <div class="sa-body"><div class="lesson-list">${x.L.map(lessonRow).join('')}</div><div class="sa-acts">${secDoneBtn(x)}<button class="btn sm" data-act="sec" data-id="${x.id}">${ico('target')}উপ-অধ্যায়ের পাতা · কুইজ ও প্রশ্নব্যাংক</button></div></div></details>`; }).join('')}</div></section>
    <section class="stack" style="gap:8px"><h2 class="h-sec">এই অধ্যায়ের টুলস</h2>
      <div class="tools">${tools.map(([v, i, t, sub]) => `<button class="tool" data-act="go" data-v="${v}"><span class="ti">${ico(i)}</span><span><b>${t}</b><small>${sub}</small></span></button>`).join('')}</div></section>
    ${c.outline ? `<details class="card" style="padding:14px"><summary style="cursor:pointer;font-weight:700">বইয়ের পূর্ণ সূচিপত্র (অনুচ্ছেদ নম্বরসহ)</summary><div style="margin-top:10px">${outlineHTML(c)}</div></details>` : ''}
    </div>`
  };
};
VIEWS.chapters = () => {
  const sb = subjOf(CH), f = fracL(sb.L), done = sb.L.filter(l => S.done[l.id]).length;
  return {
    title: 'অধ্যায়সমূহ', eye: 'HSC · ' + sb.t, nav: 'chapter',
    html: `<div class="wrap stack"><div><span class="eyebrow">বিষয়</span><h1 class="h-sec">${sb.t}</h1></div>
    ${subjPills()}
    ${progCard(f, done, sb.L.length, `${bn(sb.chs.filter(c => CHMAP[c.id]).length)}/${bn(sb.chs.length)}টি অধ্যায় প্রকাশিত`)}
    <section class="stack" style="gap:8px"><h2 class="h-sec">অধ্যায়</h2>${chRows(sb)}</section></div>`
  };
};
VIEWS.chapter = VIEWS.home; VIEWS.contents = VIEWS.home;
/* পাঠ পড়া হয়েছে চিহ্ন: বৃত্তে চাপ দিলে টগল; নির্বাচন মোডে একাধিক পাঠ একসাথে */
let SEL = null, LVW = null;
const starN = w => clamp(Math.round(w > 5 ? w / 2 : w), 1, 5);
function lessonRow(l) {
  const other = l.ch !== CH.id && CHMAP[l.ch] ? 'অধ্যায় ' + CHMAP[l.ch].no + ' · ' : '';
  const on = SEL && SEL.has(l.id);
  return `<button class="li ${SEL ? 'selm' : ''} ${on ? 'sel' : ''} ${S.done[l.id] ? 'is-done' : ''}" data-act="${SEL ? 'selPick' : 'lesson'}" data-id="${l.id}">${SEL ? `<span class="selbox" aria-hidden="true">${on ? ico('check') : ''}</span>` : ''}<span class="ck ${S.done[l.id] ? 'on' : (S.self || {})[l.id] ? 'self' : ''}" ${SEL ? '' : `data-act="ckToggle" data-id="${l.id}" role="button" title="পড়া শেষ? যাচাই করো" aria-label="পড়া শেষ চিহ্ন — যাচাই করো"`}></span><span class="no">${l.no || ''}</span><span class="t"><span class="tt">${l.t}</span><small>${other}${bn(readMin(l))} মিনিট${S.done[l.id] ? ' · আয়ত্ত ✓' : (S.self || {})[l.id] ? ' · পড়েছি, যাচাই বাকি' : ''}${S.bm[l.id] ? ' · বুকমার্ক' : ''}${S.notes[l.id] ? ' · নোট আছে' : ''}</small></span></button>`;
}
function selBtn() { return SEL ? `<button class="btn sm primary" data-act="selEnd">${ico('check')}নির্বাচন শেষ</button>` : `<button class="btn sm" data-act="selStart">${ico('check')}নির্বাচন করে চিহ্নিত</button>`; }
function secDoneBtn(x) {
  const ids = x.L.map(l => l.id);
  if (SEL) { const all = ids.every(i => SEL.has(i)); return `<button class="btn sm ${all ? 'soft' : ''}" data-act="selSec" data-id="${x.id}">${ico('layers')}${all ? 'সব বাদ দাও' : 'এই উপ-অধ্যায়ের সব নির্বাচন'}</button>`; }
  const all = ids.length && ids.every(i => S.done[i]);
  return `<button class="btn sm ${all ? 'soft' : ''}" data-act="secDone" data-id="${x.id}">${ico('check')}${all ? 'আয়ত্ত ✓ (চিহ্ন মুছো)' : 'উপ-অধ্যায় শেষ? যাচাই করো'}</button>`;
}

VIEWS.section = ({ sid }) => {
  const s = SMAP[sid]; if (!s) return VIEWS.home();
  const st = secStats(s);
  const qn = s.Q;
  const counts = `MCQ ${bn(s.allM.length)} · সংক্ষিপ্ত ${bn(qn.sq.length)} · সৃজনশীল ${bn(qn.cq.length)} · অন্যান্য ${bn(qn.bq.length + qn.aq.length + qn.nq.length + qn.hq.length)}`;
  const ex = s.exam || {};
  return {
    title: s.t, eye: s.cat === 'E' ? catOf(s)[1] : 'অধ্যায় ' + CH.no + ' · অংশ ' + s.no, nav: 'home',
    html: `<div class="wrap stack">
    <div class="sec-head">${tileHTML(s, 'tabindex="-1"')}<div style="min-width:0"><span class="eyebrow">${catOf(s)[1]}</span><h1 class="h-sec">${s.cat === 'E' ? '' : s.no + ' '}${s.t}</h1>${s.w ? `<div class="stars" title="পরীক্ষায় গুরুত্ব">${'★'.repeat(starN(s.w))}${'☆'.repeat(5 - starN(s.w))} <span class="small muted">পরীক্ষায় গুরুত্ব</span></div>` : ''}</div></div>
    ${s.intro ? `<p class="lead" style="margin:0">${s.intro}</p>` : ''}
    <div class="kv">
      <div><b>${bn(st.total)}</b><span>মোট পাঠ</span></div><div><b>${bn(st.done)}</b><span>সম্পন্ন</span></div>
      <div><b>${bn(st.rem)}</b><span>বাকি</span></div><div><b>${bn(pct(st.comp))}%</b><span>সম্পন্নের হার</span>${bar(st.comp * 100, 'thin ok')}</div>
      <div><b>${bn(st.mastery)}%</b><span>মাস্টারি</span>${bar(st.mastery, 'thin')}</div><div><b>${st.quiz == null ? '—' : bn(st.quiz) + '%'}</b><span>কুইজ স্কোর${st.best != null ? ' (সেরা ' + bn(st.best) + '%)' : ''}</span></div>
      <div><b>${bn(st.minsLeft)}<small style="font-size:13px"> মি.</small></b><span>আনুমানিক সময় বাকি</span></div><div><b>${bn(st.last7)}/৭</b><span>গত ৭ দিনে চর্চা</span></div>
    </div>
    <section class="stack" style="gap:8px"><div class="ptable-head"><h2 class="h-card">পাঠসমূহ</h2><span class="sp"></span>${selBtn()}</div><div class="sa-acts" style="margin:0">${secDoneBtn(s)}</div><div class="lesson-list">${s.L.map(lessonRow).join('')}</div></section>
    ${s.allM.length ? `<section class="stack" style="gap:8px"><h2 class="h-card">অনুশীলন</h2>
    <div class="practice-grid">
      <button class="pbtn hero" data-act="quiz" data-id="${s.id}" data-mode="adaptive"><b>অ্যাডাপটিভ কুইজ</b><small>তোমার উত্তরের সাথে কঠিনতা বদলায় · ${bn(Math.min(10, s.allM.length))} প্রশ্ন</small></button>
      <button class="pbtn" data-act="bank" data-id="${s.id}"><b>প্রশ্নব্যাংক</b><small>${counts}</small></button>
      <button class="pbtn" data-act="bank" data-id="${s.id}" data-tab="wp"><b>লিখিত অনুশীলন</b><small>জ্ঞানমূলক → উচ্চতর দক্ষতামূলক · আলোচ্য বিষয় · পাঠের লিংক</small></button>
      <button class="pbtn" data-act="go" data-v="flash" data-sid="${s.id}"><b>ফ্ল্যাশকার্ড</b><small>${bn(s.F.length)}টি কার্ড</small></button>
    </div>
    <div class="row"><span class="small muted">নির্দিষ্ট কঠিনতায় কুইজ:</span><button class="btn sm" data-act="quiz" data-id="${s.id}" data-mode="e">সহজ</button><button class="btn sm" data-act="quiz" data-id="${s.id}" data-mode="m">মাঝারি</button><button class="btn sm" data-act="quiz" data-id="${s.id}" data-mode="h">কঠিন</button></div></section>` : ''}
    ${(ex.pat || ex.board) ? `<section class="stack" style="gap:8px"><h2 class="h-card">পরীক্ষা বিশ্লেষণ</h2>
      ${ex.pat ? `<details class="blk" open><summary><span class="bi">${ico('list')}</span>বিগত প্রশ্নের ধরন<span class="chev">${ico('chev')}</span></summary><div class="bd">${listHTML(ex.pat)}</div></details>` : ''}
      ${ex.board ? `<details class="blk"><summary><span class="bi">${ico('chart')}</span>বোর্ড প্রশ্ন বিশ্লেষণ<span class="chev">${ico('chev')}</span></summary><div class="bd">${listHTML(ex.board)}</div></details>` : ''}
    </section>` : ''}
    ${s.FM.length ? `<section class="stack" style="gap:8px"><h2 class="h-card">এই অংশের সূত্র</h2>${formulaCards(s.FM, s)}</section>` : ''}
    </div>`
  };
};
function formulaCards(fm, s) {
  return fm.map(f => `<div class="card" style="padding:12px 14px"><div class="row" style="flex-wrap:nowrap"><div class="small muted" style="flex:1">${f[0]}</div>${s && s.FM.indexOf(f) >= 0 ? svBtn('x', s.id + '#' + s.FM.indexOf(f)) : ''}</div><div class="eq" style="margin:.4em 0 .3em">${f[1]}</div>${f[2] ? `<div class="small muted">${f[2]}</div>` : ''}</div>`).join('');
}

VIEWS.lesson = ({ id, find }) => {
  const l = LMAP[id]; if (!l) return VIEWS.home();
  const s = SMAP[l.sid];
  const prev = LESSONS[l.gi - 1], next = LESSONS[l.gi + 1];
  const v = (l.v || []).map(figHTML).join('');
  const blocks = BLOCKS.map(([k, label, icon, open, cls]) => {
    let val = l[k]; if (!val || (Array.isArray(val) && !val.length)) return '';
    let body = k === 'ho' ? qaHTML(val) : listHTML(val);
    if (k === 'ov' && v) body += `<div class="stack" style="gap:12px;margin:14px 0 4px">${v}</div>`;
    if (k === 'mh') body += `<div class="row" style="gap:6px;margin-top:10px"><button type="button" class="btn sm ${S.trk && S.trk[l.id] ? 'soft' : ''}" data-act="trk" data-k="${l.id}">${ico('check')}${S.trk && S.trk[l.id] ? 'মনে আছে' : 'মনে রাখলাম'}</button>${svBtn('t', l.id, 'ট্রিক সংরক্ষণ')}<span class="sp"></span><button type="button" class="btn sm ghost" data-act="go" data-v="tricks">${ico('bulb')}সব ট্রিকস</button></div>`;
    return `<details class="blk ${cls || ''}" ${open ? 'open' : ''} data-k="${k}"><summary><span class="bi">${ico(icon)}</span>${label}<span class="chev">${ico('chev')}</span></summary><div class="bd prose">${body}</div></details>`;
  }).join('');
  const done = !!S.done[l.id];
  const isLastInSec = l.li === s.L.length - 1;
  return {
    title: l.t, eye: s.no + ' ' + (s.st || s.t), nav: 'home',
    html: `<div class="wrap stack">
    <div class="crumb"><button data-act="sec" data-id="${s.id}">${s.no} ${s.st || s.t}</button><span>›</span><span>পাঠ ${bn(l.li + 1)}/${bn(s.L.length)}</span></div>
    <div><h1 class="lesson-title">${l.no ? `<span class="mono" style="font-size:.6em;color:var(--muted);display:block">${l.no}</span>` : ''}${l.t}</h1></div>
    <div class="lesson-meta"><span class="chip">${ico('clock')}${bn(readMin(l))} মিনিট পড়া</span>${done ? '<span class="chip ok">সম্পন্ন</span>' : ''}
      <span class="sp"></span><button class="btn sm ${S.bm[l.id] ? 'soft' : ''}" data-act="bm" data-id="${l.id}" aria-pressed="${!!S.bm[l.id]}">${ico(S.bm[l.id] ? 'bmf' : 'bm')}${S.bm[l.id] ? 'বুকমার্ক করা' : 'বুকমার্ক'}</button></div>
    <div class="small muted">টিপস: লেখার কোনো অংশ নির্বাচন করলে নিচে হাইলাইট বোতাম আসবে।</div>
    <article class="lesson-body stack" id="lessonBody" data-id="${l.id}">${blocks}</article>
    ${exHTML(l)}
    <section class="card notes-box stack" style="gap:8px"><div class="row"><b>${ico('pen', 'muted')} আমার নোট</b><span class="sp"></span><span class="saved" id="noteSaved">${S.notes[l.id] ? 'সংরক্ষিত' : ''}</span></div>
      <textarea id="note-${l.id}" data-note="${l.id}" placeholder="এই পাঠ নিয়ে নিজের ভাষায় লেখো — স্বয়ংক্রিয়ভাবে সংরক্ষণ হবে">${esc(S.notes[l.id] || '')}</textarea></section>
    <button class="btn block ${done ? 'done-btn on' : 'primary'}" data-act="done" data-id="${l.id}">${ico('check')}${done ? 'সম্পন্ন হয়েছে · আবার অসম্পন্ন করো' : 'পাঠ সম্পন্ন হিসেবে চিহ্নিত করো'}</button>
    ${isLastInSec && s.allM.length ? `<button class="pbtn hero" data-act="quiz" data-id="${s.id}" data-mode="adaptive"><b>অংশ ${s.no} শেষ! এবার অ্যাডাপটিভ কুইজ</b><small>${bn(Math.min(10, s.allM.length))}টি প্রশ্ন · তাৎক্ষণিক ব্যাখ্যা ও রিপোর্ট</small></button>` : ''}
    <div class="lesson-nav">
      ${prev ? `<button class="btn" data-act="lesson" data-id="${prev.id}">${ico('prev')}<span><small>আগের পাঠ</small>${prev.t}</span></button>` : '<span></span>'}
      ${next ? `<button class="btn next" data-act="lesson" data-id="${next.id}"><span><small>পরের পাঠ</small>${next.t}</span>${ico('next')}</button>` : '<span></span>'}
    </div></div>`,
    after() {
      const body = $('#lessonBody');
      (S.hl[l.id] || []).forEach(h => typeof h === 'string' ? findAndWrap(body, h, 'hl') : findAndWrap(body, h.t, 'hl hl-' + (h.c || 'y')));
      if (find) {
        const m = findAndWrap(body, find, 'find');
        if (m) { const d = m.closest('details'); if (d) d.open = true; setTimeout(() => m.scrollIntoView({ block: 'center', behavior: 'smooth' }), 120); setTimeout(() => { if (m.parentNode) { m.replaceWith(...m.childNodes); } }, 6000); }
      }
      const ta = $('textarea[data-note]'); let nt;
      ta.addEventListener('input', () => { clearTimeout(nt); $('#noteSaved').textContent = 'লেখা হচ্ছে…'; nt = setTimeout(() => { const v = ta.value.trim(); if (v) S.notes[l.id] = ta.value; else delete S.notes[l.id]; touch('m', l.sid, 0, true); $('#noteSaved').textContent = 'সংরক্ষিত'; }, 700); });
    }
  };
};

/* ---------- Lesson exercise ---------- */
function exHTML(l, open) {
  const ms = lessonM(l), xs = l.xs || [];
  if (!ms.length && !xs.length) return '';
  return `<details class="blk okb" ${open ? 'open' : ''} data-k="ex" id="lx"><summary><span class="bi">${ico('target')}</span>পাঠ অনুশীলনী — ${bn(ms.length)}টি MCQ ও ${bn(xs.length)}টি সংক্ষিপ্ত প্রশ্ন<span class="chev">${ico('chev')}</span></summary><div class="bd stack" style="gap:10px">
    <p class="small muted" style="margin:10px 0 0">পুরো পাঠের প্রতিটি গুরুত্বপূর্ণ বিষয় থেকে প্রশ্ন। উত্তরে চাপ দিলেই ব্যাখ্যা দেখাবে। <b id="lxScore"></b></p>
    ${ms.length ? `<h4 style="margin:4px 0 0">বহুনির্বাচনী প্রশ্ন (MCQ)</h4>${qPager(ms.map((id, i) => mcqHTML(MCQ[id], i)), 'lxp')}<div class="row"><span class="small muted">সব MCQ মুছে নতুন করে চেষ্টা করতে চাও?</span><span class="sp"></span><button class="btn sm" data-act="lxReset" data-id="${l.id}">${ico('repeat')}আবার করো</button></div>` : ''}
    ${xs.length ? `<h4 style="margin:6px 0 0">সংক্ষিপ্ত প্রশ্ন</h4><div class="card" style="padding:4px 14px">${qaHTML(xs, '')}</div>` : ''}
  </div></details>`;
}
function exScore() {
  const box = $('#lx'); if (!box) return;
  const cards = $$('.qcard[data-q]', box), done = cards.filter(c => c.dataset.done), ok = done.filter(c => c.querySelector('.opt.right') && !c.querySelector('.opt.wrong'));
  const el = $('#lxScore'); if (el && done.length) el.textContent = `তোমার স্কোর: ${bn(ok.length)}/${bn(done.length)} (মোট ${bn(cards.length)})`;
}

/* ---------- Question bank ---------- */
const BTABS = [['mcq', 'MCQ'], ['sq', 'সংক্ষিপ্ত'], ['cq', 'সৃজনশীল'], ['bq', 'বোর্ড ধাঁচ'], ['aq', 'প্রয়োগমূলক'], ['nq', 'বিশ্লেষণধর্মী'], ['hq', 'HOTS'], ['wp', 'লিখিত অনুশীলন']];
/* MCQ pager: one-by-one (default) or all at once — choice remembered in S.mcqMode */
function qPager(items, id) {
  const one = (S.mcqMode || 'one') === 'one', n = items.length;
  return `<div class="qpager${one ? ' one' : ''}" id="${id}" data-i="0">
    <div class="row qp-top"><div class="seg qp-seg" role="group" aria-label="MCQ দেখানোর ধরন"><button type="button" data-act="qpMode" data-m="one" class="${one ? 'on' : ''}">একটি করে</button><button type="button" data-act="qpMode" data-m="all" class="${one ? '' : 'on'}">সব একসাথে</button></div><span class="sp"></span><span class="small muted qp-pos">${one ? `প্রশ্ন ${bn(1)}/${bn(n)}` : `${bn(n)}টি প্রশ্ন`}</span></div>
    <div class="qp-dots" ${one ? '' : 'hidden'}>${items.map((_, k) => `<button type="button" data-act="qpGo" data-k="${k}" class="${k ? '' : 'on'}" aria-label="প্রশ্ন ${bn(k + 1)}">${bn(k + 1)}</button>`).join('')}</div>
    ${items.map((h, k) => `<div class="qp-item" data-k="${k}" ${one && k ? 'hidden' : ''}>${h}</div>`).join('')}
    <div class="row qp-nav" ${one ? '' : 'hidden'}><button type="button" class="btn" data-act="qpStep" data-d="-1" disabled>${ico('back')}আগের</button><span class="sp"></span><button type="button" class="btn primary" data-act="qpStep" data-d="1" ${n > 1 ? '' : 'disabled'}>পরের${ico('next')}</button></div></div>`;
}
function qpShow(pg, i, scroll) {
  const items = $$('.qp-item', pg), n = items.length; i = clamp(i, 0, n - 1); pg.dataset.i = i;
  const one = pg.classList.contains('one');
  items.forEach((el, k) => { el.hidden = one && k !== i; });
  $$('.qp-dots button', pg).forEach((b, k) => b.classList.toggle('on', k === i));
  const nav = $$('.qp-nav button', pg); if (nav.length) { nav[0].disabled = i <= 0; nav[1].disabled = i >= n - 1; }
  const pos = $('.qp-pos', pg); if (pos) pos.textContent = one ? `প্রশ্ন ${bn(i + 1)}/${bn(n)}` : `${bn(n)}টি প্রশ্ন`;
  if (one && scroll) { const top = pg.getBoundingClientRect().top; if (top < 60 || top > innerHeight * 0.5) pg.scrollIntoView({ block: 'start', behavior: 'smooth' }); }
}
function qpMark(card, ok) {
  const it = card.closest('.qp-item'), pg = card.closest('.qpager'); if (!it || !pg) return;
  const d = $$('.qp-dots button', pg)[+it.dataset.k]; if (d) d.classList.add(ok ? 'ok' : 'bad');
}
function qpApplyMode() {
  const one = (S.mcqMode || 'one') === 'one';
  $$('.qpager').forEach(pg => { pg.classList.toggle('one', one); $$('.qp-seg button', pg).forEach(b => b.classList.toggle('on', b.dataset.m === (one ? 'one' : 'all'))); $('.qp-dots', pg).hidden = !one; $('.qp-nav', pg).hidden = !one; qpShow(pg, +pg.dataset.i || 0, false); });
}
function mcqHTML(m, idx, opts = {}) {
  return `<div class="qcard" data-q="${m.id}"><div class="qhead"><span class="chip">${opts.label || 'প্রশ্ন ' + bn(idx + 1)}</span><span class="chip ${m.d}">${DL[m.d]}</span>${m.l && LMAP[m.l] ? `<span class="chip">${LMAP[m.l].no || ''}</span>` : ''}${S.wrong[m.id] ? '<span class="chip bad">আগে ভুল</span>' : ''}<span class="sp"></span>${svBtn('m', m.id)}</div>
  <div class="qtext">${m.q}</div><div class="opts">${m.o.map((o, i) => `<button class="opt" data-act="${opts.act || 'pmcq'}" data-q="${m.id}" data-i="${i}"><span class="ol">${OL[i]}</span><span>${o}</span></button>`).join('')}</div><div class="fb"></div></div>`;
}
function recordQ(id, ok) {
  const r = S.qs[id] || { c: 0, w: 0 };
  if (ok) r.c++; else r.w++; r.last = ok ? 1 : 0; r.t = Date.now(); S.qs[id] = r;
  if (ok) delete S.wrong[id]; else S.wrong[id] = 1;
  touch('q', MCQ[id] && MCQ[id].sid);
}
const RK = {};
const STOPW = new Set(['নিচের', 'কোনটি', 'সঠিক', 'হলো', 'কাকে', 'বলে', 'যায়', 'হয়', 'প্রায়', 'একটি', 'থাকে', 'করে', 'জন্য', 'থেকে', 'সাথে', 'কোন', 'কত', 'কেন', 'যদি', 'তবে', 'এবং', 'অথবা', 'বিক্রিয়ায়', 'নির্ণয়', 'সমান', 'উপযুক্ত', 'ব্যবহৃত']);
function readRef(m) {
  if (RK[m.id]) return RK[m.id];
  const toks = strip(m.o[m.a] + ' ' + m.q + ' ' + (m.x || '')).replace(/<[^>]+>/g, ' ').split(/[^ঀ-৿A-Za-z0-9₀-₉⁰-⁹⁺⁻]+/).map(t => t.trim()).filter(t => t.length >= 3 && !STOPW.has(t) && !/^[০-৯0-9.]+$/.test(t));
  const s = SMAP[m.sid]; const cand = m.l && LMAP[m.l] ? [LMAP[m.l]] : (s ? s.L : []);
  let best = null, bs = -1, kw = '';
  cand.forEach(l => { const tx = strip([l.t, l.ov, l.dp, (l.fx || []).join(' '), l.sc].join(' ')); let sc = 0, k = ''; toks.forEach(t => { if (tx.includes(t)) { sc++; if (t.length > k.length) k = t; } }); if (sc > bs) { bs = sc; best = l; kw = k; } });
  let fact = '';
  if (best) { let fb = 0; [].concat(best.fx || [], best.mh || []).forEach(f => { const t = strip(f); let sc = 0; toks.forEach(k => { if (t.includes(k)) sc += k.length; }); if (sc > fb) { fb = sc; fact = f; } }); if (fb < 6) fact = ''; }
  return (RK[m.id] = { l: best, kw, fact });
}
/* লিখিত অনুশীলন: নম্বর বণ্টন থেকে শুধু আলোচ্য বিষয়গুলো, আর প্রাসঙ্গিক পাঠের লিংক */
function wpPoints(sch, ans) {
  const clean = t => strip(t).replace(/\([^)]*\)/g, ' ').replace(/নম্বর/g, ' ').replace(/[~×≈]/g, ' ').replace(/(^|\s)[০-৯0-9.]+(?=\s|$)/g, ' ').replace(/(^|\s)(প্রতিটি|প্রত্যেকটি|সঠিক|যেকোনো)(?=\s)/g, ' ').replace(/\s+/g, ' ').trim();
  const out = sch ? strip(sch).split(/\s*\+\s*/).map(clean).filter(t => t.length > 1) : [];
  const m = /<table/.test(ans || '') ? [...ans.matchAll(/<tr>\s*<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/g)].slice(1).map(x => strip(x[1]).replace(/<[^>]+>/g, '').trim()).filter(Boolean) : [];
  if (m.length) out.push('তুলনার দিক: ' + m.join(', '));
  return [...new Set(out)];
}
/* বোর্ডের চার স্তর: জ্ঞানমূলক (ক), অনুধাবনমূলক (খ), প্রয়োগমূলক (গ), উচ্চতর দক্ষতামূলক (ঘ) */
const WPL = [['ক', 'জ্ঞানমূলক', 'সংজ্ঞা, নাম, তথ্য মনে রাখা'], ['খ', 'অনুধাবনমূলক', 'কারণ ব্যাখ্যা, বুঝে লেখা'], ['গ', 'প্রয়োগমূলক', 'হিসাব, সমীকরণ, নতুন পরিস্থিতিতে প্রয়োগ'], ['ঘ', 'উচ্চতর দক্ষতামূলক', 'বিশ্লেষণ, তুলনা, মূল্যায়ন ও সিদ্ধান্ত']];
function wpLevel(w, i, n) {
  if (n !== 5) return Math.min(3, Math.floor(i * 4 / Math.max(1, n)));
  if (i === 2) return /নির্ণয়|হিসাব|গণনা|প্রতিপাদন|সমীকরণ|ব্যবহার করে|প্রয়োগ|পরিমাণ|কত/.test(strip(w[1])) ? 2 : 1;
  return [0, 1, 1, 2, 3][i];
}
function wpRefs(s, w) {
  const toks = strip(w[1] + ' ' + w[2] + ' ' + (w[3] || '')).replace(/<[^>]+>/g, ' ').split(/[^ঀ-৿A-Za-z0-9₀-₉⁰-⁹⁺⁻]+/).map(t => t.trim()).filter(t => t.length >= 3 && !STOPW.has(t) && !/^[০-৯0-9.]+$/.test(t));
  const qt = strip(w[1]).replace(/<[^>]+>/g, ' ');
  const sc = s.L.map(l => { const tx = strip([l.t, l.ov, l.dp, (l.fx || []).join(' '), l.sc].join(' ')); let n = 0, k = ''; toks.forEach(t => { if (tx.includes(t)) { n += qt.includes(t) ? 2 : 1; if (qt.includes(t) && t.length > k.length) k = t; } }); return [l, k, n]; }).sort((a, b) => b[2] - a[2]);
  if (!sc.length || !sc[0][2]) return [];
  return sc.filter((x, i) => i === 0 || x[2] >= sc[0][2] * 0.75).slice(0, 3);
}
function readLink(m) { const r = readRef(m); return r.l ? `<button class="linkbtn small" data-act="lesson" data-id="${r.l.id}"${r.kw ? ` data-find="${esc(r.kw)}"` : ''}>${ico('book')}পড়ো: ${r.l.no || ''} ${r.l.t}</button>` : ''; }
function feedbackHTML(m, pick) {
  const ok = pick === m.a;
  const r = readRef(m), lt = r.l;
  const read = lt ? `<div class="fb-read">${ico('book')}<span><b>বিস্তারিত পড়ো:</b> <button class="linkbtn" data-act="lesson" data-id="${lt.id}"${r.kw ? ` data-find="${esc(r.kw)}"` : ''}>${lt.no || ''} ${lt.t}</button>${r.kw ? ` <span class="muted">— "${esc(r.kw)}" অংশে নিয়ে যাবে</span>` : ''}</span></div>` : '';
  return `<div class="feedback ${ok ? 'ok' : 'bad'}"><b>${ok ? `✓ সঠিক! (${OL[m.a]}) ${m.o[m.a]}` : `✗ ভুল হয়েছে — সঠিক উত্তর (${OL[m.a]}) ${m.o[m.a]}`}</b>${m.x ? `<div><b style="display:inline">ব্যাখ্যা:</b> ${m.x}</div>` : ''}${r.fact && strip(r.fact) !== strip(m.x || '') ? `<div class="small" style="margin-top:4px"><b style="display:inline">💡 মনে রাখো:</b> ${r.fact}</div>` : ''}
  ${!ok ? `<div class="small" style="margin-top:6px"><b style="display:inline">ভুলের বিশ্লেষণ:</b> তুমি (${OL[pick]}) ${m.o[pick]} বেছে নিয়েছ — কিন্তু সঠিক হলো (${OL[m.a]})। নিচের পাঠে ধারণাটি আরেকবার দেখে নাও।</div>` : ''}${read}</div>`;
}
VIEWS.bank = ({ id, tab = 'mcq', diff = 'all' }) => {
  const s = SMAP[id]; if (!s) return VIEWS.home();
  const Q = s.Q;
  let body = '';
  if (tab === 'mcq') {
    const list = s.allM.map(id => MCQ[id]).filter(m => diff === 'all' || m.d === diff);
    body = `<div class="row"><div class="seg">${[['all', 'সব'], ['e', 'সহজ'], ['m', 'মাঝারি'], ['h', 'কঠিন']].map(([k, n]) => `<button class="${diff === k ? 'on' : ''}" data-act="bankDiff" data-d="${k}">${n}</button>`).join('')}</div><span class="small muted">উত্তরে চাপ দিলে সাথে সাথে ব্যাখ্যা</span></div>
    ${list.length ? qPager(list.map((m, i) => mcqHTML(m, i)), 'bkp') : '<div class="empty">এই কঠিনতায় প্রশ্ন নেই।</div>'}`;
  } else if (tab === 'cq') {
    body = Q.cq.map((c, i) => cqHTML(c, i, { svk: s.id + '#' + i })).join('') || '<div class="empty">শীঘ্রই যুক্ত হবে।</div>';
  } else if (tab === 'wp') {
    const card = w => { const pts = wpPoints(w[3], w[2]), refs = wpRefs(s, w); return `<div class="qcard"><div class="qtext">${w[1]}</div>
      ${pts.length ? `<div class="wp-pts"><b>${ico('layers')}যা যা আলোচনা করবে</b><ul>${pts.map(t => `<li>${t}</li>`).join('')}</ul></div>` : ''}
      ${refs.length ? `<div class="fb-read wp-read">${ico('book')}<span><b>বিস্তারিত পড়ো:</b> ${refs.map(([l, kw]) => `<button class="linkbtn" data-act="lesson" data-id="${l.id}"${kw ? ` data-find="${esc(kw)}"` : ''}>${l.no || ''} ${l.t}</button>`).join(' · ')}</span></div>` : ''}
      <button class="btn sm soft reveal-btn" data-act="reveal">${ico('eye')}মডেল উত্তর দেখো</button><div class="ans" hidden>${w[2]}</div></div>`; };
    const G = [[], [], [], []]; Q.wp.forEach((w, i) => G[wpLevel(w, i, Q.wp.length)].push(w));
    body = Q.wp.length ? `<p class="small muted" style="margin:0">বোর্ডের সৃজনশীল প্রশ্নের চার স্তর অনুযায়ী সাজানো — জ্ঞানমূলক থেকে উচ্চতর দক্ষতামূলক।</p>` + G.map((g, k) => g.length ? `<section class="stack wp-lv" style="gap:8px"><h2 class="h-card wp-lvh"><span class="wp-tag l${k}">${WPL[k][0]}</span>${WPL[k][1]}<small class="muted">${WPL[k][2]}</small></h2>${g.map(card).join('')}</section>` : '').join('') : '<div class="empty">শীঘ্রই যুক্ত হবে।</div>';
  } else {
    const items = Q[tab] || [];
    const pre = { sq: 'সংক্ষিপ্ত প্রশ্ন', bq: 'বোর্ড প্রশ্নের ধাঁচে', aq: 'প্রয়োগমূলক', nq: 'বিশ্লেষণধর্মী', hq: 'উচ্চতর চিন্তন' }[tab];
    body = items.length ? `<div class="card">${qaHTML(items)}</div>${tab === 'bq' ? '<p class="small muted">বোর্ড পরীক্ষার জ্ঞানমূলক (ক) ও অনুধাবনমূলক (খ) প্রশ্নের ধরনে তৈরি।</p>' : ''}` : '<div class="empty">শীঘ্রই যুক্ত হবে।</div>';
    body = `<div class="small muted">${pre}</div>` + body;
  }
  return {
    title: 'প্রশ্নব্যাংক', eye: s.no + ' ' + (s.st || s.t), nav: 'practice',
    html: `<div class="wrap stack"><div><span class="eyebrow">প্রশ্নব্যাংক · ${s.no}</span><h1 class="h-sec">${s.t}</h1></div>
    <div class="tabs" role="tablist">${BTABS.map(([k, n]) => `<button role="tab" class="${tab === k ? 'on' : ''}" data-act="bankTab" data-tab="${k}">${n}<span class="ct">${bn(k === 'mcq' ? s.allM.length : (Q[k] || []).length)}</span></button>`).join('')}</div>
    <div class="stack" style="gap:10px">${body}</div>
    ${s.allM.length ? `<button class="btn primary" data-act="quiz" data-id="${s.id}" data-mode="adaptive">${ico('target')}অ্যাডাপটিভ কুইজ শুরু করো</button>` : ''}</div>`
  };
};
function cqHTML(c, i, opts = {}) {
  return `<div class="qcard" ${opts.attr || ''}><div class="qhead"><span class="chip acc">${opts.label || 'সৃজনশীল প্রশ্ন ' + bn(i + 1)}</span>${opts.svk ? `<span class="sp"></span>${svBtn('c', opts.svk)}` : ''}</div>
  <div class="note amb" style="margin-top:0"><b>উদ্দীপক:</b> ${c.s}</div>
  ${c.p.map((p, j) => `<div class="qa"><div class="q"><b>${OL[j]}.</b> ${p[0]} <span class="chip">${bn(j + 1)}</span></div><button class="btn sm soft reveal-btn" data-act="reveal">${ico('eye')}উত্তর দেখো</button><div class="ans" hidden>${p[1]}</div>${opts.mark ? opts.mark(j) : ''}</div>`).join('')}</div>`;
}

/* ---------- Adaptive quiz ---------- */
let QZ = null;
const LV = ['e', 'm', 'h'];
function startQuiz(sid, mode) {
  let pool;
  if (sid === 'wrong') pool = wrongIds();
  else if (sid === 'mist') pool = mistOf(false);
  else if (sid === 'daily') { if (dailyDone()) { toast('আজকের চ্যালেঞ্জ শেষ — কাল আবার নতুন ১০টি প্রশ্ন'); return; } pool = dailyPool(); }
  else { pool = SMAP[sid].allM.slice(); }
  if (mode !== 'adaptive' && LV.includes(mode)) { const f = pool.filter(id => MCQ[id].d === mode); if (f.length >= 3) pool = f; }
  if (!pool.length) { toast('এখানে কোনো প্রশ্ন নেই'); return; }
  QZ = { sid, mode, pool, n: Math.min(10, pool.length), asked: [], answers: [], level: mode === 'adaptive' ? 'm' : null, cur: null, start: Date.now(), qStart: Date.now(), picked: null };
  nextQ();
  go('quiz', { sid });
}
function nextQ() {
  const left = QZ.pool.filter(id => !QZ.asked.includes(id));
  let cand = left;
  if (QZ.level) {
    const order = QZ.level === 'm' ? ['m', 'e', 'h'] : QZ.level === 'h' ? ['h', 'm', 'e'] : ['e', 'm', 'h'];
    for (const lv of order) { const c = left.filter(id => MCQ[id].d === lv); if (c.length) { cand = c; break; } }
  }
  const pickOne = shuffle(cand)[0];
  QZ.cur = pickOne; QZ.asked.push(pickOne); QZ.picked = null; QZ.rv = null; QZ.qStart = Date.now();
}
VIEWS.quiz = () => {
  if (!QZ || !QZ.cur) return VIEWS.practice();
  const i = QZ.asked.length, rv = QZ.rv != null && QZ.rv < i - 1 ? QZ.rv : null, vi = rv == null ? i - 1 : rv;
  const m = MCQ[QZ.asked[vi]];
  const s = SMAP[m.sid];
  const segs = Array.from({ length: QZ.n }, (_, k) => { const a = QZ.answers[k]; return `<i class="${a ? (a.ok ? 'ok' : 'bad') : (k === i - 1 ? 'cur' : '')}${k === vi ? ' view' : ''}"></i>`; }).join('');
  const modeName = QZ.mode === 'adaptive' ? 'অ্যাডাপটিভ' : QZ.mode === 'wrong' || QZ.mode === 'mist' ? 'পুনরায় অনুশীলন' : QZ.mode === 'daily' ? 'আজকের চ্যালেঞ্জ' : DL[QZ.mode];
  const answered = rv != null || QZ.picked != null;
  return {
    title: 'কুইজ', eye: (QZ.sid === 'wrong' ? 'ভুল প্রশ্ন পুনরায়' : QZ.sid === 'mist' ? 'ভুলের খাতা' : QZ.sid === 'daily' ? 'অধ্যায় ' + CH.no : s.no + ' ' + (s.st || s.t)) + ' · ' + modeName, nav: 'practice',
    html: `<div class="wrap stack"><div class="row"><b>প্রশ্ন ${bn(vi + 1)}/${bn(QZ.n)}</b>${rv != null ? '<span class="chip">আগের প্রশ্ন — শুধু দেখা</span>' : ''}<span class="sp"></span>${QZ.level ? `<span class="small muted">বর্তমান স্তর:</span> <span class="chip ${QZ.level}">${DL[QZ.level]}</span>` : ''}<span class="timer" id="qTimer">০:০০</span></div>
    <div class="qprog">${segs}</div>
    ${mcqHTML(m, vi, { act: 'qpick', label: (!SMAP[QZ.sid] ? s.no + ' · ' : '') + 'প্রশ্ন ' + bn(vi + 1) })}
    <div class="row"><button class="btn" data-act="qprev" ${vi > 0 ? '' : 'disabled'}>${ico('back')}আগের</button><span class="sp"></span>${rv != null ? `<button class="btn primary" data-act="qfwd">${rv + 1 === i - 1 ? 'বর্তমান প্রশ্নে ফেরো' : 'পরের'}${ico('next')}</button>` : `<span id="qNext" ${answered ? '' : 'hidden'}><button class="btn primary" data-act="qnext">${i >= QZ.n ? 'ফলাফল দেখো' : 'পরের প্রশ্ন'}${ico('next')}</button></span>`}</div>
    <button class="btn ghost sm" data-act="qquit" style="align-self:flex-start">কুইজ ছেড়ে দাও</button></div>`,
    after() {
      const a = rv != null ? QZ.answers[rv] : QZ.picked != null ? QZ.answers[QZ.answers.length - 1] : null;
      if (a) { const card = $('.qcard'); $$('.opt', card).forEach((b, k) => { b.disabled = true; if (k === m.a) b.classList.add('right'); if (k === a.pick && !a.ok) b.classList.add('wrong'); }); $('.fb', card).innerHTML = feedbackHTML(m, a.pick); }
      const t = setInterval(() => { const e = Math.floor((Date.now() - QZ.start) / 1000); const el = $('#qTimer'); if (el) el.textContent = bn(Math.floor(e / 60)) + ':' + bn(String(e % 60).padStart(2, '0')); }, 1000);
      cleanups.push(() => clearInterval(t));
    }
  };
};
function quizPick(btn) {
  if (!QZ || QZ.picked != null) return;
  const m = MCQ[btn.dataset.q], pick = +btn.dataset.i, ok = pick === m.a;
  QZ.picked = pick;
  QZ.answers.push({ id: m.id, pick, ok, d: m.d, t: Date.now() - QZ.qStart });
  recordQ(m.id, ok);
  const card = btn.closest('.qcard');
  $$('.opt', card).forEach((b, k) => { b.disabled = true; if (k === m.a) b.classList.add('right'); if (k === pick && !ok) b.classList.add('wrong'); });
  $('.fb', card).innerHTML = feedbackHTML(m, pick);
  if (QZ.level) { const li = LV.indexOf(QZ.level); QZ.level = LV[clamp(li + (ok ? 1 : -1), 0, 2)]; }
  const n = $('#qNext'); n.hidden = false; n.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}
function finishQuiz() {
  const a = QZ.answers, sc = a.filter(x => x.ok).length, p = Math.round(sc / a.length * 100);
  if (QZ.sid === 'daily') { S.daily = S.daily || {}; S.daily[dkey() + ':' + CH.id] = { p, sc, n: a.length }; save(); }
  else if (SMAP[QZ.sid]) {
    const q = S.quiz[QZ.sid] || { n: 0, best: 0, hist: [] };
    q.n++; q.last = p; q.best = Math.max(q.best || 0, p); q.hist = (q.hist || []).concat([[Date.now(), p]]).slice(-12);
    S.quiz[QZ.sid] = q; save();
  }
  QZ.done = { sc, p, time: Date.now() - QZ.start };
  go('quizReport', { sid: QZ.sid }, { replace: true });
}
VIEWS.quizReport = () => {
  if (!QZ || !QZ.done) return VIEWS.practice();
  const a = QZ.answers, { sc, p, time } = QZ.done;
  const byD = LV.map(d => { const x = a.filter(r => r.d === d); return [d, x.length, x.filter(r => r.ok).length]; }).filter(r => r[1]);
  const weak = {};
  a.filter(r => !r.ok).forEach(r => { const m = MCQ[r.id]; const k = m.l || m.sid; weak[k] = (weak[k] || 0) + 1; });
  const weakList = Object.entries(weak).sort((x, y) => y[1] - x[1]);
  const verdict = p >= 85 ? 'চমৎকার! এই অংশে তোমার দখল দৃঢ়।' : p >= 65 ? 'ভালো করেছ। কয়েকটি ধারণা আরেকবার ঝালিয়ে নাও।' : p >= 40 ? 'মাঝামাঝি। নিচের দুর্বল জায়গাগুলো আবার পড়ে আবার কুইজ দাও।' : 'এই অংশটি আবার শুরু থেকে পড়া দরকার। পাঠ শেষে আবার চেষ্টা করো।';
  const s = SMAP[QZ.sid];
  return {
    title: 'কুইজ রিপোর্ট', eye: s ? s.no + ' ' + (s.st || s.t) : QZ.sid === 'daily' ? 'আজকের চ্যালেঞ্জ · +৩০ XP' : QZ.sid === 'mist' ? 'ভুলের খাতা' : 'ভুল প্রশ্ন', nav: 'practice',
    html: `<div class="wrap stack">
    <div class="card row" style="gap:18px;align-items:center">${ring(p, 132, 11, 'স্কোর')}<div style="flex:1;min-width:180px"><h2 class="h-card">পারফরম্যান্স রিপোর্ট</h2><p style="margin:.3em 0">${verdict}</p>
    <div class="small muted">${bn(sc)}/${bn(a.length)} সঠিক · মোট সময় ${bn(Math.round(time / 60000))} মি. ${bn(Math.round(time / 1000) % 60)} সে. · প্রতি প্রশ্নে গড় ${bn(Math.round(time / a.length / 1000))} সে.</div></div></div>
    <div class="card stack" style="gap:10px"><b>কঠিনতা অনুযায়ী</b>${byD.map(([d, n, c]) => `<div><div class="row small"><span class="chip ${d}">${DL[d]}</span><span class="sp"></span>${bn(c)}/${bn(n)}</div>${bar(c / n * 100, d === 'e' ? 'ok' : d === 'm' ? 'a2' : '')}</div>`).join('')}</div>
    <div class="card stack" style="gap:8px"><b>পুনরালোচনার পরামর্শ</b>${weakList.length ? weakList.map(([k, n]) => { const l = LMAP[k]; const sx = SMAP[k]; return l ? `<button class="li" style="border:1px solid var(--line);border-radius:12px" data-act="lesson" data-id="${l.id}"><span class="no">${l.no || ''}</span><span class="t">${l.t}<small>${bn(n)}টি ভুল এই পাঠ থেকে</small></span>${ico('next')}</button>` : sx ? `<button class="li" data-act="sec" data-id="${sx.id}"><span class="t">${sx.t}<small>${bn(n)}টি ভুল</small></span></button>` : ''; }).join('') : '<span class="muted">কোনো ভুল নেই — দারুণ! কঠিন স্তরে আরেকবার চেষ্টা করতে পারো।</span>'}</div>
    <details class="blk"><summary><span class="bi">${ico('list')}</span>সব উত্তর ও ব্যাখ্যা<span class="chev">${ico('chev')}</span></summary><div class="bd stack" style="gap:10px">${a.map((r, k) => { const m = MCQ[r.id]; return `<div class="qa"><div class="q"><b>${bn(k + 1)}.</b> ${m.q} <span class="chip ${r.ok ? 'ok' : 'bad'}">${r.ok ? 'সঠিক' : 'ভুল'}</span></div><div class="small">তোমার উত্তর: (${OL[r.pick]}) ${m.o[r.pick]}${r.ok ? '' : ` · সঠিক: (${OL[m.a]}) ${m.o[m.a]}`}</div>${m.x ? `<div class="small muted">${m.x}</div>` : ''}${readLink(m)}</div>`; }).join('')}</div></details>
    <div class="row">${QZ.sid === 'daily' ? `<button class="btn primary" data-act="go" data-v="xp">${ico('trophy')}লেভেল ও XP দেখো</button><button class="btn" data-act="go" data-v="home">হোমে ফেরো</button>` : QZ.sid === 'mist' ? `<button class="btn primary" data-act="go" data-v="mistakes">${ico('repeat')}ভুলের খাতায় ফেরো</button>` : QZ.sid !== 'wrong' ? `<button class="btn primary" data-act="quiz" data-id="${QZ.sid}" data-mode="${QZ.mode}">${ico('repeat')}আবার কুইজ</button><button class="btn" data-act="sec" data-id="${QZ.sid}">অংশে ফিরে যাও</button>` : `<button class="btn primary" data-act="quiz" data-id="wrong" data-mode="wrong">${ico('repeat')}বাকি ভুলগুলো আবার</button>`}</div>
    </div>`
  };
};

/* ---------- Practice hub ---------- */
VIEWS.practice = () => {
  const wr = wrongIds().length;
  const mg = S.mega;
  return {
    title: 'অনুশীলন', nav: 'practice',
    html: `<div class="wrap stack"><div><span class="eyebrow">কুইজ ও পরীক্ষা</span><h1 class="h-sec">অনুশীলন কেন্দ্র</h1></div>
    <button class="pbtn hero" data-act="go" data-v="mega"><b>${ico('trophy')} অধ্যায় চূড়ান্ত মেগা টেস্ট</b><small>১০০ MCQ · ৫০ সংক্ষিপ্ত · ২০ সৃজনশীল · ১০ বিশ্লেষণধর্মী · ৫ HOTS সেট${mg ? ' · সর্বশেষ মাস্টারি ' + bn(mg.mastery) + '%' : ''}</small></button>
    <div class="grid2"><button class="pbtn" data-act="go" data-v="testBuild"><b>${ico('clock')} টেস্ট বিল্ডার</b><small>সময় ধরে MCQ টেস্ট · প্যালেট · ইতিহাস${S.test && !S.test.done ? ' · ⏸ একটি চলমান' : ''}</small></button><button class="pbtn" data-act="go" data-v="cqLab"><b>${ico('pen')} CQ ল্যাব</b><small>লেখো, রুব্রিকে নিজে নম্বর দাও, মডেলের সাথে মেলাও</small></button></div>
    <div class="grid2"><button class="pbtn" data-act="go" data-v="flash"><b>${ico('cards')} ফ্ল্যাশকার্ড (SRS)</b><small>আজ ${bn(fcDueCount())}টি রিভিউ বাকি</small></button><button class="pbtn" data-act="go" data-v="mistakes"><b>${ico('alert')} ভুলের খাতা</b><small>${bn(mistOf(false).length)}টি চলমান · ${bn(mistOf(true).length)}টি আয়ত্ত</small></button><button class="pbtn" data-act="go" data-v="badges"><b>${ico('trophy')} অর্জন ও ব্যাজ</b><small>${bn(badges().filter(x => x[3] >= x[4]).length)}/${bn(badges().length)}টি অর্জিত</small></button><button class="pbtn" data-act="go" data-v="games"><b>🎮 খেলা</b><small>মিলাও · জোড়া খোঁজো · স্পিড কুইজ</small></button><button class="pbtn" data-act="go" data-v="xp"><b>${ico('spark')} লেভেল ও XP</b><small>লেভেল ${bn(xpInfo().L)} · ${bn(xpInfo().xp)} XP</small></button></div>
    <button class="pbtn" data-act="quiz" data-id="daily" data-mode="daily"><b>${ico('spark')} আজকের চ্যালেঞ্জ</b><small>${dailyDone() ? 'আজ সম্পন্ন · স্কোর ' + p2(dailyDone().p / 100) + '%' : 'এই অধ্যায় থেকে ১০টি প্রশ্ন · +৩০ XP'}</small></button>
    ${wr ? `<button class="pbtn" data-act="quiz" data-id="wrong" data-mode="wrong"><b>ভুল প্রশ্নগুলো আবার করো</b><small>${bn(wr)}টি প্রশ্ন যেগুলো সর্বশেষে ভুল হয়েছিল</small></button>` : ''}
    <h2 class="h-card">অংশভিত্তিক কুইজ ও প্রশ্নব্যাংক</h2>
    <div class="lesson-list">${SECS.filter(s => s.allM.length).map(s => { const st = secStats(s); return `<div class="li" style="flex-wrap:wrap"><span class="no">${s.no}</span><span class="t">${s.t}<small>কুইজ ${st.quiz == null ? 'দেওয়া হয়নি' : bn(st.quiz) + '% (সেরা ' + bn(st.best) + '%)'} · মাস্টারি ${bn(st.mastery)}%</small></span><span class="row" style="gap:6px"><button class="btn sm" data-act="bank" data-id="${s.id}">প্রশ্নব্যাংক</button><button class="btn sm primary" data-act="quiz" data-id="${s.id}" data-mode="adaptive">কুইজ</button></span></div>`; }).join('')}</div></div>`
  };
};

/* ---------- Tools hub ---------- */
VIEWS.tools = () => {
  const t = [['toc', 'layers', 'সম্পূর্ণ সূচিপত্র', 'সব অধ্যায়ের অনুচ্ছেদ ও উপ-অনুচ্ছেদ, নম্বরসহ'], ['tricks', 'bulb', 'মনে রাখার ট্রিকস', 'ছন্দ, সংক্ষেপ ও গল্পে কঠিন বিষয় মনে রাখো'], ['figures', 'pic', 'চিত্রসূচি', `${bn(figList(CH).length)}টি চিত্র, অ্যানিমেশন ও ৩D মডেল — অংশভিত্তিক`], ['formulas', 'sigma', 'ফর্মুলা শিট', 'অধ্যায়ের সব সূত্র, অংশভিত্তিক'], ['compare', 'layers', 'পার্থক্য সারণি', `${bn(cmpList().length)}টি তুলনা — এই অধ্যায়ের মডেল ও ধারণা`],['flash', 'cards', 'ফ্ল্যাশকার্ড', 'ট্যাপ করে উল্টাও, জানা/অজানা চিহ্নিত করো'], ['revision', 'repeat', 'রিভিশন মোড', 'শুধু নোট, তথ্য ও কৌশল'], ['library', 'bm', 'আমার লাইব্রেরি', 'সংরক্ষিত পাঠ, MCQ, সৃজনশীল, চিত্র, সূত্র, ট্রিকস, হাইলাইট ও নোট — আলাদা আলাদা'], ['search', 'search', 'খোঁজো', 'পাঠ ও প্রশ্নে যেকোনো শব্দ'], ['stats', 'chart', 'অগ্রগতি বিশ্লেষণ', 'লার্নিং ট্র্যাকার'], ['study', 'chart', '৩০ দিনের পড়া', 'রঙিন ক্যালেন্ডার ও সারসংক্ষেপ'], ['xp', 'trophy', 'লেভেল ও XP', 'অর্জিত পয়েন্ট ও ধাপ'], ['settings', 'gear', 'সেটিংস', 'থিম, দৈনিক লক্ষ্য, অফলাইন']];
  return { title: 'টুলস', nav: 'tools', html: `<div class="wrap stack"><div><span class="eyebrow">পড়ার সহায়ক</span><h1 class="h-sec">টুলস</h1></div><div class="tools">${t.map(([v, i, n, s]) => `<button class="tool" data-act="go" data-v="${v}"><span class="ti">${ico(i)}</span><span><b>${n}</b><small>${s}</small></span></button>`).join('')}</div></div>` };
};

/* ---------- টুলসের পরিসর: অধ্যায় / বিষয় / সব ---------- */
const scKey = a => { const k = (a && a.sc) || S.tsc || 'ch'; return ['ch', 'sub', 'all'].includes(k) ? k : 'ch'; };
function scopeChs(k) { return k === 'all' ? CHAPTERS.slice() : k === 'sub' ? subjOf(CH).chs.filter(c => CHMAP[c.id]) : [CH]; }
const scopeName = k => k === 'all' ? 'পুরো কনটেন্ট' : k === 'sub' ? subjOf(CH).t : 'অধ্যায় ' + CH.no;
function scopeSeg(k) { return `<div class="seg scope-seg" role="tablist" aria-label="পরিসর">${[['ch', 'এই অধ্যায়'], ['sub', 'এই বিষয়'], ['all', 'সব']].map(([v, n]) => `<button type="button" data-act="scope" data-k="${v}" class="${k === v ? 'on' : ''}">${n}</button>`).join('')}</div>`; }
const chHead = (c, multi) => multi ? `<h2 class="h-sec ch-sep"><span class="mono muted" style="font-size:.75em">অধ্যায় ${c.no}</span> ${c.t} <small class="muted">· ${subjOf(c).t}</small></h2>` : '';

/* ---------- Table of figures ---------- */
VIEWS.figures = ({ type = 'all', q = '' }) => {
  const sc = scKey(cur.args), chs = scopeChs(sc), multi = chs.length > 1;
  const all = chs.flatMap(c => figList(c));
  const cnt = k => all.filter(f => (VIS[f.k].k || []).includes(k)).length;
  const types = [['all', 'সব'], ['3d', '৩D'], ['anim', 'অ্যানিমেশন'], ['int', 'ইন্টারঅ্যাকটিভ'], ['calc', 'ক্যালকুলেটর'], ['2d', '২D চিত্র']].filter(([k]) => k === 'all' || cnt(k));
  const body = () => {
    const ty = cur.args.type || 'all', ql = (cur.args.q || '').trim().toLowerCase();
    const f = all.filter(x => (ty === 'all' || (VIS[x.k].k || []).includes(ty)) && (!ql || strip(VIS[x.k].t + ' ' + (VIS[x.k].cap || '')).toLowerCase().includes(ql)));
    if (!f.length) return '<div class="empty">এই ফিল্টারে কোনো চিত্র নেই।</div>';
    return chs.map(c => { const secs = c.S.map(s => {
      const items = f.filter(x => x.l.sid === s.id); if (!items.length) return '';
      return `<section class="stack" style="gap:8px"><h2 class="h-card"><span class="mono muted" style="font-size:.8em">${s.no}</span> ${s.st || s.t}</h2>${items.map(x => { const v = VIS[x.k]; return `<details class="blk figi" data-fk="${x.k}"><summary><span class="bi mono" style="font-size:10.5px;width:auto;min-width:34px;padding:0 6px">${CHMAP[x.l.ch].no}.${bn(x.n)}</span><span style="flex:1;min-width:0">${v.t}<small class="figi-k">${(v.k || []).map(k => VTYPE[k] || k).join(' · ')} · পাঠ ${x.l.no || ''}</small></span><span class="chev">${ico('chev')}</span></summary><div class="bd stack" style="gap:10px">${figHTML(x.k)}<button class="btn sm soft" data-act="lesson" data-id="${x.l.id}">${ico('book')}পাঠে যাও: ${x.l.no || ''} ${x.l.t}</button></div></details>`; }).join('')}</section>`;
    }).join(''); return secs ? chHead(c, multi) + secs : ''; }).join('');
  };
  return {
    title: 'চিত্রসূচি', nav: 'tools',
    html: `<div class="wrap stack"><div><span class="eyebrow">${scopeName(sc)} · Table of Figures</span><h1 class="h-sec">চিত্রসূচি</h1><p class="muted small" style="margin:4px 0 0">${sc === 'ch' ? 'এই অধ্যায়ের' : scopeName(sc) + '-এর'} ${bn(all.length)}টি চিত্র${cnt('3d') ? ` (${bn(cnt('3d'))}টি ৩D মডেল` : ' ('}${cnt('anim') ? `${cnt('3d') ? ', ' : ''}${bn(cnt('anim'))}টি অ্যানিমেশন` : ''})। যেকোনো চিত্রে চাপ দিলে এখানেই খুলবে ও চলবে; পাঠে যেতে নিচের বোতাম।</p></div>
    ${scopeSeg(sc)}
    <div class="search-box">${ico('search', 'muted')}<input id="figQ" type="search" placeholder="চিত্র খোঁজো (যেমন: ভেক্টর, প্রাস, ধারক)" value="${esc(q)}"></div>
    <div class="row" style="gap:8px;flex-wrap:wrap">${X_seg(types, type)}<span class="sp"></span><button class="btn sm" id="figAll">${ico('layers')}সব খোলো</button></div>
    <div id="figList" class="stack">${body()}</div></div>`,
    after() {
      const i = $('#figQ'), list = $('#figList');
      const redo = () => { list.innerHTML = body(); mountFigs(); };
      i.addEventListener('input', () => { cur.args.q = i.value; redo(); });
      $$('[data-fty]').forEach(b => b.addEventListener('click', () => { cur.args.type = b.dataset.fty; $$('[data-fty]').forEach(x => x.classList.toggle('on', x === b)); redo(); }));
      $('#figAll').addEventListener('click', () => { const ds = $$('details.figi', list), open = !ds.every(d => d.open); ds.forEach(d => { d.open = open; }); $('#figAll').lastChild.textContent = open ? 'সব বন্ধ করো' : 'সব খোলো'; });
    }
  };
};
function X_seg(items, on) { return `<div class="seg">${items.map(([k, n]) => `<button type="button" data-fty="${k}" class="${k === on ? 'on' : ''}">${n}</button>`).join('')}</div>`; }

/* ---------- Comparison tables ---------- */
function cmpTable(e) {
  if (e.h) return e.h;
  const l = LMAP[e.l]; if (!l) return '';
  const src = ['dp', 'sc', 'fx'].map(k => typeof l[k] === 'string' ? l[k] : '').join('');
  let j = -1;
  if (e.k) { const i = src.indexOf('<h4>' + e.k + '</h4>'); if (i < 0) return ''; j = src.indexOf('<div class="table-wrap"', i); }
  else { j = -1; for (let c = 0; c <= (e.n || 0); c++) { j = src.indexOf('<div class="table-wrap"', j + 1); if (j < 0) return ''; } }
  if (j < 0) return '';
  const k = src.indexOf('</table></div>', j); if (k < 0) return '';
  return src.slice(j, k + 14);
}
function cmpList(chs) { const ids = new Set((chs || [CH]).map(c => c.id)); return (window.CMPT || []).filter(e => LMAP[e.l] && ids.has(LMAP[e.l].ch)).map(e => Object.assign({ html: cmpTable(e) }, e)).filter(e => e.html); }
VIEWS.compare = ({ q = '' }) => {
  const sc = scKey(cur.args), chs = scopeChs(sc), multi = chs.length > 1;
  const list = cmpList(chs);
  const body = () => {
    const ql = (cur.args.q || '').trim().toLowerCase();
    const f = list.filter(e => !ql || strip(e.t + ' ' + e.html).toLowerCase().includes(ql));
    if (!f.length) return '<div class="empty">কোনো সারণি মেলেনি।</div>';
    return chs.map(c => { const fc = f.filter(e => LMAP[e.l].ch === c.id), groups = [...new Set(fc.map(e => e.g))]; const body = groups.map(g => { const items = fc.filter(e => e.g === g); if (!items.length) return ''; return `<section class="stack" style="gap:8px"><h2 class="h-card">${g}</h2>${items.map(e => { const l = LMAP[e.l]; return `<details class="blk" ${ql ? 'open' : ''}><summary><span class="bi">${ico('layers')}</span>${e.t}<span class="chev">${ico('chev')}</span></summary><div class="bd prose">${e.html}<button class="btn sm soft" data-act="lesson" data-id="${l.id}">${ico('book')}পাঠে যাও: ${l.no || ''} ${l.t}</button></div></details>`; }).join('')}</section>`; }).join(''); return body ? chHead(c, multi) + body : ''; }).join('');
  };
  return {
    title: 'পার্থক্য সারণি', nav: 'tools',
    html: `<div class="wrap stack"><div><span class="eyebrow">এক জায়গায় সব তুলনা</span><h1 class="h-sec">পার্থক্য ও তুলনা সারণি</h1><p class="muted small" style="margin:4px 0 0">বোর্ডে "পার্থক্য লেখো" প্রশ্নের জন্য সব সারণি এখানে। প্রতিটি সারণি তার পাঠেও আছে — নিচের বোতামে সেই পাঠে যাওয়া যাবে।</p></div>
    ${scopeSeg(sc)}
    <div class="search-box">${ico('search', 'muted')}<input id="cmpQ" type="search" placeholder="খোঁজো (যেমন: প্রত্যাবর্তী, ঘর্ষণ, ধারক)" value="${esc(q)}"></div>
    <div id="cmpList" class="stack">${body()}</div></div>`,
    after() { const i = $('#cmpQ'); i.addEventListener('input', () => { cur.args.q = i.value; $('#cmpList').innerHTML = body(); }); }
  };
};

/* ---------- Formulas ---------- */
VIEWS.formulas = ({ q = '' }) => { const sc = scKey(cur.args), chs = scopeChs(sc); return {
  title: 'ফর্মুলা শিট', nav: 'tools',
  html: `<div class="wrap stack"><div><span class="eyebrow">${scopeName(sc)} · সব সূত্র</span><h1 class="h-sec">ফর্মুলা শিট</h1></div>
  ${scopeSeg(sc)}
  <div class="search-box">${ico('search', 'muted')}<input id="fmQ" type="search" placeholder="সূত্র খোঁজো (যেমন: কার্নো, গাউস, ও'ম)" value="${esc(q)}"></div>
  <div id="fmList" class="stack">${fmList(q, chs)}</div></div>`,
  after() { const i = $('#fmQ'); i.addEventListener('input', () => { cur.args.q = i.value; $('#fmList').innerHTML = fmList(i.value, chs); }); }
}; };
function fmList(q, chs) {
  q = (q || '').trim().toLowerCase(); chs = chs || [CH]; const multi = chs.length > 1;
  const out = chs.map(c => { const b = c.S.filter(s => s.FM.length).map(s => {
    const f = s.FM.filter(x => !q || strip(x.join(' ')).toLowerCase().includes(q));
    return f.length ? `<section class="stack" style="gap:8px"><h2 class="h-card"><span class="mono small muted">${s.no}</span> ${s.t}</h2>${formulaCards(f, s)}</section>` : '';
  }).join(''); return b ? chHead(c, multi) + b : ''; }).join('');
  return out || '<div class="empty">কোনো সূত্র মেলেনি।</div>';
}

/* ---------- Flashcards ---------- */
let FC = null;
VIEWS.flash = ({ sid = 'all' }) => {
  const deck = [];
  SECS.forEach(s => { if (sid !== 'all' && s.id !== sid) return; s.F.forEach((f, i) => deck.push({ id: s.id + 'f' + i, sid: s.id, f: f[0], b: f[1] })); });
  if (!FC || FC.sid !== sid) {
    const order = shuffle(deck).sort((a, b) => (S.fc[a.id] || 0) - (S.fc[b.id] || 0));
    FC = { sid, order, i: 0, flip: false };
  }
  const known = deck.filter(c => (S.fc[c.id] || 0) >= 2).length;
  const c = FC.order[FC.i];
  const opts = `<select class="inp" id="fcDeck"><option value="all">সব অংশ (${bn(SECS.reduce((a, s) => a + s.F.length, 0))})</option>${SECS.filter(s => s.F.length).map(s => `<option value="${s.id}" ${s.id === sid ? 'selected' : ''}>${s.no} ${s.st || s.t} (${bn(s.F.length)})</option>`).join('')}</select>`;
  return {
    title: 'ফ্ল্যাশকার্ড', nav: 'tools',
    html: `<div class="wrap stack"><div><span class="eyebrow">সক্রিয় স্মরণ</span><h1 class="h-sec">ফ্ল্যাশকার্ড</h1></div>
    <div class="row">${opts}<span class="sp"></span><span class="small muted">আয়ত্ত ${bn(known)}/${bn(deck.length)}</span></div>
    ${bar(deck.length ? known / deck.length * 100 : 0, 'ok')}
    ${c ? `<div class="flash-stage"><div class="flash ${FC.flip ? 'flip' : ''}" id="flashCard" data-act="fcFlip" role="button" tabindex="0" aria-label="কার্ড উল্টাও">
      <div class="face"><small>${SMAP[c.sid].no} · কার্ড ${bn(FC.i + 1)}/${bn(FC.order.length)}</small><div class="fq">${c.f}</div><div class="small muted" style="margin-top:14px">উত্তর দেখতে ট্যাপ করো</div></div>
      <div class="face back"><small>উত্তর</small><div class="fa">${c.b}</div></div></div></div>
    <div class="grid2"><button class="btn" data-act="fcMark" data-k="0">${ico('repeat')}আবার দেখব</button><button class="btn primary" data-act="fcMark" data-k="1">${ico('check')}জানি</button></div>
    <div class="row"><button class="btn sm ghost" data-act="fcStep" data-d="-1">${ico('prev')}আগের</button><span class="sp"></span><button class="btn sm ghost" data-act="fcShuffle">${ico('repeat')}এলোমেলো করো</button><button class="btn sm ghost" data-act="fcStep" data-d="1">পরের${ico('next')}</button></div>`
        : '<div class="empty">এই ডেকে কার্ড নেই।</div>'}</div>`,
    after() { const d = $('#fcDeck'); d && d.addEventListener('change', () => { FC = null; go('flash', { sid: d.value }, { replace: true }); }); }
  };
};

/* ---------- Revision ---------- */
VIEWS.revision = ({ sid }) => {
  const list = SECS.filter(s => !sid || s.id === sid);
  return {
    title: 'রিভিশন মোড', nav: 'tools',
    html: `<div class="wrap stack"><div><span class="eyebrow">পরীক্ষার আগের রাতে</span><h1 class="h-sec">রিভিশন মোড</h1><p class="muted small" style="margin:4px 0 0">প্রতিটি পাঠের সংক্ষিপ্ত নোট, গুরুত্বপূর্ণ তথ্য ও মনে রাখার কৌশল এক পাতায়।</p></div>
    ${wrongIds().length ? `<button class="pbtn" data-act="quiz" data-id="wrong" data-mode="wrong"><b>ভুল প্রশ্ন রিভিশন</b><small>${bn(wrongIds().length)}টি প্রশ্ন</small></button>` : ''}
    ${list.map(s => `<details class="blk"><summary><span class="bi mono" style="font-size:11px">${s.no}</span>${s.t}<span class="chev">${ico('chev')}</span></summary><div class="bd prose">
      ${s.L.map(l => { const parts = [['sn', 'নোট'], ['fx', 'তথ্য'], ['mh', 'কৌশল']].filter(([k]) => l[k] && l[k].length); if (!parts.length) return ''; return `<h4>${l.no || ''} ${l.t}</h4>${parts.map(([k, n]) => `<div class="small muted">${n}</div>${listHTML(l[k])}`).join('')}`; }).join('')}
      ${s.FM.length ? `<h4>সূত্র</h4>${s.FM.map(f => `<div class="eq">${f[1]}</div>`).join('')}` : ''}</div></details>`).join('')}</div>`
  };
};

/* ---------- Search ---------- */
let IDX = null;
function buildIdx() {
  IDX = [];
  const multi = CHAPTERS.length > 1, cp = x => multi ? 'অ.' + CHMAP[x.ch].no + ' · ' : '';
  LESSONS_ALL.forEach(l => { let t = l.t + ' '; BLOCKS.forEach(([k]) => { const v = l[k]; if (v) t += ' ' + (Array.isArray(v) ? v.map(x => Array.isArray(x) ? x.join(' ') : x).join(' ') : v); }); IDX.push({ k: 'l', id: l.id, sid: l.sid, title: cp(l) + (l.no ? l.no + ' ' : '') + l.t, text: strip(t).replace(/\{\{v:[\w-]+\}\}/g, '').replace(/\s+/g, ' ') }); });
  SECS_ALL.forEach(s => {
    s.allM.forEach(id => { const m = MCQ[id]; IDX.push({ k: 'q', sid: s.id, tab: 'mcq', title: cp(s) + 'MCQ · ' + s.no, text: strip(m.q + ' ' + m.o.join(' ') + ' ' + m.x).replace(/\s+/g, ' ') }); });
    ['sq', 'bq', 'aq', 'nq', 'hq'].forEach(t => s.Q[t].forEach(q => IDX.push({ k: 'q', sid: s.id, tab: t, title: cp(s) + BTABS.find(b => b[0] === t)[1] + ' · ' + s.no, text: strip(q.join(' ')).replace(/\s+/g, ' ') })));
    s.Q.cq.forEach(c => IDX.push({ k: 'q', sid: s.id, tab: 'cq', title: cp(s) + 'সৃজনশীল · ' + s.no, text: strip(c.s + ' ' + c.p.map(p => p.join(' ')).join(' ')).replace(/\s+/g, ' ') }));
    s.FM.forEach(f => IDX.push({ k: 'f', sid: s.id, ch: s.ch, title: cp(s) + 'সূত্র · ' + s.no, text: strip(f.join(' ')).replace(/\s+/g, ' ') }));
  });
}
VIEWS.search = ({ q = '' }) => ({
  title: 'খোঁজো', nav: 'tools',
  html: `<div class="wrap stack"><div class="search-box">${ico('search', 'muted')}<input id="sQ" type="search" placeholder="যেমন: বামার, শিখা পরীক্ষা, Rf, আউফবাউ" value="${esc(q)}" autocomplete="off"></div><div id="sRes" class="lesson-list" style="${q ? '' : 'display:none'}"></div><div id="sHint" class="small muted">পাঠ, প্রশ্ন ও সূত্র — সবখানে খোঁজা হবে।</div></div>`,
  after() { const i = $('#sQ'); const run = () => { cur.args.q = i.value; doSearch(i.value); }; i.addEventListener('input', run); if (q) run(); setTimeout(() => i.focus(), 50); }
});
function doSearch(q) {
  if (!IDX) buildIdx();
  q = q.trim(); const box = $('#sRes'), hint = $('#sHint');
  if (q.length < 2) { box.style.display = 'none'; hint.textContent = 'অন্তত ২টি অক্ষর লেখো।'; return; }
  const ql = q.toLowerCase(); const res = [];
  for (const e of IDX) { const p = e.text.toLowerCase().indexOf(ql); if (p >= 0 || e.title.toLowerCase().includes(ql)) res.push([e, p]); if (res.length > 80) break; }
  hint.textContent = res.length ? bn(res.length) + 'টি ফলাফল' : 'কিছু পাওয়া যায়নি। অন্য শব্দে চেষ্টা করো।';
  box.style.display = res.length ? '' : 'none';
  box.innerHTML = res.map(([e, p]) => {
    const a = Math.max(0, p - 50), snip = p >= 0 ? (a > 0 ? '…' : '') + esc(e.text.slice(a, p)) + '<mark>' + esc(e.text.slice(p, p + q.length)) + '</mark>' + esc(e.text.slice(p + q.length, p + q.length + 70)) + '…' : '';
    const act = e.k === 'l' ? `data-act="lesson" data-id="${e.id}" data-find="${esc(q)}"` : e.k === 'f' ? `data-act="go" data-v="formulas" data-ch="${e.ch}" data-q="${esc(q)}"` : `data-act="bank" data-id="${e.sid}" data-tab="${e.tab}"`;
    return `<button class="res" ${act}><small>${e.k === 'l' ? 'পাঠ' : ''} ${e.title}</small>${e.k === 'l' ? `<b>${LMAP[e.id].t}</b>` : ''}<p>${snip}</p></button>`;
  }).join('');
}

/* ---------- Library ---------- */
VIEWS.library = ({ tab = 'bm' }) => {
  let body = '';
  if (tab === 'bm') { const l = LESSONS_ALL.filter(x => S.bm[x.id]); body = l.length ? `<div class="lesson-list">${l.map(lessonRow).join('')}</div>` : '<div class="empty">কোনো বুকমার্ক নেই। পাঠের উপরের "বুকমার্ক" বোতামে চাপ দাও।</div>'; }
  if (tab === 'notes') { const l = LESSONS_ALL.filter(x => S.notes[x.id]); body = l.length ? l.map(x => `<button class="card" style="text-align:left;color:inherit" data-act="lesson" data-id="${x.id}"><div class="small muted">${x.no || ''} ${x.t}</div><div style="white-space:pre-wrap;margin-top:4px">${esc(S.notes[x.id])}</div></button>`).join('') : '<div class="empty">এখনো কোনো নোট নেই। প্রতিটি পাঠের নিচে নোট লেখার জায়গা আছে।</div>'; }
  if (tab === 'hl') { const l = LESSONS_ALL.filter(x => (S.hl[x.id] || []).length); body = l.length ? l.map(x => `<div class="card stack" style="gap:6px"><button class="btn ghost sm" style="justify-content:flex-start;padding:0;color:var(--accent)" data-act="lesson" data-id="${x.id}">${x.no || ''} ${x.t}</button>${S.hl[x.id].map((h, i) => `<div class="row" style="flex-wrap:nowrap;align-items:flex-start"><mark class="hl" style="flex:1">${esc(h)}</mark><button class="icon-btn" style="width:34px;height:34px" data-act="hlDel" data-id="${x.id}" data-i="${i}" aria-label="মুছো">${ico('trash')}</button></div>`).join('')}</div>`).join('') : '<div class="empty">কোনো হাইলাইট নেই। পাঠের লেখা নির্বাচন করে "হাইলাইট" চাপো।</div>'; }
  if (tab === 'wrong') { const ids = wrongIds(); body = ids.length ? `<button class="btn primary" data-act="quiz" data-id="wrong" data-mode="wrong">${ico('repeat')}এগুলো দিয়ে কুইজ</button>` + ids.map((id, i) => mcqHTML(MCQ[id], i, { label: SMAP[MCQ[id].sid].no })).join('') : '<div class="empty">কোনো ভুল প্রশ্ন জমা নেই।</div>'; }
  const tabs = [['bm', 'বুকমার্ক'], ['notes', 'নোট'], ['hl', 'হাইলাইট'], ['wrong', 'ভুল প্রশ্ন']];
  return { title: 'লাইব্রেরি', nav: 'tools', html: `<div class="wrap stack"><div><span class="eyebrow">তোমার সংরক্ষণ</span><h1 class="h-sec">বুকমার্ক ও নোট</h1></div><div class="tabs">${tabs.map(([k, n]) => `<button class="${tab === k ? 'on' : ''}" data-act="libTab" data-tab="${k}">${n}</button>`).join('')}</div><div class="stack" style="gap:10px">${body}</div></div>` };
};

/* ---------- Stats / Learning tracker ---------- */
VIEWS.stats = () => {
  const g = globalStats(); const sk = streak(); const a7 = daysActive(7), a14 = daysActive(14);
  const cells = []; const now = new Date();
  for (let i = 27; i >= 0; i--) { const d = new Date(now); d.setDate(now.getDate() - i); const r = S.days[dkey(d)] || {}; const sc = (r.l || 0) * 10 + (r.m || 0) + (r.q || 0) * 1.5; const lv = sc <= 0 ? '' : sc < 10 ? 'l1' : sc < 30 ? 'l2' : 'l3'; cells.push(`<i class="${lv} ${i === 0 ? 'today' : ''}" title="${dkey(d)}"></i>`); }
  const totalMin = Object.values(S.days).reduce((a, d) => a + (d.m || 0), 0);
  const totalQ = Object.values(S.days).reduce((a, d) => a + (d.q || 0), 0);
  const left = SECS.reduce((a, s) => a + secStats(s).minsLeft, 0);
  return {
    title: 'অগ্রগতি', nav: 'stats',
    html: `<div class="wrap stack"><div><span class="eyebrow">লার্নিং অ্যানালিটিক্স</span><h1 class="h-sec">তোমার অগ্রগতি</h1></div>
    <div class="card row" style="gap:18px">${ring(g.pct, 132, 11, 'সম্পন্ন')}<div style="flex:1;min-width:180px" class="stack"><div><b>${bn(g.done)}/${bn(g.total)}</b> পাঠ সম্পন্ন · বাকি ${bn(g.total - g.done)}</div>
    <div class="small muted">গড় মাস্টারি ${bn(g.mastery)}% · MCQ নির্ভুলতা ${bn(g.acc)}% (${bn(g.att)}টি প্রশ্ন)</div>${bar(g.mastery)}<div class="small muted">আনুমানিক বাকি সময়: ${bn(Math.floor(left / 60))} ঘ. ${bn(left % 60)} মি.</div></div></div>
    <div class="grid2"><button class="btn" data-act="go" data-v="study">${ico('chart')}৩০ দিনের পড়া</button><button class="btn" data-act="go" data-v="xp">${ico('trophy')}লেভেল ও XP</button></div><div class="kv"><div><b>${bn(sk)}</b><span>দিনের স্ট্রিক</span></div><div><b>${bn(a7)}/৭</b><span>গত ৭ দিনে সক্রিয়</span></div><div><b>${bn(Math.round(totalMin))}</b><span>মোট পড়ার মিনিট</span></div><div><b>${bn(totalQ)}</b><span>মোট উত্তর দেওয়া প্রশ্ন</span></div></div>
    <div class="card stack" style="gap:10px"><div class="row"><b>গত ২৮ দিনের চর্চা</b><span class="sp"></span><span class="small muted">ধারাবাহিকতা ${bn(Math.round(a14 / 14 * 100))}% (১৪ দিন)</span></div><div class="heat">${cells.join('')}</div><div class="legend"><span>কম</span><span class="heat" style="display:inline-grid;grid-template-columns:repeat(4,12px);gap:3px"><i></i><i class="l1"></i><i class="l2"></i><i class="l3"></i></span><span>বেশি</span></div></div>
    <div class="card stack" style="gap:10px"><b>দৈনিক লক্ষ্য</b><div class="row"><span>পাঠ/দিন</span><span class="sp"></span><button class="btn sm" data-act="goal" data-k="l" data-d="-1">−</button><b class="mono">${bn(S.goal.l)}</b><button class="btn sm" data-act="goal" data-k="l" data-d="1">+</button></div><div class="row"><span>মিনিট/দিন</span><span class="sp"></span><button class="btn sm" data-act="goal" data-k="m" data-d="-5">−</button><b class="mono">${bn(S.goal.m)}</b><button class="btn sm" data-act="goal" data-k="m" data-d="5">+</button></div></div>
    ${CHAPTERS.length > 1 ? `<h2 class="h-card">সব অধ্যায়</h2><div class="ch-list">${CHAPTERS.map(c => { const st = chStats(c); return `<button class="ch-item ${c === CH ? 'on' : ''}" data-act="ch" data-id="${c.id}"><span class="ch-n">${c.no}</span><span class="ch-b"><b>${c.t}</b><small>${c.paper} · ${bn(st.d)}/${bn(st.t)} পাঠ · ${bn(st.pct)}%</small><span class="bar thin" style="margin-top:6px"><i style="width:${st.pct}%"></i></span></span></button>`; }).join('')}</div>` : ''}
    <h2 class="h-card">অংশভিত্তিক বিশ্লেষণ · অধ্যায় ${CH.no}</h2>
    ${SECS.map(s => { const st = secStats(s); return `<button class="card stack" style="gap:8px;text-align:left;color:inherit" data-act="sec" data-id="${s.id}">
      <div class="row" style="flex-wrap:nowrap"><span class="mono small muted">${s.no}</span><b style="flex:1;min-width:0">${s.t}</b><span class="chip ${st.mastery >= 75 ? 'ok' : st.mastery >= 40 ? 'warn' : ''}">মাস্টারি ${bn(st.mastery)}%</span></div>
      ${bar(st.comp * 100, 'ok')}
      <div class="small muted">পাঠ ${bn(st.done)}/${bn(st.total)} (বাকি ${bn(st.rem)}) · সম্পন্ন ${bn(pct(st.comp))}% · কুইজ ${st.quiz == null ? '—' : bn(st.quiz) + '%'} · MCQ ${bn(st.att)}/${bn(st.n)} চেষ্টা, নির্ভুলতা ${bn(Math.round(st.acc * 100))}% · বাকি ~${bn(st.minsLeft)} মি. · গত ৭ দিনে ${bn(st.last7)} দিন</div></button>`; }).join('')}
    </div>`
  };
};

/* ---------- Settings ---------- */
VIEWS.settings = () => ({
  title: 'সেটিংস', nav: 'tools',
  html: `<div class="wrap stack"><div><span class="eyebrow">ব্যক্তিগতকরণ</span><h1 class="h-sec">সেটিংস</h1></div>
  <section class="stack" style="gap:8px"><h2 class="h-card">থিম</h2>${themeOpts()}</section>
  <section class="card stack" style="gap:8px"><h2 class="h-card">নিচের বারের ২য় বোতাম</h2><p class="small muted" style="margin:0">হোম আর অধ্যায় পাতায় প্রায় একই জিনিস থাকে, তাই ডিফল্টে এখানে “সংরক্ষিত” থাকে। চাইলে বদলাও।</p>${navSlotOpts()}</section>
  <section class="card stack" style="gap:8px"><h2 class="h-card">শেষ করা অংশ কেটে দাও</h2><p class="small muted" style="margin:0">চালু থাকলে আয়ত্ত করা পাঠ ও পুরো আয়ত্ত উপ-অধ্যায়ের শিরোনামে দাগ কাটা (<s>এভাবে</s>) দেখাবে — কতটা বাকি এক নজরে বোঝা যায়।</p>${strikeOpts()}</section>
  <section class="card stack" style="gap:8px"><h2 class="h-card">সংরক্ষণ ও অফলাইন</h2>
  <p style="margin:0">তোমার অগ্রগতি, নোট, হাইলাইট ও কুইজ ফলাফল প্রতিটি কাজের সাথে সাথে স্বয়ংক্রিয়ভাবে সংরক্ষিত হয়। ${cloud.on ? '<b>এখন তোমার অ্যাকাউন্টেও সংরক্ষিত হচ্ছে</b>, তাই অন্য ডিভাইসে খুললেও একই জায়গা থেকে শুরু করতে পারবে।' : 'এখন শুধু এই ডিভাইসের ব্রাউজারে সংরক্ষিত হচ্ছে।'}</p>
  <p style="margin:0" class="small muted">পুরো অ্যাপ (সব পাঠ, চিত্র, অ্যানিমেশন ও প্রশ্ন) একটি ফাইলেই আছে — ইন্টারনেট ছাড়াও চলে। শুধু ফন্ট অনলাইনে থাকলে আরও সুন্দর দেখায়; অফলাইনে ফোনের বাংলা ফন্ট ব্যবহার হয়।</p></section>
  <section class="card stack" style="gap:8px"><h2 class="h-card">অফলাইন কপি ডাউনলোড</h2><p class="small muted" style="margin:0">পুরো অ্যাপ — সব অধ্যায়, চিত্র, অ্যানিমেশন ও প্রশ্ন — একটিমাত্র HTML ফাইলে। ফোন বা কম্পিউটারে রেখে ইন্টারনেট ছাড়াই ব্রাউজারে খোলো।</p><button class="btn primary" data-act="dlApp">${ico('next')}hsc-physics.html ডাউনলোড করো</button><span class="small muted" id="dlMsg"></span></section>
  <section class="card stack" style="gap:8px"><h2 class="h-card">অধ্যায় ও ফাইলের গঠন</h2>
  <div class="table-wrap"><table class="t sm"><thead><tr><th>অধ্যায়</th><th>id</th><th>অংশ</th><th>পাঠ</th><th>MCQ</th></tr></thead><tbody>${CHAPTERS.map(c => `<tr><td>${chLabel(c)}<br><span class="small muted">${c.t}</span></td><td class="mono">${c.id}</td><td>${bn(c.S.length)}</td><td>${bn(c.L.length)}</td><td>${bn(c.S.reduce((a, x) => a + x.allM.length, 0))}</td></tr>`).join('')}</tbody></table></div>
  ${PROB.length ? `<div class="stack" style="gap:6px"><b style="color:var(--bad)">⚠ ${bn(PROB.length)}টি গঠনগত সমস্যা</b><ul class="pts small" style="margin:0">${PROB.slice(0, 40).map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>` : `<p class="small muted" style="margin:0">${ico('check')} কোনো গঠনগত সমস্যা নেই — সব id অনন্য, সব চিত্র ও প্রশ্ন ঠিক আছে।</p>`}
  <p class="small muted" style="margin:0">নতুন অধ্যায় যোগ করতে HTML ফাইলটি খুলে একেবারে শেষের “নতুন অধ্যায় এখানে যোগ করো” অংশে দেওয়া ছাঁচ অনুযায়ী কোড বসাও।</p></section>
  <section class="card stack" style="gap:8px"><h2 class="h-card">অগ্রগতি মুছে ফেলো</h2>${resetCardBody()}</section></div>`
});
function themeOpts() {
  const on = themeKey();
  return `<div class="theme-opts">${THEMES.map(([k, n, d, sw, lv]) => { const open = themeOpen(k); return `<button class="theme-opt ${on === k ? 'on' : ''} ${open ? '' : 'locked'}" data-act="theme" data-k="${k}"><span class="sw">${sw.map(c => `<i style="background:${c}"></i>`).join('')}</span><b>${n}</b><small>${open ? d : `লেভেল ${bn(lv)} এ পৌঁছালে খুলবে — পাঠ পড়ো ও প্রশ্নের উত্তর দিয়ে XP জমাও`}</small></button>`; }).join('')}</div>`;
}
function openSheet(html) {
  closeSheet();
  const w = document.createElement('div'); w.className = 'sheet-wrap'; w.id = 'sheetWrap';
  w.innerHTML = `<div class="sheet" role="dialog" aria-modal="true"><div class="grab"></div>${html}</div>`;
  w.addEventListener('click', e => { if (e.target === w) closeSheet(); });
  document.body.appendChild(w);
}
function closeSheet() { const w = $('#sheetWrap'); if (w) w.remove(); }

/* ---------- Mega test ---------- */
const MEGA_PARTS = [
  ['A', 'MCQ', 100, 'বহুনির্বাচনী — স্বয়ংক্রিয় মূল্যায়ন', 0.40],
  ['B', 'সংক্ষিপ্ত প্রশ্ন', 50, 'উত্তর দেখে নিজে নম্বর দাও', 0.15],
  ['C', 'সৃজনশীল প্রশ্ন (CQ)', 20, 'ক-খ-গ-ঘ, প্রতিটি ১০ নম্বর', 0.25],
  ['D', 'বিশ্লেষণধর্মী প্রশ্ন', 10, 'যুক্তি ও হিসাব', 0.10],
  ['E', 'HOTS সেট', 5, 'প্রতি সেটে ৩টি উচ্চতর চিন্তন প্রশ্ন', 0.10]
];
function sampleAcross(getList, n) {
  const per = SECS.map(s => shuffle(getList(s).map((x, i) => [s.id, i])));
  const out = []; let k = 0;
  while (out.length < n && per.some(p => p.length)) { const p = per[k % per.length]; if (p.length) out.push(p.pop()); k++; }
  return shuffle(out);
}
function newMega() {
  const hq = sampleAcross(s => s.Q.hq, 15);
  S.megaRun = {
    at: Date.now(),
    A: { items: sampleAcross(s => s.allM, 100).map(([sid, i]) => SMAP[sid].allM[i]), ans: {}, done: false, i: 0, start: null },
    B: { items: sampleAcross(s => s.Q.sq, 50), marks: {}, done: false },
    C: { items: sampleAcross(s => s.Q.cq, 20), marks: {}, done: false, i: 0 },
    D: { items: sampleAcross(s => s.Q.nq, 10), marks: {}, done: false },
    E: { items: [0, 1, 2, 3, 4].map(k => hq.slice(k * 3, k * 3 + 3)).filter(x => x.length), marks: {}, done: false }
  };
  save();
}
function partScore(P, k) {
  const r = S.megaRun[P]; if (!r) return null;
  if (P === 'A') { const n = r.items.length; let c = 0; r.items.forEach(id => { if (r.ans[id] === MCQ[id].a) c++; }); return n ? c / n : 0; }
  if (P === 'C') { const max = r.items.length * 10; const got = Object.values(r.marks).reduce((a, b) => a + b, 0); return max ? got / max : 0; }
  if (P === 'E') { const n = r.items.reduce((a, s) => a + s.length, 0); const got = Object.values(r.marks).reduce((a, b) => a + b, 0); return n ? got / n : 0; }
  const n = r.items.length; const got = Object.values(r.marks).reduce((a, b) => a + b, 0); return n ? got / n : 0;
}
VIEWS.mega = () => {
  const R = S.megaRun;
  const head = `<div><span class="eyebrow">অধ্যায় চূড়ান্ত মূল্যায়ন</span><h1 class="h-sec">মেগা টেস্ট</h1><p class="muted small" style="margin:4px 0 0">পাঁচটি অংশ যেকোনো ক্রমে দাও। মাঝপথে বন্ধ করলেও যেখানে ছিলে সেখান থেকে চলবে। সব অংশ জমা দিলে পূর্ণ রিপোর্ট পাবে।</p></div>`;
  if (!R) return { title: 'মেগা টেস্ট', nav: 'practice', html: `<div class="wrap stack">${head}<div class="card stack">${MEGA_PARTS.map(([k, n, c, d]) => `<div class="mega-part"><span class="pi">${k}</span><div><b>${n} · ${bn(c)}টি</b><div class="small muted">${d}</div></div></div>`).join('')}</div><button class="btn primary" data-act="megaNew">${ico('play')}মেগা টেস্ট শুরু করো</button>${S.mega ? `<button class="btn" data-act="go" data-v="megaReport">সর্বশেষ রিপোর্ট দেখো</button>` : ''}</div>` };
  const doneN = MEGA_PARTS.filter(([k]) => R[k].done).length;
  return {
    title: 'মেগা টেস্ট', nav: 'practice',
    html: `<div class="wrap stack">${head}
    <div class="card stack" style="gap:6px"><div class="row"><b>${bn(doneN)}/৫ অংশ জমা</b><span class="sp"></span><span class="small muted">শুরু: ${dateBn(new Date(R.at))}</span></div>${bar(doneN / 5 * 100, 'ok')}</div>
    ${MEGA_PARTS.map(([k, n, c, d]) => { const r = R[k]; const cnt = k === 'E' ? r.items.length : r.items.length; const sc = r.done ? partScore(k) : null; return `<button class="card mega-part" style="text-align:left;color:inherit" data-act="megaPart" data-p="${k}"><span class="pi">${k}</span><span style="flex:1;min-width:0"><b>${n} · ${bn(cnt)}টি</b><span class="small muted" style="display:block">${r.done ? 'জমা দেওয়া হয়েছে · স্কোর ' + bn(Math.round(sc * 100)) + '%' : d}</span></span>${r.done ? '<span class="chip ok">সম্পন্ন</span>' : ico('next')}</button>`; }).join('')}
    <div class="grid2"><button class="btn primary" data-act="megaFinish" ${doneN ? '' : 'disabled'}>${ico('chart')}রিপোর্ট তৈরি করো</button><button class="btn" data-act="megaReset" id="megaResetBtn">${ico('repeat')}নতুন টেস্ট</button></div></div>`
  };
};
VIEWS.megaA = () => {
  if (!S.megaRun || !S.megaRun.A || !S.megaRun.A.items) return VIEWS.mega();
  const R = S.megaRun.A; if (!R.start) { R.start = Date.now(); save({ cloud: false }); }
  const id = R.items[R.i], m = MCQ[id];
  const answered = Object.keys(R.ans).length;
  const pal = R.items.map((qid, k) => `<button class="btn sm ${k === R.i ? 'primary' : R.ans[qid] != null ? 'soft' : ''}" style="min-width:40px;padding:4px" data-act="megaJump" data-i="${k}">${bn(k + 1)}</button>`).join('');
  return {
    title: 'মেগা টেস্ট · MCQ', nav: 'practice',
    html: `<div class="wrap stack"><div class="row"><b>প্রশ্ন ${bn(R.i + 1)}/${bn(R.items.length)}</b><span class="sp"></span><span class="small muted">উত্তর ${bn(answered)}</span><span class="timer" id="mTimer"></span></div>${bar(answered / R.items.length * 100)}
    <div class="qcard"><div class="qhead"><span class="chip">${SMAP[m.sid].no}</span><span class="chip ${m.d}">${DL[m.d]}</span></div><div class="qtext">${m.q}</div>
    <div class="opts">${m.o.map((o, i) => `<button class="opt ${R.ans[id] === i ? 'sel' : ''}" data-act="megaPick" data-i="${i}"><span class="ol" ${R.ans[id] === i ? 'style="background:var(--accent);color:var(--accent-ink)"' : ''}>${OL[i]}</span><span>${o}</span></button>`).join('')}</div></div>
    <div class="grid2"><button class="btn" data-act="megaStep" data-d="-1" ${R.i ? '' : 'disabled'}>${ico('prev')}আগের</button><button class="btn primary" data-act="megaStep" data-d="1" ${R.i < R.items.length - 1 ? '' : 'disabled'}>পরের${ico('next')}</button></div>
    <details class="blk"><summary><span class="bi">${ico('grid')}</span>প্রশ্ন তালিকা (যেকোনোটিতে যাও)<span class="chev">${ico('chev')}</span></summary><div class="bd"><div class="row" style="gap:6px">${pal}</div></div></details>
    <button class="btn" data-act="megaSubmitA" id="megaSubA">${ico('check')}MCQ অংশ জমা দাও (${bn(answered)}/${bn(R.items.length)} উত্তর)</button></div>`,
    after() { const t = setInterval(() => { const e = Math.floor((Date.now() - R.start) / 1000); const el = $('#mTimer'); if (el) el.textContent = bn(Math.floor(e / 60)) + ':' + bn(String(e % 60).padStart(2, '0')) + ' / ১০০:০০'; }, 1000); cleanups.push(() => clearInterval(t)); }
  };
};
function selfMarkHTML(P, key, max, val) {
  const opts = max === 1 ? [[0, 'পারিনি'], [0.5, 'আংশিক'], [1, 'পেরেছি']] : Array.from({ length: max + 1 }, (_, i) => [i, bn(i)]);
  return `<div class="selfmark" role="group" aria-label="নিজের নম্বর">${max === 1 ? '' : '<span class="small muted" style="align-self:center">নম্বর:</span>'}${opts.map(([v, n]) => `<button class="${val === v ? 'on' : ''}" data-act="megaMark" data-p="${P}" data-key="${key}" data-v="${v}">${n}</button>`).join('')}</div>`;
}
VIEWS.megaSelf = ({ p }) => {
  if (!S.megaRun || !S.megaRun[p] || !MEGA_PARTS.find(x => x[0] === p)) return VIEWS.mega();
  const R = S.megaRun[p]; const name = MEGA_PARTS.find(x => x[0] === p)[1];
  let body = '';
  if (p === 'B' || p === 'D') {
    const tab = p === 'B' ? 'sq' : 'nq';
    body = R.items.map(([sid, i], k) => { const it = SMAP[sid].Q[tab][i]; const key = sid + ':' + i; return `<div class="qcard"><div class="qhead"><span class="chip">${bn(k + 1)}</span><span class="chip">${SMAP[sid].no}</span></div><div class="q">${it[0]}</div><button class="btn sm soft reveal-btn" data-act="reveal">${ico('eye')}মডেল উত্তর</button><div class="ans" hidden>${it[1]}</div>${selfMarkHTML(p, key, 1, R.marks[key])}</div>`; }).join('');
  } else if (p === 'C') {
    body = R.items.map(([sid, i], k) => { const c = SMAP[sid].Q.cq[i]; return cqHTML(c, k, { label: 'CQ ' + bn(k + 1) + ' · ' + SMAP[sid].no, mark: j => selfMarkHTML('C', sid + ':' + i + ':' + j, j + 1, R.marks[sid + ':' + i + ':' + j]) }); }).join('');
  } else if (p === 'E') {
    body = R.items.map((set, k) => `<div class="card stack" style="gap:6px"><b>HOTS সেট ${bn(k + 1)}</b>${set.map(([sid, i]) => { const it = SMAP[sid].Q.hq[i]; const key = sid + ':' + i; return `<div class="qa"><div class="q"><span class="chip">${SMAP[sid].no}</span> ${it[0]}</div><button class="btn sm soft reveal-btn" data-act="reveal">${ico('eye')}মডেল উত্তর</button><div class="ans" hidden>${it[1]}</div>${selfMarkHTML('E', key, 1, R.marks[key])}</div>`; }).join('')}</div>`).join('');
  }
  const marked = Object.keys(R.marks).length;
  return {
    title: 'মেগা টেস্ট · ' + name, nav: 'practice',
    html: `<div class="wrap stack"><div><span class="eyebrow">অংশ ${p}</span><h1 class="h-sec">${name}</h1><p class="small muted" style="margin:4px 0 0">আগে খাতায় নিজে উত্তর লেখো, তারপর মডেল উত্তরের সাথে মিলিয়ে সৎভাবে নম্বর দাও। এই নম্বর দিয়েই তোমার দুর্বল জায়গা নির্ণয় হবে।</p></div>${body}
    <button class="btn primary" data-act="megaSubmitSelf" data-p="${p}">${ico('check')}এই অংশ জমা দাও (${bn(marked)}টি মূল্যায়িত)</button></div>`
  };
};
function computeMega() {
  const R = S.megaRun; const parts = {}; let wsum = 0, ssum = 0;
  MEGA_PARTS.forEach(([k, , , , w]) => { if (R[k].done) { const sc = partScore(k); parts[k] = Math.round(sc * 100); wsum += w; ssum += w * sc; } });
  const mastery = wsum ? Math.round(ssum / wsum * 100) : 0;
  const bySec = {};
  const add = (sid, got, max) => { const b = bySec[sid] || (bySec[sid] = [0, 0]); b[0] += got; b[1] += max; };
  if (R.A.done) R.A.items.forEach(id => add(MCQ[id].sid, R.A.ans[id] === MCQ[id].a ? 1 : 0, 1));
  if (R.B.done) R.B.items.forEach(([sid, i]) => add(sid, R.B.marks[sid + ':' + i] || 0, 1));
  if (R.D.done) R.D.items.forEach(([sid, i]) => add(sid, R.D.marks[sid + ':' + i] || 0, 1));
  if (R.C.done) R.C.items.forEach(([sid, i]) => { let g = 0; for (let j = 0; j < 4; j++) g += R.C.marks[sid + ':' + i + ':' + j] || 0; add(sid, g / 10 * 2, 2); });
  if (R.E.done) R.E.items.forEach(set => set.forEach(([sid, i]) => add(sid, R.E.marks[sid + ':' + i] || 0, 1)));
  const secPct = Object.entries(bySec).filter(([, b]) => b[1] > 0).map(([sid, b]) => [sid, Math.round(b[0] / b[1] * 100), b[1]]).sort((a, b) => a[1] - b[1]);
  const weak = secPct.filter(x => x[1] < 60);
  const hardIds = R.A.done ? R.A.items.filter(id => MCQ[id].d === 'h') : [];
  const hardAcc = hardIds.length ? hardIds.filter(id => R.A.ans[id] === MCQ[id].a).length / hardIds.length : (mastery / 100);
  const g = globalStats();
  const consistency = Math.min(1, daysActive(14) / 10);
  const lq = Math.round(100 * (0.35 * mastery / 100 + 0.25 * g.done / Math.max(1, g.total) + 0.15 * consistency + 0.25 * hardAcc));
  const planSrc = (weak.length ? weak : secPct.slice(0, 3)).slice(0, 6);
  const plan = planSrc.map(([sid, p]) => { const s = SMAP[sid]; const st = secStats(s); return { sid, p, lessons: s.L.filter(l => !S.done[l.id]).length || s.L.length, mins: Math.max(20, st.minsLeft || s.L.reduce((a, l) => a + readMin(l), 0)) }; });
  S.mega = { at: Date.now(), parts, mastery, lq, secPct, weak: weak.map(w => w[0]), plan, hardAcc: Math.round(hardAcc * 100) };
  save();
}
VIEWS.megaReport = () => {
  const M = S.mega; if (!M) return VIEWS.mega();
  const lvl = M.mastery >= 85 ? 'অসাধারণ — বোর্ড ও ভর্তি পরীক্ষার জন্য প্রস্তুত' : M.mastery >= 70 ? 'ভালো — কিছু জায়গা শক্ত করলেই A+' : M.mastery >= 50 ? 'মাঝারি — পরিকল্পনামতো রিভিশন দরকার' : 'প্রাথমিক — ভিত্তি থেকে আবার পড়ো';
  return {
    title: 'মেগা টেস্ট রিপোর্ট', nav: 'practice',
    html: `<div class="wrap stack"><div><span class="eyebrow">${dateBn(new Date(M.at))}</span><h1 class="h-sec">চূড়ান্ত মূল্যায়ন রিপোর্ট</h1></div>
    <div class="card row" style="gap:16px;justify-content:space-around">${ring(M.mastery, 128, 11, 'চ্যাপ্টার মাস্টারি')}${ring(M.lq, 128, 11, 'লার্নিং কোয়ালিটি')}</div>
    <div class="note"><b>${lvl}।</b> লার্নিং কোয়ালিটি স্কোর তৈরি হয়েছে মেগা টেস্টের ফল, পাঠ সম্পন্নের হার, পড়ার ধারাবাহিকতা এবং কঠিন প্রশ্নে নির্ভুলতা (${bn(M.hardAcc)}%) মিলিয়ে।</div>
    <div class="card stack" style="gap:10px"><b>অংশভিত্তিক স্কোর</b>${MEGA_PARTS.map(([k, n]) => M.parts[k] == null ? `<div class="row small"><span>${k}. ${n}</span><span class="sp"></span><span class="muted">জমা হয়নি</span></div>` : `<div><div class="row small"><span>${k}. ${n}</span><span class="sp"></span><b>${bn(M.parts[k])}%</b></div>${bar(M.parts[k], M.parts[k] >= 60 ? 'ok' : 'a2')}</div>`).join('')}</div>
    <div class="card stack" style="gap:10px"><b>দুর্বল বিষয় নির্ণয়</b>${M.secPct.length ? M.secPct.map(([sid, p]) => `<div><div class="row small"><span>${SMAP[sid].no} ${SMAP[sid].st || SMAP[sid].t}</span><span class="sp"></span><span class="chip ${p < 60 ? 'bad' : p < 80 ? 'warn' : 'ok'}">${bn(p)}%</span></div>${bar(p, p < 60 ? '' : 'ok')}</div>`).join('') : '<span class="muted">মূল্যায়নের তথ্য নেই।</span>'}</div>
    <div class="card stack" style="gap:8px"><b>ব্যক্তিগত রিভিশন পরিকল্পনা</b><p class="small muted" style="margin:0">${M.weak.length ? 'যে অংশে ৬০%-এর কম পেয়েছ সেগুলো আগে।' : 'কোনো অংশ ৬০%-এর নিচে নেই — তুলনামূলক কম স্কোরের অংশ দিয়ে পরিকল্পনা।'} প্রতিদিন একটি অংশ।</p>
    <ol class="steps" style="margin:0">${M.plan.map((p, k) => { const s = SMAP[p.sid]; return `<li><b>দিন ${bn(k + 1)} — ${s.no} ${s.t}</b> (বর্তমান ${bn(p.p)}%)<br><span class="small">১) ${bn(s.L.length)}টি পাঠের "সংক্ষিপ্ত নোট" ও "সাধারণ ভুল" পড়ো (~${bn(Math.min(p.mins, 60))} মি.) · ২) ফর্মুলা শিটের সূত্রগুলো খাতায় লেখো · ৩) প্রশ্নব্যাংকের সৃজনশীল প্রশ্ন ১টি লিখে মিলাও · ৪) অ্যাডাপটিভ কুইজে ৮০%+ লক্ষ্য</span><br><button class="btn sm soft" style="margin-top:6px" data-act="sec" data-id="${s.id}">অংশটি খোলো</button></li>`; }).join('')}<li><b>দিন ${bn(M.plan.length + 1)} — মিশ্র রিভিশন</b><br><span class="small">রিভিশন মোড পড়ো, ভুল প্রশ্নগুলো আবার করো, তারপর নতুন মেগা টেস্ট দাও।</span></li></ol></div>
    <div class="grid2"><button class="btn" data-act="go" data-v="mega">মেগা টেস্টে ফিরে যাও</button><button class="btn primary" data-act="go" data-v="revision">রিভিশন মোড</button></div></div>`
  };
};

/* ---------------- highlights ---------------- */
function textNodesIn(root) {
  const out = []; const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(n) { const p = n.parentNode; if (!p || !p.closest) return NodeFilter.FILTER_REJECT; if (p.closest('svg,script,style,textarea,button,.fig,.ans,summary,select')) return NodeFilter.FILTER_REJECT; return n.nodeValue.length ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT; }
  });
  let n; while ((n = w.nextNode())) out.push(n); return out;
}
function findAndWrap(root, needle, cls) {
  const norm = String(needle).replace(/\s+/g, ' ').trim(); if (!norm || !root) return null;
  const nodes = textNodesIn(root); let flat = ''; const map = []; let ps = false;
  nodes.forEach((n, ni) => { const v = n.nodeValue; for (let k = 0; k < v.length; k++) { const sp = /\s/.test(v[k]); if (sp) { if (ps) continue; flat += ' '; ps = true; } else { flat += v[k]; ps = false; } map.push([ni, k]); } });
  let idx = flat.indexOf(norm);
  if (idx < 0) idx = flat.toLowerCase().indexOf(norm.toLowerCase());
  if (idx < 0) return null;
  const parts = new Map();
  for (let i = idx; i < idx + norm.length; i++) { const [ni, k] = map[i]; const p = parts.get(ni); if (!p) parts.set(ni, [k, k]); else p[1] = k; }
  let first = null;
  for (const [ni, [a, b]] of parts) { const node = nodes[ni]; try { const r = document.createRange(); r.setStart(node, a); r.setEnd(node, b + 1); const m = document.createElement('mark'); m.className = cls; m.dataset.hl = needle; r.surroundContents(m); if (!first) first = m; } catch (e) { } }
  return first;
}
let hlMode = null;
function hideHl() { $('#hlbar').hidden = true; hlMode = null; }
document.addEventListener('selectionchange', () => {
  clearTimeout(hideHl._t);
  hideHl._t = setTimeout(() => {
    const body = $('#lessonBody'); const sel = getSelection();
    if (!body || !sel || sel.isCollapsed) { if (hlMode && hlMode.type === 'add') hideHl(); return; }
    const t = sel.toString().trim();
    if (t.length < 2 || t.length > 600 || !body.contains(sel.anchorNode) || !body.contains(sel.focusNode)) { if (hlMode && hlMode.type === 'add') hideHl(); return; }
    hlMode = { type: 'add', text: t, id: body.dataset.id };
    $('#hlIn').innerHTML = `<span class="hl-lab">হাইলাইট:</span>${[['y', 'হলুদ'], ['g', 'সবুজ'], ['p', 'গোলাপি'], ['b', 'নীল']].map(([c, n]) => `<button data-act="hlAdd" data-c="${c}" aria-label="${n}" title="${n}"><span class="sw hl-${c}"></span></button>`).join('')}<button data-act="hlCancel" aria-label="বাতিল">${ico('x')}</button>`;
    $('#hlbar').hidden = false;
  }, 180);
});

/* ---------------- actions ---------------- */
const ACT = {
  back: () => back(), drawer: () => toggleDrawer(),
  djToggle: b => b.parentNode.classList.toggle('open'),
  go: b => { const a = {}; if (b.dataset.ch && CHMAP[b.dataset.ch]) setCh(b.dataset.ch); if (b.dataset.sid) a.sid = b.dataset.sid; if (b.dataset.q) a.q = b.dataset.q; if (b.dataset.v === 'flash' && a.sid !== (FC && FC.sid)) FC = null; go(b.dataset.v, a); },
  sec: b => go('section', { sid: b.dataset.id }),
  lesson: b => go('lesson', { id: b.dataset.id, find: b.dataset.find }),
  bank: b => go('bank', { id: b.dataset.id, tab: b.dataset.tab || 'mcq' }),
  bankTab: b => { cur.args.tab = b.dataset.tab; cur.args.diff = 'all'; render(); },
  bankDiff: b => { cur.args.diff = b.dataset.d; render(true); },
  libTab: b => { if (cur.name !== 'library') { go('library', { tab: b.dataset.tab }); return; } cur.args.tab = b.dataset.tab; render(); },
  reveal: b => { const a = b.nextElementSibling; a.hidden = !a.hidden; b.innerHTML = a.hidden ? ico('eye') + (b.textContent.includes('মডেল') ? 'মডেল উত্তর দেখো' : 'উত্তর দেখো') : ico('x') + 'উত্তর লুকাও'; if (!a.hidden) mountFigsIn(a); },
  bm: b => { const id = b.dataset.id; if (S.bm[id]) delete S.bm[id]; else S.bm[id] = Date.now(); save(); render(true); toast(S.bm[id] ? 'বুকমার্ক করা হলো' : 'বুকমার্ক সরানো হলো'); },
  done: b => {
    const id = b.dataset.id, l = LMAP[id];
    if (S.done[id]) { delete S.done[id]; save(); render(true); toast('অসম্পন্ন হিসেবে চিহ্নিত'); return; }
    S.done[id] = Date.now(); touch('l', l.sid); pop(b);
    const nx = LESSONS[l.gi + 1];
    render(true);
    const td = S.days[dkey()];
    const goalMsg = td.l === S.goal.l ? ' আজকের লক্ষ্য পূরণ!' : '';
    toast('✅ পাঠ সম্পন্ন! +১০ XP' + goalMsg, nx ? 'পরের পাঠ' : null, () => nx && go('lesson', { id: nx.id }));
  },
  pmcq: b => {
    const card = b.closest('.qcard'); if (card.dataset.done) return; card.dataset.done = 1;
    const m = MCQ[b.dataset.q], pick = +b.dataset.i, ok = pick === m.a;
    recordQ(m.id, ok);
    $$('.opt', card).forEach((x, k) => { x.disabled = true; if (k === m.a) x.classList.add('right'); if (k === pick && !ok) x.classList.add('wrong'); });
    $('.fb', card).innerHTML = feedbackHTML(m, pick);
    if (card.closest('#lx')) exScore();
    qpMark(card, ok);
    try { comboHit(ok); } catch (e) { }
  },
  quiz: b => startQuiz(b.dataset.id, b.dataset.mode || 'adaptive'),
  qpick: b => quizPick(b),
  qpMode: b => { S.mcqMode = b.dataset.m; save({ cloud: false }); qpApplyMode(); },
  qpStep: b => { const pg = b.closest('.qpager'); if (pg) qpShow(pg, (+pg.dataset.i || 0) + +b.dataset.d, true); },
  qpGo: b => { const pg = b.closest('.qpager'); if (pg) qpShow(pg, +b.dataset.k, true); },
  qprev: () => { if (!QZ) return; const i = QZ.asked.length, vi = QZ.rv != null ? QZ.rv : i - 1; if (vi > 0) { QZ.rv = vi - 1; render(true); } },
  qfwd: () => { if (!QZ || QZ.rv == null) return; QZ.rv = QZ.rv + 1 >= QZ.asked.length - 1 ? null : QZ.rv + 1; render(true); },
  qnext: () => { if (QZ.asked.length >= QZ.n) finishQuiz(); else { nextQ(); render(); } },
  qquit: () => { QZ = null; back(); },
  fcFlip: () => { FC.flip = !FC.flip; $('#flashCard').classList.toggle('flip', FC.flip); },
  fcMark: b => { const c = FC.order[FC.i]; if (!c) return; S.fc[c.id] = b.dataset.k === '1' ? Math.min(3, (S.fc[c.id] || 0) + 1) : 0; touch('q', c.sid, 0.5); FC.i = (FC.i + 1) % FC.order.length; FC.flip = false; render(true); },
  fcStep: b => { FC.i = (FC.i + +b.dataset.d + FC.order.length) % FC.order.length; FC.flip = false; render(true); },
  fcShuffle: () => { FC.order = shuffle(FC.order); FC.i = 0; FC.flip = false; render(true); },
  goal: b => { const k = b.dataset.k; S.goal[k] = clamp(S.goal[k] + +b.dataset.d, k === 'l' ? 1 : 5, k === 'l' ? 15 : 300); save(); render(true); },
  theme: b => { if (!themeOpen(b.dataset.k)) { toast('🔒 এই থিম খুলবে লেভেল ' + bn(themeLock(b.dataset.k)) + ' এ — এখন তুমি লেভেল ' + bn(xpInfo().L)); return; } S.theme = b.dataset.k; save(); applyTheme(); $$('.theme-opt').forEach(x => x.classList.toggle('on', x.dataset.k === S.theme)); toast('থিম: ' + THEMES.find(t => t[0] === S.theme)[1]); },
  chSheet: () => openSheet(chSheetHTML()),
  subjSheet: () => openSheet(chSheetHTML()),
  subj: b => { const x = SUBMAP[b.dataset.id]; if (!x) return; closeSheet(); const want = (S.chBy && S.chBy[x.id]) || (x.chs.find(c => CHMAP[c.id]) || {}).id; if (!want) { toast(x.t + ' — শীঘ্রই আসছে'); return; } if (want !== CH.id) { setCh(want); save(); } stack.length = 0; IDX = null; go('home', {}, { replace: true }); },
  chOpen: b => { const id = b.dataset.id; if (!CHMAP[id]) return; closeSheet(); if (id !== CH.id) { setCh(id); save(); IDX = null; } stack.length = 0; go('home', {}, { replace: true }); },
  chPickSheet: () => openSheet(`<h2 class="h-card" style="margin-bottom:4px">অধ্যায় বেছে নাও</h2><p class="small muted" style="margin:0 0 12px">${subjOf(CH).t}</p>${chRows(subjOf(CH))}<button class="btn block" style="margin-top:14px" data-act="closeSheet">বন্ধ করো</button>`),
  dlApp: async () => {
    const msg = $('#dlMsg'); if (msg) msg.textContent = 'ফাইল তৈরি হচ্ছে…';
    try {
      let html = window.__HSC_SRC || ('<!doctype html>\n' + document.documentElement.outerHTML);
      const srcs = [...html.matchAll(/<script src="([^"]+)"><\/script>/g)].map(m => m[1]);
      for (const u of srcs) { const r = await fetch(u); if (!r.ok) throw new Error(u); const js = (await r.text()).replace(/<\/script/gi, '<\\/script'); html = html.replace(`<script src="${u}"><\/script>`, () => `<script>\n${js}\n<\/script>`); }
      const dlc = window.claude && window.claude.use ? await window.claude.use('downloads').catch(() => null) : null;
      if (dlc) {
        try { await dlc.save({ filename: 'hsc-physics.html', data: new Blob([html], { type: 'text/html' }) }); if (msg) msg.textContent = 'ডাউনলোড সম্পন্ন — ফাইলটি ব্রাউজারে খোলো।'; }
        catch (e) { if (msg) msg.textContent = e && e.code === 'declined' ? 'ডাউনলোড বাতিল করা হয়েছে।' : e && e.code === 'rate_limited' ? 'একটু পরে আবার চেষ্টা করো।' : 'এই পরিবেশে ডাউনলোড চালানো যাচ্ছে না — চ্যাটে পাঠানো ফাইলটি ব্যবহার করো।'; }
        return;
      }
      const blob = new Blob([html], { type: 'text/html' }), a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = 'hsc-physics.html'; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
      if (msg) msg.textContent = 'ডাউনলোড শুরু হয়েছে। না হলে চ্যাটে পাঠানো ফাইলটি ব্যবহার করো।';
    } catch (e) { if (msg) msg.textContent = 'এই পরিবেশে সরাসরি ডাউনলোড আটকানো — চ্যাটে পাঠানো hsc-physics.html ফাইলটি ব্যবহার করো।'; }
  },
  outline: b => { const c = (HSC.chapters || []).find(x => x.id === b.dataset.id); if (!c) return; openSheet(`<span class="eyebrow">${c.paper} · অধ্যায় ${c.no}</span><h2 class="h-card" style="margin:2px 0 4px">${c.t}</h2><p class="small muted" style="margin:0 0 10px">এই অধ্যায়ের কাজ চলছে। বইয়ের সূচিপত্র অনুযায়ী সব অনুচ্ছেদ নিচে — লেখা শেষ হলে এখানেই খুলবে।</p>${outlineHTML(c)}<button class="btn block" style="margin-top:14px" data-act="closeSheet">বন্ধ করো</button>`); },
  ch: b => ACT.chOpen(b),
  themeSheet: () => openSheet(`<h2 class="h-card" style="margin-bottom:10px">থিম বেছে নাও</h2>${themeOpts()}<button class="btn block" style="margin-top:12px" data-act="closeSheet">ঠিক আছে</button>`),
  closeSheet: () => closeSheet(),
  reset: b => {
    if (S.resetAt) return;
    if (!b.dataset.arm) { b.dataset.arm = 1; b.innerHTML = ico('alert') + 'নিশ্চিত? আবার চাপলে সব মুছে যাবে'; setTimeout(() => { if (b.isConnected) { delete b.dataset.arm; b.innerHTML = ico('trash') + 'সব অগ্রগতি মুছো'; } }, 5000); return; }
    S.resetAt = Date.now() + RESET_DELAY; save(); toast('৪৮ ঘণ্টা পর অগ্রগতি মুছে যাবে — এর মধ্যে সেটিংস থেকে বাতিল করা যাবে'); render(true);
  },
  hlAdd: b => { if (!hlMode) return; const { text, id } = hlMode, c = (b && b.dataset.c) || 'y'; (S.hl[id] || (S.hl[id] = [])).push({ t: text, c }); save(); const body = $('#lessonBody'); findAndWrap(body, text, 'hl hl-' + c); try { msCheck(); } catch (e) { } try { getSelection().removeAllRanges(); } catch (e) { } hideHl(); toast('হাইলাইট সংরক্ষিত'); },
  hlCancel: () => { try { getSelection().removeAllRanges(); } catch (e) { } hideHl(); },
  hlRemove: () => { if (!hlMode) return; const arr = S.hl[hlMode.id] || []; const i = arr.findIndex(h => (typeof h === 'string' ? h : h.t) === hlMode.text); if (i >= 0) arr.splice(i, 1); save(); hideHl(); render(true); toast('হাইলাইট মুছে ফেলা হলো'); },
  hlDel: b => { const arr = S.hl[b.dataset.id] || []; arr.splice(+b.dataset.i, 1); save(); render(true); },
  megaNew: () => { newMega(); render(); },
  megaReset: b => { if (!b.dataset.arm) { b.dataset.arm = 1; b.textContent = 'নিশ্চিত? আবার চাপো'; setTimeout(() => { if (b.isConnected) { delete b.dataset.arm; b.innerHTML = ico('repeat') + 'নতুন টেস্ট'; } }, 4000); return; } newMega(); render(); toast('নতুন প্রশ্ন দিয়ে মেগা টেস্ট তৈরি হলো'); },
  megaPart: b => { const p = b.dataset.p; if (p === 'A') go('megaA'); else go('megaSelf', { p }); },
  megaPick: b => { const R = S.megaRun.A; R.ans[R.items[R.i]] = +b.dataset.i; save({ cloud: false }); if (R.i < R.items.length - 1) { setTimeout(() => { R.i++; render(); }, 160); } else render(true); },
  megaStep: b => { const R = S.megaRun.A; R.i = clamp(R.i + +b.dataset.d, 0, R.items.length - 1); save({ cloud: false }); render(); },
  megaJump: b => { S.megaRun.A.i = +b.dataset.i; render(); },
  megaSubmitA: b => {
    const R = S.megaRun.A; const un = R.items.length - Object.keys(R.ans).length;
    if (un > 0 && !b.dataset.arm) { b.dataset.arm = 1; b.textContent = bn(un) + 'টি উত্তর বাকি — তবুও জমা দিতে আবার চাপো'; return; }
    R.done = true; R.items.forEach(id => { if (R.ans[id] != null) recordQ(id, R.ans[id] === MCQ[id].a); }); save(); toast('MCQ অংশ জমা হয়েছে · স্কোর ' + bn(Math.round(partScore('A') * 100)) + '%'); go('mega', {}, { replace: true });
  },
  megaMark: b => { const R = S.megaRun[b.dataset.p]; R.marks[b.dataset.key] = +b.dataset.v; save({ cloud: false }); $$('button', b.parentNode).forEach(x => x.classList.toggle('on', x === b)); },
  megaSubmitSelf: b => { const R = S.megaRun[b.dataset.p]; R.done = true; save(); toast('অংশ ' + b.dataset.p + ' জমা হয়েছে'); go('mega', {}, { replace: true }); },
  megaFinish: () => { computeMega(); go('megaReport'); },
  lxReset: b => { const l = LMAP[b.dataset.id], box = $('#lx'); if (!l || !box) return; const t = document.createElement('div'); t.innerHTML = exHTML(l, true); box.replaceWith(t.firstElementChild); const nb = $('#lx'); if (nb) nb.scrollIntoView({ block: 'start', behavior: 'smooth' }); toast('অনুশীলনী নতুন করে শুরু হলো'); }
};
function mountFigsIn(el) { mountFigs(); }
document.addEventListener('click', e => {
  const m = e.target.closest('mark.hl');
  if (m && m.closest('#lessonBody') && getSelection().isCollapsed) {
    hlMode = { type: 'rm', text: m.dataset.hl, id: $('#lessonBody').dataset.id };
    $('#hlIn').innerHTML = `<button data-act="hlRemove">${ico('trash')}হাইলাইট মুছো</button><button data-act="hlCancel">${ico('x')}</button>`;
    $('#hlbar').hidden = false; return;
  }
  const a = e.target.closest('[data-act]'); if (!a) return;
  const f = ACT[a.dataset.act]; if (f) { e.preventDefault(); f(a, e); try { msSoon(); } catch (er) { } }
});
$('#hlbar').addEventListener('mousedown', e => e.preventDefault());
document.addEventListener('keydown', e => {
  if ((e.key === 'Enter' || e.key === ' ') && e.target.id === 'flashCard') { e.preventDefault(); ACT.fcFlip(); }
  if ((e.key === 'ArrowLeft' || e.key === 'ArrowRight') && !/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) {
    const d = e.key === 'ArrowLeft' ? -1 : 1;
    if (cur && cur.name === 'flash' && FC && FC.order.length) { const j = FC.i + d; if (j >= 0 && j < FC.order.length) { FC.i = j; FC.flip = false; render(true); } }
    else { const pg = $$('.qpager.one').find(x => { const r = x.getBoundingClientRect(); return r.bottom > 0 && r.top < innerHeight; }); if (pg) qpShow(pg, (+pg.dataset.i || 0) + d, false); }
  }
  if (e.key === 'Escape') { closeSheet(); toggleDrawer(false); hideHl(); }
});

/*@@PLUS@@*/
/* ---------------- boot ---------------- */
setCh(S.ch);
applyTheme();
let bootName = 'home', bootArgs = {};
const hash = (location.hash || '').slice(1);
if (hash && LMAP[hash]) { bootName = 'lesson'; bootArgs = { id: hash }; }
else if (hash && SMAP[hash]) { bootName = 'section'; bootArgs = { sid: hash }; }
else if (S.last && S.last.name && VIEWS[S.last.name] && !NOPERSIST[S.last.name]) {
  const a = S.last.args || {}, okRef = (!a.id || LMAP[a.id] || SMAP[a.id] || a.id === 'wrong') && (!a.sid || SMAP[a.sid]) && (!a.ch || CHMAP[a.ch]);
  if (okRef) { if (a.ch && a.ch !== CH.id) setCh(a.ch); bootName = S.last.name; bootArgs = Object.assign({}, a, { y: S.last.y || 0 }); }
}
if (bootName !== 'home') { stack.push({ name: 'home', args: {} }); }
cur = { name: bootName, args: bootArgs };
render(false, true);
if (bootName !== 'home' && !hash) {
  const y = bootArgs.y || 0;
  setTimeout(() => { if (y) window.scrollTo(0, y); }, 350);
  setTimeout(() => toast('যেখানে থেমেছিলে সেখান থেকে শুরু হলো', 'হোমে যাও', () => { stack.length = 0; go('home', {}, { replace: true }); }), 500);
}
if (TOP) { try { history.replaceState({ d: 0 }, ''); } catch (e) { } }
renderDrawer();
syncBadge();
try { frzCheck(); msInit(); } catch (e) { console.warn(e); }
try { if (window.TX) TX.observe(document.body); } catch (e) { console.warn('TX', e); }
cloud.init();
if (PROB.length) { console.warn('[HSC] গঠনগত সমস্যা:\n' + PROB.join('\n')); setTimeout(() => toast('⚠ ফাইলে ' + bn(PROB.length) + 'টি গঠনগত সমস্যা পাওয়া গেছে', 'দেখো', () => go('settings')), 900); }
window.APP = { S: () => S, go, LMAP, SMAP, MCQ, LESSONS: LESSONS_ALL, SECS: SECS_ALL, CHAPTERS, CH: () => CH, setCh, problems: PROB };
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', BOOT, { once: true }); else BOOT();
})();
