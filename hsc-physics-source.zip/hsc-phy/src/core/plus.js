/* ═══════════════ PLUS (ধাপ ১): হোম সাজানো · দ্রুত শুরু · সাপ্তাহিক পড়া · ৩০ দিনের হিটম্যাপ · XP/লেভেল · পছন্দ ও ব্যাকআপ ═══════════════
   app.js এর BOOT() ক্লোজারের ভিতরে বসে (build.py "@@PLUS@@" চিহ্নে যুক্ত করে) — তাই S, VIEWS, ACT, render ইত্যাদি সরাসরি ব্যবহার করা যায়। */
const SET_DEF = { homeOrder: [], homeHidden: {}, examDate: '', examName: 'HSC পরীক্ষা', fs: 1, motion: 'auto' };
const SET = () => (S.set = Object.assign({}, SET_DEF, S.set || {}));
function applyPrefs() { const s = SET(), r = document.documentElement; r.style.setProperty('--fs', s.fs); r.dataset.motion = s.motion; }
const WDS = ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'];
const dOf = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
const fmtMin = m => { m = Math.round(m || 0); return m >= 60 ? bn(Math.floor(m / 60)) + ' ঘ. ' + bn(m % 60) + ' মি.' : bn(m) + ' মি.'; };
const lessonsOn = k => LESSONS_ALL.filter(l => S.done[l.id] && dkey(new Date(S.done[l.id])) === k);

/* ---------- XP ও লেভেল ---------- */
const LVN = ['নবীন', 'শিক্ষার্থী', 'অনুসন্ধানী', 'অধ্যবসায়ী', 'দক্ষ', 'প্রস্তুত', 'মেধাবী', 'অভিজ্ঞ', 'বিশেষজ্ঞ', 'চ্যাম্পিয়ন', 'কিংবদন্তি'];
function xpInfo() {
  let corr = 0, wr = 0; for (const id in S.qs) { const r = S.qs[id] || {}; corr += r.c || 0; wr += r.w || 0; }
  const les = Object.keys(S.done).length, fc = S.fcN || 0, daily = Object.keys(S.daily || {}).length, tests = (S.testsN || 0) + (S.mega ? 1 : 0) + Object.values(S.megaBy || {}).filter(x => x && x.m).length, cq = S.cqN || 0;
  const gm = S.gamesN || 0, gw = S.gameWins || 0;
  const trk = Object.keys(S.trk || {}).length, svn = Object.keys(S.sv || {}).length;
  const xp = les * 10 + corr * 2 + wr + fc + tests * 15 + daily * 30 + cq * 20 + gm * 5 + gw * 5 + trk * 3 + Math.min(svn, 100);
  let L = 1; while (50 * (L + 1) * L <= xp) L++;
  const a = 50 * L * (L - 1), b = 50 * (L + 1) * L;
  return { xp, L, name: LVN[Math.min(L - 1, LVN.length - 1)], f: (xp - a) / (b - a), need: b - xp, parts: [['সম্পন্ন পাঠ × ১০', les * 10], ['সঠিক উত্তর × ২', corr * 2], ['ভুল উত্তর × ১ (চেষ্টার জন্য)', wr], ['ফ্ল্যাশকার্ড রিভিউ × ১', fc], ['টেস্ট × ১৫', tests * 15], ['আজকের চ্যালেঞ্জ × ৩০', daily * 30], ['CQ জমা × ২০', cq * 20], ['খেলা × ৫ + জয় × ৫', gm * 5 + gw * 5], ['আয়ত্ত ট্রিক × ৩', trk * 3], ['★ সংরক্ষণ × ১ (সর্বোচ্চ ১০০)', Math.min(svn, 100)]] };
}

/* ---------- আজকের চ্যালেঞ্জ: তারিখ ও অধ্যায়ভিত্তিক নির্দিষ্ট ১০ প্রশ্ন ---------- */
function dailyPool() {
  const ids = SECS.reduce((a, s) => a.concat(s.allM), []); let h = 0; const k = dkey() + CH.id; for (let i = 0; i < k.length; i++) h = (h * 31 + k.charCodeAt(i)) % 2147483647;
  const r = X0rng(h || 7); const a = ids.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a.slice(0, 10);
}
const X0rng = seed => () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
const dailyDone = () => (S.daily || {})[dkey() + ':' + CH.id];

/* ---------- হোমের অংশসমূহ ---------- */
const HSEC = [['subj', 'বিষয় বাছাই'], ['chap', 'অধ্যায় বাছাই'], ['resume', 'যেখানে থেমেছিলে'], ['today', 'আজ, স্ট্রিক ও কাউন্টডাউন'], ['fact', 'আজকের মজার তথ্য'], ['quick', 'দ্রুত শুরু'], ['progress', 'অধ্যায়ের অগ্রগতি'], ['sub', 'উপ-অধ্যায়'], ['week', 'সাপ্তাহিক পড়া'], ['level', 'লেভেল ও XP'], ['saved', 'সংরক্ষিত'], ['tools', 'এই অধ্যায়ের টুলস'], ['outline', 'বইয়ের সূচিপত্র']];
function homeOrder() { const s = SET(), ids = HSEC.map(x => x[0]), o = (s.homeOrder || []).filter(k => ids.includes(k)); ids.forEach((k, i) => { if (!o.includes(k)) o.splice(Math.min(i, o.length), 0, k); }); return o; }
let HEDIT = false;
function countdown() {
  const s = SET(); if (!s.examDate) return null; const d = dOf(s.examDate), t = new Date(); t.setHours(0, 0, 0, 0);
  return Math.round((d - t) / 864e5);
}
const HS = {
  subj: () => subjPills() || `<div>${subjChip()}</div>`,
  chap: () => chPick(),
  resume: () => resumeCard(LESSONS, 'এই অধ্যায়ের'),
  today: () => {
    const td = S.days[dkey()] || {}, sk = streak(), lp = clamp((td.l || 0) / S.goal.l, 0, 1) * 100, mp = clamp((td.m || 0) / S.goal.m, 0, 1) * 100, cd = countdown();
    const sb = subjOf(CH), left = sb.L.filter(l => !S.done[l.id]).reduce((a, l) => a + readMin(l), 0);
    return `<div class="stat-strip"><div class="mini">${ico('fire', 'muted')}<b>${bn(sk)}</b><span>দিনের ধারাবাহিকতা</span></div>
      <button type="button" class="mini goal-tile" data-act="goalSheet" aria-label="দৈনিক পাঠ লক্ষ্য বদলাও"><b>${bn(td.l || 0)}/${bn(S.goal.l)}</b><span>আজকের পাঠ লক্ষ্য ✎</span>${bar(lp, 'thin a2')}</button>
      <button type="button" class="mini goal-tile" data-act="goalSheet" aria-label="দৈনিক মিনিট লক্ষ্য বদলাও"><b id="todayMin">${bn(Math.round(td.m || 0))}/${bn(S.goal.m)}</b><span>আজ পড়ার মিনিট ✎</span>${bar(mp, 'thin')}</button>
      <button class="mini" data-act="frzInfo" style="cursor:pointer;text-align:inherit"><span class="frz">🧊</span><b>${bn((S.frz || {}).n || 0)}/২</b><span>স্ট্রিক রক্ষাকবচ</span></button></div>
      ${cd == null ? `<button class="cd-card ghost" data-act="go" data-v="settings">${ico('target')}<span><b>পরীক্ষার তারিখ যোগ করো</b><small>সেটিংসে তারিখ দিলে এখানে কাউন্টডাউন ও দৈনিক দরকারি সময় দেখাবে</small></span></button>`
        : `<div class="cd-card"><span class="cd-n">${cd >= 0 ? bn(cd) : '—'}</span><span><b>${esc(SET().examName)} ${cd > 0 ? 'বাকি ' + bn(cd) + ' দিন' : cd === 0 ? 'আজ!' : 'পার হয়ে গেছে'}</b><small>${cd > 0 ? `${sb.t} এর বাকি পাঠ ${fmtMin(left)} — দিনে অন্তত ${fmtMin(Math.ceil(left / cd))} পড়লে সময়মতো শেষ হবে` : 'সেটিংস থেকে নতুন তারিখ দাও'}</small></span></div>`}`;
  },
  quick: () => {
    const dd = dailyDone(), wr = wrongIds().length, fcn = SECS.reduce((a, s) => a + s.F.length, 0);
    const t = [['quiz', 'daily', 'daily', 'spark', 'আজকের চ্যালেঞ্জ', dd ? `সম্পন্ন · স্কোর ${p2(dd.p / 100)}%` : '১০টি প্রশ্ন · +৩০ XP'], ['go', 'flash', '', 'cards', 'ফ্ল্যাশকার্ড', `${bn(fcn)}টি কার্ড`], ['quiz', 'wrong', 'wrong', 'repeat', 'ভুল প্রশ্ন আবার', wr ? `${bn(wr)}টি জমা আছে` : 'কোনো ভুল জমা নেই'], ['go', 'mega', '', 'trophy', 'মেগা টেস্ট', S.mega ? `সর্বশেষ মাস্টারি ${bn(S.mega.mastery)}%` : 'পূর্ণ অধ্যায় যাচাই']];
    return `<div class="quick">${t.map(([act, v, mode, i, n, sub]) => `<button class="qk ${act === 'quiz' && v === 'daily' && !dd ? 'hot' : ''}" data-act="${act}" ${act === 'go' ? `data-v="${v}"` : `data-id="${v}" data-mode="${mode}"`} ${act === 'quiz' && v === 'wrong' && !wr ? 'disabled' : ''}><span class="ti">${ico(i)}</span><b>${n}</b><small>${sub}</small></button>`).join('')}</div>`;
  },
  progress: () => { const f = fracL(LESSONS), g = globalStats(); return progCard(f, LESSONS.filter(l => S.done[l.id]).length, LESSONS.length, `গড় মাস্টারি ${bn(g.mastery)}% · MCQ নির্ভুলতা ${bn(g.acc)}%`); },
  sub: () => {
    const last = lastLesson(), openSid = last && last.ch === CH.id ? last.sid : null;
    return `<div class="ptable-head"><h2 class="h-sec">উপ-অধ্যায়</h2><span class="sp"></span>${selBtn()}</div>
    <div class="sec-acc">${SECS.map(x => { const st = secStats(x); return `<details class="sa ${st.done === st.total && st.total ? 'all-done' : ''}" data-sid="${x.id}" ${x.id === openSid ? 'open' : ''}><summary><span class="pr-no">${x.cat === 'E' ? '★' : x.no}</span><span class="pr-b"><span class="pr-t">${x.t}</span><span class="pr-m">${bn(st.done)}/${bn(st.total)} পাঠ · মাস্টারি ${bn(st.mastery)}%</span><span class="bar thin"><i style="width:${st.comp * 100}%"></i></span></span><span class="pr-p">${p2(st.comp)}%</span><span class="chev">${ico('chev')}</span></summary>
      <div class="sa-body"><div class="lesson-list">${x.L.map(lessonRow).join('')}</div><div class="sa-acts">${secDoneBtn(x)}<button class="btn sm" data-act="sec" data-id="${x.id}">${ico('target')}উপ-অধ্যায়ের পাতা · কুইজ ও প্রশ্নব্যাংক</button></div></div></details>`; }).join('')}</div>`;
  },
  week: () => {
    const days = []; const now = new Date(); for (let i = 6; i >= 0; i--) { const d = new Date(now); d.setDate(now.getDate() - i); const k = dkey(d); days.push([k, d, (S.days[k] || {}).m || 0]); }
    const mx = Math.max(S.goal.m, ...days.map(x => x[2])), tot = days.reduce((a, x) => a + x[2], 0);
    return `<button class="wk card" data-act="go" data-v="study" aria-label="গত ৩০ দিনের পড়া দেখো"><span class="wk-head"><b>সাপ্তাহিক পড়া</b><span class="small muted">মোট ${fmtMin(tot)}</span><span class="sp"></span><span class="pill-arrow">৩০ দিন ›</span></span>
      <span class="wk-bars">${days.map(([k, d, m], i) => `<span class="wk-col ${i === 6 ? 'today' : ''}"><span class="wk-v">${m ? bn(Math.round(m)) : ''}</span><span class="wk-bar"><i style="height:${Math.max(m ? 4 : 0, m / mx * 100)}%" class="${m >= S.goal.m ? 'met' : ''}"></i><em style="bottom:${S.goal.m / mx * 100}%"></em></span><span class="wk-d">${WDS[d.getDay()]}</span></span>`).join('')}</span>
      <span class="small muted">কাটা রেখা = দৈনিক লক্ষ্য ${bn(S.goal.m)} মিনিট · সবুজ = লক্ষ্য পূরণ</span></button>`;
  },
  level: () => { const x = xpInfo(); return `<button class="lv card" data-act="go" data-v="xp"><span class="lv-badge">${bn(x.L)}</span><span class="lv-b"><span class="row" style="gap:6px"><b>লেভেল ${bn(x.L)} · ${x.name}</b><span class="sp"></span><span class="small mono">${bn(x.xp)} XP</span></span>${bar(x.f * 100, 'a2')}<small class="muted">পরের লেভেলে আর ${bn(x.need)} XP · ${dailyDone() ? 'আজকের চ্যালেঞ্জ সম্পন্ন ✓' : 'আজকের চ্যালেঞ্জে +৩০ XP'}</small></span>${ico('next')}</button>`; },
  saved: () => {
    const n = { sv: Object.keys(S.sv || {}).length, bm: LESSONS_ALL.filter(x => S.bm[x.id]).length, notes: LESSONS_ALL.filter(x => S.notes[x.id]).length, hl: LESSONS_ALL.reduce((a, x) => a + (S.hl[x.id] || []).length, 0), wrong: wrongIds().length };
    return `<div class="card stack" style="gap:8px;padding:14px"><b>সংরক্ষিত</b><div class="chips">${[['bm', 'bm', 'পাঠ'], ['m', 'bmf', '★ সংরক্ষিত'], ['notes', 'note', 'নোট'], ['hl', 'pen', 'হাইলাইট'], ['wrong', 'alert', 'ভুল প্রশ্ন']].map(([k, i, t]) => `<button class="schip" data-act="libTab" data-tab="${k}">${ico(i)}${t}<b>${bn(k === 'm' ? n.sv : n[k])}</b></button>`).join('')}</div></div>`;
  },
  tools: () => { const c = CH, tools = [['figures', 'pic', 'চিত্রসূচি', `${bn(figList(c).length)}টি চিত্র ও সিমুলেশন`], ['formulas', 'sigma', 'ফর্মুলা শিট', 'সব সূত্র এক জায়গায়'], ['flash', 'cards', 'ফ্ল্যাশকার্ড', 'দ্রুত মুখস্থ যাচাই'], ['mega', 'trophy', 'মেগা টেস্ট', 'পূর্ণ অধ্যায় মূল্যায়ন'], ['compare', 'layers', 'পার্থক্য সারণি', 'ধারণার তুলনা'], ['revision', 'repeat', 'রিভিশন মোড', 'নোট ও তথ্য']];
    return `<h2 class="h-sec">এই অধ্যায়ের টুলস</h2><div class="tools">${tools.map(([v, i, t, sub]) => `<button class="tool" data-act="go" data-v="${v}"><span class="ti">${ico(i)}</span><span><b>${t}</b><small>${sub}</small></span></button>`).join('')}</div>`; },
  outline: () => CH.outline ? `<details class="card" style="padding:14px"><summary style="cursor:pointer;font-weight:700">বইয়ের পূর্ণ সূচিপত্র (অনুচ্ছেদ নম্বরসহ)</summary><div style="margin-top:10px">${outlineHTML(CH)}</div></details>` : ''
};
VIEWS.home = () => {
  const s = SET(), order = homeOrder();
  const parts = order.map(id => {
    const hid = !!s.homeHidden[id]; if (hid && !HEDIT) return '';
    let body = ''; try { body = HS[id](); } catch (e) { console.warn(e); }
    if (!HEDIT) return body ? `<div class="hs" data-hs="${id}">${body}</div>` : '';
    const lab = (HSEC.find(x => x[0] === id) || [])[1];
    return `<div class="hs edit ${hid ? 'off' : ''}" data-hs="${id}"><div class="hs-bar"><span class="hs-grip" data-grip aria-label="টেনে সরাও">${ico('menu')}</span><b>${lab}</b><span class="sp"></span><button data-act="hsMove" data-d="-1" aria-label="উপরে">▲</button><button data-act="hsMove" data-d="1" aria-label="নিচে">▼</button><button data-act="hsHide" aria-label="লুকাও/দেখাও">${ico(hid ? 'eye' : 'x')}</button></div><div class="hs-body">${body || '<div class="small muted">(এই অধ্যায়ে খালি)</div>'}</div></div>`;
  }).join('');
  return {
    title: CH.t, eye: chLabel(CH), nav: 'home',
    html: `<div class="wrap stack ${HEDIT ? 'home-edit' : ''}" id="homeWrap">
    <div class="hello-row"><div class="hello" style="flex:1;min-width:0"><span class="date">${dateBn()}</span><h1 class="h-display">${greet()}!</h1></div><button class="btn sm ${HEDIT ? 'primary' : ''}" data-act="homeEdit">${HEDIT ? ico('check') + 'সম্পন্ন' : ico('pen') + 'সাজাও'}</button></div>
    ${HEDIT ? `<div class="card small" style="padding:10px 14px">✋ বাম পাশের হাতল ধরে টেনে বা ▲▼ দিয়ে ক্রম বদলাও; ✕ দিয়ে লুকাও (লুকানো অংশ ঝাপসা দেখাবে, 👁 দিয়ে ফেরাও)। সবকিছু নিজে থেকেই সংরক্ষিত হয়। <button class="btn sm" data-act="homeReset" style="margin-top:6px">${ico('repeat')}ডিফল্টে ফেরাও</button></div>` : ''}
    ${parts}
    </div>`,
    after: () => { if (HEDIT) homeDrag(); }
  };
};
function saveHomeOrder() { const ids = $$('#homeWrap .hs[data-hs]').map(e => e.dataset.hs); SET().homeOrder = ids; save(); }
function homeDrag() {
  const wrap = $('#homeWrap'); if (!wrap) return;
  let drag = null;
  const move = e => { if (!drag) return; e.preventDefault(); const y = e.clientY; drag.el.style.transform = `translateY(${y - drag.y0}px)`;
    const sibs = $$('.hs[data-hs]', wrap).filter(x => x !== drag.el);
    for (const s of sibs) { const r = s.getBoundingClientRect(); if (y < r.top + r.height / 2) { if (s.previousElementSibling !== drag.el) { wrap.insertBefore(drag.el, s); drag.y0 = y; drag.el.style.transform = ''; } return; } }
    const lastS = sibs[sibs.length - 1]; if (lastS && lastS.nextElementSibling !== drag.el) { lastS.after(drag.el); drag.y0 = y; drag.el.style.transform = ''; } };
  const up = () => { if (!drag) return; drag.el.classList.remove('dragging'); drag.el.style.transform = ''; drag = null; saveHomeOrder(); document.removeEventListener('pointermove', move); document.removeEventListener('pointerup', up); document.removeEventListener('pointercancel', up); };
  $$('[data-grip]', wrap).forEach(g => g.addEventListener('pointerdown', e => { e.preventDefault(); const el = g.closest('.hs'); drag = { el, y0: e.clientY }; el.classList.add('dragging'); document.addEventListener('pointermove', move, { passive: false }); document.addEventListener('pointerup', up); document.addEventListener('pointercancel', up); }));
  cleanups.push(() => up());
}

/* ---------- ৩০ দিনের পড়া (হিটম্যাপ) ---------- */
VIEWS.study = ({ sel }) => {
  const goal = S.goal.m, now = new Date(); now.setHours(0, 0, 0, 0);
  const days = []; for (let i = 29; i >= 0; i--) { const d = new Date(now); d.setDate(now.getDate() - i); const k = dkey(d), r = S.days[k] || {}; days.push({ k, d, m: r.m || 0, l: r.l || 0, q: r.q || 0 }); }
  const lv = m => m <= 0 ? 0 : m < goal / 4 ? 1 : m < goal / 2 ? 2 : m < goal ? 3 : 4;
  const pad = days[0].d.getDay(); const today = dkey(now); sel = sel || today;
  const tot = days.reduce((a, x) => a + x.m, 0), act = days.filter(x => x.m > 0 || x.l > 0).length, met = days.filter(x => x.m >= goal).length, best = days.reduce((a, x) => x.m > a.m ? x : a, days[0]);
  const l7 = days.slice(-7).reduce((a, x) => a + x.m, 0), p7 = days.slice(-14, -7).reduce((a, x) => a + x.m, 0);
  let run = 0; for (let i = days.length - 1; i >= 0; i--) { if (days[i].m > 0 || days[i].l > 0) run++; else if (i === days.length - 1) continue; else break; }
  const S_ = days.find(x => x.k === sel) || days[days.length - 1], les = lessonsOn(S_.k);
  return {
    title: 'গত ৩০ দিনের পড়া', nav: 'stats',
    html: `<div class="wrap stack"><div><span class="eyebrow">পড়ার ক্যালেন্ডার</span><h1 class="h-sec">গত ৩০ দিনের পড়া</h1><p class="small muted" style="margin:4px 0 0">রঙ যত গাঢ়, সেদিন তত বেশি সময় পড়েছ (দৈনিক লক্ষ্য ${bn(goal)} মিনিটের হিসাবে)। যেকোনো দিনে চাপ দাও।</p></div>
    <div class="card"><div class="hm"><div class="hm-wd">${WDS.map(w => `<span>${w}</span>`).join('')}</div><div class="hm-grid">${'<span></span>'.repeat(pad)}${days.map(x => `<button class="hm-c lv${lv(x.m)} ${x.k === today ? 'today' : ''} ${x.k === S_.k ? 'sel' : ''}" data-act="hmSel" data-k="${x.k}" aria-label="${dateBn(x.d)}: ${Math.round(x.m)} মিনিট"><span>${bn(x.d.getDate())}</span>${x.m >= goal ? '<em>✓</em>' : ''}</button>`).join('')}</div>
    <div class="hm-leg"><span>কম</span>${[0, 1, 2, 3, 4].map(i => `<i class="hm-c lv${i}"></i>`).join('')}<span>বেশি</span></div>
    <div class="small muted" style="text-align:center">০ · ${bn(Math.ceil(goal / 4))} মি.-এর কম · ${bn(Math.ceil(goal / 2))} মি.-এর কম · ${bn(goal)} মি.-এর কম · লক্ষ্য পূরণ ✓</div></div></div>
    <div class="card stack" style="gap:6px" aria-live="polite"><b>${dateBn(S_.d)}</b><div class="row" style="gap:16px"><span>⏱ ${fmtMin(S_.m)}</span><span>📘 ${bn(S_.l)}টি পাঠ</span><span>❓ ${bn(Math.round(S_.q))}টি প্রশ্ন</span><span>🎯 লক্ষ্যের ${p2(S_.m / goal)}%</span></div>${bar(clamp(S_.m / goal, 0, 1) * 100, S_.m >= goal ? 'ok' : '')}
    ${les.length ? `<div class="lesson-list" style="margin-top:6px">${les.map(lessonRow).join('')}</div>` : '<div class="small muted">সেদিন কোনো পাঠ সম্পন্ন চিহ্নিত হয়নি।</div>'}</div>
    <div class="kv"><div><b>${fmtMin(tot)}</b><span>৩০ দিনে মোট</span></div><div><b>${bn(act)}/৩০</b><span>পড়ার দিন</span></div><div><b>${fmtMin(tot / 30)}</b><span>দৈনিক গড়</span></div><div><b>${bn(met)}</b><span>লক্ষ্য পূরণের দিন</span></div><div><b>${best.m ? fmtMin(best.m) : '—'}</b><span>সেরা দিন${best.m ? ' · ' + bn(best.d.getDate()) + ' ' + MON[best.d.getMonth()] : ''}</span></div><div><b>${bn(run)}</b><span>টানা পড়ার দিন</span></div></div>
    <div class="card row" style="gap:10px"><span style="font-size:26px">${l7 >= p7 ? '📈' : '📉'}</span><span style="flex:1;min-width:0"><b>শেষ ৭ দিন ${fmtMin(l7)}</b><br><span class="small muted">আগের ৭ দিন ${fmtMin(p7)} · ${p7 ? (l7 >= p7 ? '+' : '−') + p2(Math.abs(l7 - p7) / p7) + '%' : l7 ? 'নতুন শুরু!' : 'এখনো শুরু হয়নি'}</span></span></div>
    <div class="row"><button class="btn sm" data-act="goal" data-k="m" data-d="-5">−</button><span class="small">দৈনিক লক্ষ্য <b>${bn(goal)}</b> মিনিট</span><button class="btn sm" data-act="goal" data-k="m" data-d="5">+</button></div></div>`
  };
};

/* ---------- XP পাতা ---------- */
VIEWS.xp = () => {
  const x = xpInfo();
  return { title: 'লেভেল ও XP', nav: 'stats', html: `<div class="wrap stack"><div><span class="eyebrow">গেমিফিকেশন</span><h1 class="h-sec">লেভেল ${bn(x.L)} · ${x.name}</h1></div>
    <div class="card stack" style="gap:8px"><div class="row"><span class="lv-badge big">${bn(x.L)}</span><span style="flex:1"><b style="font-size:22px">${bn(x.xp)} XP</b><br><span class="small muted">পরের লেভেল (${LVN[Math.min(x.L, LVN.length - 1)]}) পর্যন্ত আর ${bn(x.need)} XP</span></span></div>${bar(x.f * 100, 'a2')}</div>
    <div class="card stack" style="gap:6px"><b>XP কোথা থেকে এল</b>${x.parts.map(([n, v]) => `<div class="row small"><span>${n}</span><span class="sp"></span><b class="mono">${bn(v)}</b></div>`).join('')}</div>
    <div class="card stack" style="gap:6px"><b>লেভেলের ধাপ</b><div class="small muted">লেভেল L এ পৌঁছাতে মোট ৫০ × L × (L − ১) XP লাগে।</div>${LVN.map((n, i) => `<div class="row small ${i + 1 === x.L ? 'on-lv' : ''}"><span class="mono">${bn(i + 1)}</span><span>${n}</span><span class="sp"></span><span class="mono muted">${bn(50 * (i + 1) * i)} XP</span></div>`).join('')}</div>
    <button class="btn primary" data-act="quiz" data-id="daily" data-mode="daily" ${dailyDone() ? 'disabled' : ''}>${ico('spark')}${dailyDone() ? 'আজকের চ্যালেঞ্জ সম্পন্ন' : 'আজকের চ্যালেঞ্জ দাও (+৩০ XP)'}</button></div>` };
};

/* ---------- সেটিংস: পছন্দ ও ব্যাকআপ ---------- */
const backupJSON = () => JSON.stringify(Object.assign({ _app: 'hsc-phy', _at: new Date().toISOString() }, S));
const toCode = s => btoa(unescape(encodeURIComponent(s)));
const fromCode = c => decodeURIComponent(escape(atob(c.replace(/\s+/g, ''))));
function prefsHTML() {
  const s = SET();
  const seg = (k, items) => `<div class="seg">${items.map(([v, n]) => `<button type="button" data-act="pref" data-k="${k}" data-v="${v}" class="${String(s[k]) === String(v) ? 'on' : ''}">${n}</button>`).join('')}</div>`;
  return `<section class="card stack" style="gap:10px"><h2 class="h-card">পরীক্ষা ও দৈনিক লক্ষ্য</h2>
    <label class="small">পরীক্ষার নাম<input class="inp" data-pref="examName" value="${esc(s.examName)}"></label>
    <label class="small">পরীক্ষার তারিখ (হোমে কাউন্টডাউন)<input class="inp" type="date" data-pref="examDate" value="${esc(s.examDate)}"></label>
    <div class="row"><span>দৈনিক লক্ষ্য: পাঠ</span><span class="sp"></span><button class="btn sm" data-act="goal" data-k="l" data-d="-1">−</button><b class="mono">${bn(S.goal.l)}</b><button class="btn sm" data-act="goal" data-k="l" data-d="1">+</button></div>
    <div class="row"><span>দৈনিক লক্ষ্য: মিনিট</span><span class="sp"></span><button class="btn sm" data-act="goal" data-k="m" data-d="-5">−</button><b class="mono">${bn(S.goal.m)}</b><button class="btn sm" data-act="goal" data-k="m" data-d="5">+</button></div></section>
  <section class="card stack" style="gap:10px"><h2 class="h-card">দেখা ও পড়া</h2>
    <div class="small muted">লেখার আকার</div>${seg('fs', [[0.9, 'ছোট'], [1, 'স্বাভাবিক'], [1.1, 'বড়'], [1.2, 'আরও বড়']])}
    <div class="small muted">অ্যানিমেশন</div>${seg('motion', [['auto', 'ফোনের মতো'], ['full', 'সবসময় চালু'], ['reduce', 'কমাও']])}
    <button class="btn sm" data-act="homeEditGo" style="align-self:flex-start">${ico('pen')}হোম পেজ সাজাও</button></section>
  <section class="card stack" style="gap:10px"><h2 class="h-card">ব্যাকআপ ও পুনরুদ্ধার</h2>
    <p class="small muted" style="margin:0">সব অগ্রগতি, নোট, হাইলাইট, কুইজ ফল ও সেটিংস একটি ফাইলে বা কোডে। নতুন ফোনে বা অফলাইন কপিতে নিতে কাজে লাগবে।</p>
    <div class="row"><button class="btn" data-act="bkFile">${ico('next')}ফাইল ডাউনলোড</button><button class="btn" data-act="bkCode">${ico('cards')}ব্যাকআপ কোড কপি</button></div>
    <textarea class="inp" id="bkBox" rows="3" placeholder="ব্যাকআপ কোড বা JSON এখানে পেস্ট করো…"></textarea>
    <div class="row"><button class="btn primary" data-act="bkImport">${ico('repeat')}পুনরুদ্ধার করো</button><label class="btn">${ico('book')}ফাইল থেকে<input type="file" accept=".json,application/json,text/plain" id="bkFileIn" hidden></label></div><span class="small muted" id="bkMsg"></span></section>`;
}
const _settings = VIEWS.settings;
VIEWS.settings = a => { const o = _settings(a); const k = '<section class="stack" style="gap:8px"><h2 class="h-card">থিম</h2>'; o.html = o.html.replace(k, prefsHTML() + k); const af = o.after; o.after = () => { af && af(); const f = $('#bkFileIn'); if (f) f.onchange = () => { const fl = f.files[0]; if (!fl) return; const rd = new FileReader(); rd.onload = () => { $('#bkBox').value = rd.result; ACT.bkImport(); }; rd.readAsText(fl); }; }; return o; };
function doImport(txt) {
  let o = null; txt = (txt || '').trim(); if (!txt) return 'কিছু পেস্ট করা হয়নি।';
  try { o = JSON.parse(txt[0] === '{' ? txt : fromCode(txt)); } catch (e) { return 'কোড/ফাইলটি পড়া গেল না — পুরোটা কপি হয়েছে কি না দেখো।'; }
  if (!o || typeof o !== 'object' || !o.done) return 'এটি এই অ্যাপের ব্যাকআপ নয়।';
  delete o._app; delete o._at; S = Object.assign(DEF(), o); S.updatedAt = Date.now(); save(); CH = null; setCh(S.ch); applyTheme(); applyPrefs(); IDX = null; return '';
}
document.addEventListener('change', e => { const t = e.target.closest('[data-pref]'); if (!t) return; SET()[t.dataset.pref] = t.value; save(); toast('সংরক্ষিত'); });
const _fcMark = ACT.fcMark;
Object.assign(ACT, {
  fcMark: b => { S.fcN = (S.fcN || 0) + 1; _fcMark(b); },
  homeEdit: () => { HEDIT = !HEDIT; render(true); },
  homeEditGo: () => { HEDIT = true; stack.length = 0; go('home', {}, { replace: true }); },
  homeReset: () => { const s = SET(); s.homeOrder = []; s.homeHidden = {}; save(); render(true); toast('হোম ডিফল্ট সাজানোয় ফিরেছে'); },
  hsMove: b => { const el = b.closest('.hs'), d = +b.dataset.d, sib = d < 0 ? el.previousElementSibling : el.nextElementSibling; if (!sib || !sib.dataset.hs) return; if (d < 0) sib.before(el); else sib.after(el); saveHomeOrder(); el.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); },
  hsHide: b => { const id = b.closest('.hs').dataset.hs, s = SET(); if (s.homeHidden[id]) delete s.homeHidden[id]; else s.homeHidden[id] = 1; save(); render(true); },
  hmSel: b => { cur.args.sel = b.dataset.k; render(true); },
  pref: b => { const s = SET(), k = b.dataset.k; s[k] = k === 'fs' ? +b.dataset.v : b.dataset.v; save(); applyPrefs(); render(true); },
  bkFile: async () => {
    const msg = $('#bkMsg'), name = 'hsc-backup-' + dkey() + '.json', blob = new Blob([backupJSON()], { type: 'application/json' });
    try { const dlc = window.claude && window.claude.use ? await window.claude.use('downloads').catch(() => null) : null; if (dlc) { await dlc.save({ filename: name, data: blob }); if (msg) msg.textContent = 'ব্যাকআপ ফাইল সংরক্ষিত হয়েছে।'; return; } } catch (e) { if (msg) msg.textContent = 'ডাউনলোড হয়নি — নিচের "ব্যাকআপ কোড কপি" ব্যবহার করো।'; return; }
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 3000); if (msg) msg.textContent = 'ডাউনলোড শুরু হয়েছে।';
  },
  bkCode: async () => { const c = toCode(backupJSON()), box = $('#bkBox'); if (box) { box.value = c; box.select(); } let ok = false; try { await navigator.clipboard.writeText(c); ok = true; } catch (e) { try { ok = document.execCommand('copy'); } catch (e2) { } } $('#bkMsg').textContent = ok ? `কোড কপি হয়েছে (${bn(Math.round(c.length / 1024))} KB) — কোথাও নিরাপদে রেখে দাও।` : 'বক্সের কোডটি নিজে সিলেক্ট করে কপি করো।'; },
  bkImport: b => { const box = $('#bkBox'); if (b && !b.dataset.arm) { b.dataset.arm = 1; b.innerHTML = ico('alert') + 'নিশ্চিত? বর্তমান অগ্রগতির জায়গায় বসবে — আবার চাপো'; setTimeout(() => { if (b.isConnected) { delete b.dataset.arm; b.innerHTML = ico('repeat') + 'পুনরুদ্ধার করো'; } }, 6000); return; } const err = doImport(box && box.value); if (err) { $('#bkMsg').textContent = err; return; } toast('ব্যাকআপ থেকে পুনরুদ্ধার হয়েছে'); stack.length = 0; go('home', {}, { replace: true }); }
});
applyPrefs();

/* ═══════════════ PLUS (ধাপ ২): SM-2 ফ্ল্যাশকার্ড · ভুলের খাতা · ব্যাজ ═══════════════ */
const DAY = 864e5;
function srsNext(r, g) {
  r = Object.assign({ ef: 2.5, ivl: 0, reps: 0, lapses: 0 }, r || {}); const now = Date.now();
  if (g === 0) { r.lapses++; r.reps = 0; r.ivl = 0; r.ef = Math.max(1.3, r.ef - 0.2); r.due = now + 60000; }
  else if (g === 1) { r.ivl = Math.max(1, Math.round(r.ivl * 1.2)); r.ef = Math.max(1.3, r.ef - 0.15); r.reps++; r.due = now + r.ivl * DAY; }
  else if (g === 2) { r.ivl = r.reps === 0 ? 1 : r.reps === 1 ? 3 : Math.max(1, Math.round(r.ivl * r.ef)); r.reps++; r.due = now + r.ivl * DAY; }
  else { r.ivl = r.reps === 0 ? 3 : Math.round(Math.max(r.ivl, 1) * r.ef * 1.3); r.ef = r.ef + 0.15; r.reps++; r.due = now + r.ivl * DAY; }
  r.t = now; return r;
}
const ivlTxt = r => r.ivl ? (r.ivl >= 30 ? bn(Math.round(r.ivl / 30)) + ' মাস' : bn(r.ivl) + ' দিন') : '১ মিনিট';
function deckOf(sid) { const d = []; SECS.forEach(s => { if (sid && sid !== 'all' && s.id !== sid) return; s.F.forEach((f, i) => d.push({ id: s.id + 'f' + i, sid: s.id, f: f[0], b: f[1] })); }); return d; }
function srsSplit(deck) { const now = Date.now(), R = S.srs || {}; const due = [], nw = [], later = [], weak = []; deck.forEach(c => { const r = R[c.id]; if (!r) nw.push(c); else if ((r.due || 0) <= now) due.push(c); else later.push(c); if (r && (r.lapses >= 2 || r.ef < 2)) weak.push(c); }); due.sort((a, b) => R[a.id].due - R[b.id].due); return { due, nw, later, weak }; }
const fcDueCount = () => { const x = srsSplit(deckOf('all')); return x.due.length + Math.min(20, x.nw.length); };
VIEWS.flash = ({ sid = 'all', mode = 'due' }) => {
  const deck = deckOf(sid), sp = srsSplit(deck), R = S.srs || {};
  const pool = mode === 'due' ? sp.due.concat(sp.nw.slice(0, 20)) : mode === 'weak' ? sp.weak : mode === 'new' ? sp.nw : shuffle(deck);
  if (!FC || FC.key !== sid + mode) FC = { key: sid + mode, sid, order: pool, i: 0, flip: false, seen: 0 };
  const c = FC.order[FC.i];
  const opts = `<select class="inp" id="fcDeck" style="margin:0"><option value="all">সব উপ-অধ্যায় (${bn(SECS.reduce((a, s) => a + s.F.length, 0))})</option>${SECS.filter(s => s.F.length).map(s => `<option value="${s.id}" ${s.id === sid ? 'selected' : ''}>${s.no} ${s.st || s.t} (${bn(s.F.length)})</option>`).join('')}</select>`;
  const learned = deck.filter(x => R[x.id] && R[x.id].reps >= 2).length;
  const seg = [['due', `আজকের (${bn(sp.due.length + Math.min(20, sp.nw.length))})`], ['weak', `দুর্বল (${bn(sp.weak.length)})`], ['new', `নতুন (${bn(sp.nw.length)})`], ['all', `সব (${bn(deck.length)})`]];
  const prev = c ? [0, 1, 2, 3].map(g => ivlTxt(srsNext(R[c.id], g))) : [];
  return {
    title: 'ফ্ল্যাশকার্ড', nav: 'practice',
    html: `<div class="wrap stack"><div><span class="eyebrow">সক্রিয় স্মরণ · স্পেসড রিপিটিশন (SM-2)</span><h1 class="h-sec">ফ্ল্যাশকার্ড</h1></div>
    ${opts}<div class="seg">${seg.map(([k, n]) => `<button type="button" data-act="fcMode" data-k="${k}" class="${k === mode ? 'on' : ''}">${n}</button>`).join('')}</div>
    <div class="row small muted"><span>আয়ত্ত (২+ বার মনে পড়েছে) ${bn(learned)}/${bn(deck.length)} · ${p2(deck.length ? learned / deck.length : 0)}%</span><span class="sp"></span><span>পরে আসবে ${bn(sp.later.length)}</span></div>${bar(deck.length ? learned / deck.length * 100 : 0, 'ok')}
    ${c ? `<div class="flash-stage"><div class="flash ${FC.flip ? 'flip' : ''}" id="flashCard" data-act="fcFlip" role="button" tabindex="0" aria-label="কার্ড উল্টাও">
      <div class="face"><small>${SMAP[c.sid].no} · কার্ড ${bn(FC.i + 1)}/${bn(FC.order.length)}${R[c.id] ? ' · ' + bn(R[c.id].reps) + ' বার রিভিউ' : ' · নতুন'}</small><div class="fq">${c.f}</div><div class="small muted" style="margin-top:14px">মনে মনে উত্তর ভাবো, তারপর ট্যাপ করো</div></div>
      <div class="face back"><small>উত্তর</small><div class="fa">${c.b}</div></div></div></div>
    <div class="row fc-nav"><button class="btn" data-act="fcStep" data-d="-1" ${FC.i > 0 ? '' : 'disabled'}>${ico('back')}আগের</button><span class="sp"></span><span class="small muted">${bn(FC.i + 1)}/${bn(FC.order.length)}</span><span class="sp"></span><button class="btn" data-act="fcStep" data-d="1" ${FC.i < FC.order.length - 1 ? '' : 'disabled'}>পরের${ico('next')}</button></div>
    <div class="row" style="justify-content:center">${svBtn('f', c.id, 'কার্ডটি সংরক্ষণ করো')}</div>
    <div class="srs-row" ${FC.flip ? '' : 'hidden'} id="srsRow">${[['আবার', 'bad'], ['কঠিন', 'warn'], ['ভালো', 'ok'], ['সহজ', 'acc']].map(([n, cl], g) => `<button class="srs ${cl}" data-act="srs" data-g="${g}"><b>${n}</b><small>${prev[g]}</small></button>`).join('')}</div>
    ${FC.flip ? '' : `<button class="btn primary block" data-act="fcFlip">${ico('eye')}উত্তর দেখো</button>`}`
      : `<div class="card stack" style="text-align:center;padding:24px"><div style="font-size:40px">🎉</div><b>${mode === 'due' ? 'আজকের সব কার্ড শেষ!' : 'এই তালিকায় কার্ড নেই।'}</b><span class="small muted">${sp.later.length ? `পরের কার্ড আসবে ${dateBn(new Date(Math.min(...sp.later.map(x => R[x.id].due))))}` : ''}</span>${mode !== 'all' ? `<button class="btn" data-act="fcMode" data-k="all">সব কার্ড অনুশীলন করো</button>` : ''}</div>`}
    <details class="card small" style="padding:12px 14px"><summary style="cursor:pointer;font-weight:600">স্পেসড রিপিটিশন কীভাবে কাজ করে?</summary><p style="margin:.5em 0 0">উত্তর দেখার পর নিজেকে মূল্যায়ন করো। <b>আবার</b> = মনে পড়েনি (১ মিনিট পরে আবার আসবে); <b>কঠিন</b> = কষ্টে মনে পড়েছে; <b>ভালো</b> = ঠিকঠাক; <b>সহজ</b> = এক নিমেষে। যত ভালো মনে থাকে, কার্ড তত দেরিতে ফিরে আসে (১ → ৩ → ৮ → ২০ দিন…)। এতে কম সময়ে বেশি দিন মনে থাকে।</p></details></div>`,
    after() { const d = $('#fcDeck'); d && d.addEventListener('change', () => { FC = null; go('flash', { sid: d.value, mode }, { replace: true }); }); }
  };
};

/* ---------- ভুলের খাতা ---------- */
const REASONS = [['concept', 'ধারণাগত'], ['careless', 'অসাবধানতা'], ['time', 'সময়ের চাপ'], ['guess', 'অনুমান'], ['calc', 'হিসাবের ভুল']];
const mistOf = ok => Object.keys(S.mist || {}).filter(id => MCQ[id] && SMAP[MCQ[id].sid].ch === CH.id && (!!S.mist[id].ok === ok));
const _recordQ = recordQ;
recordQ = function (id, ok) {
  _recordQ(id, ok); const M = S.mist = S.mist || {};
  if (!ok) { M[id] = Object.assign({ n: 0 }, M[id] || {}, { at: Date.now(), streak: 0, ok: 0 }); M[id].n++; }
  else if (M[id] && !M[id].ok) { M[id].streak = (M[id].streak || 0) + 1; if (M[id].streak >= 3) { M[id].ok = Date.now(); S.mistOk = (S.mistOk || 0) + 1; toast('🎯 ভুলের খাতার একটি প্রশ্ন আয়ত্ত হলো (টানা ৩ বার সঠিক)'); } }
  save({ cloud: false });
};
VIEWS.mistakes = ({ tab = 'open', r = 'all' }) => {
  let ids = mistOf(tab === 'done'); const all = ids.length;
  if (r !== 'all') ids = ids.filter(id => (S.mist[id].reason || '') === r);
  ids.sort((a, b) => S.mist[b].at - S.mist[a].at);
  const cnt = k => mistOf(tab === 'done').filter(id => (S.mist[id].reason || '') === k).length;
  return {
    title: 'ভুলের খাতা', nav: 'practice',
    html: `<div class="wrap stack"><div><span class="eyebrow">অধ্যায় ${CH.no} · ${CH.t}</span><h1 class="h-sec">ভুলের খাতা</h1><p class="small muted" style="margin:4px 0 0">যেকোনো কুইজ, টেস্ট বা অনুশীলনে ভুল হওয়া প্রশ্ন এখানে নিজে থেকেই জমা হয়। পুনরায় অনুশীলনে <b>টানা ৩ বার সঠিক</b> হলে প্রশ্নটি "আয়ত্ত" তালিকায় চলে যায়।</p></div>
    <div class="tabs"><button class="${tab === 'open' ? 'on' : ''}" data-act="mistTab" data-tab="open">চলমান (${bn(mistOf(false).length)})</button><button class="${tab === 'done' ? 'on' : ''}" data-act="mistTab" data-tab="done">আয়ত্ত (${bn(mistOf(true).length)})</button></div>
    ${all ? `<div class="chips"><button class="schip ${r === 'all' ? 'on' : ''}" data-act="mistR" data-r="all">সব <b>${bn(all)}</b></button>${REASONS.map(([k, n]) => `<button class="schip ${r === k ? 'on' : ''}" data-act="mistR" data-r="${k}">${n} <b>${bn(cnt(k))}</b></button>`).join('')}<button class="schip ${r === '' ? 'on' : ''}" data-act="mistR" data-r="">কারণ দেওয়া হয়নি <b>${bn(cnt(''))}</b></button></div>` : ''}
    ${tab === 'open' && mistOf(false).length ? `<button class="btn primary" data-act="quiz" data-id="mist" data-mode="mist">${ico('repeat')}পুনরায় অনুশীলন (${bn(Math.min(10, mistOf(false).length))}টি প্রশ্ন)</button>` : ''}
    ${ids.length ? ids.map((id, i) => { const m = MCQ[id], M = S.mist[id]; return `<div class="card stack mist" style="gap:8px"><div class="row small muted" style="gap:6px"><span class="chip">${SMAP[m.sid].no}</span><span class="chip ${m.d}">${DL[m.d]}</span><span>${bn(M.n || 1)} বার ভুল</span><span class="sp"></span><span class="streak">${[0, 1, 2].map(k => `<i class="${k < (M.ok ? 3 : M.streak || 0) ? 'on' : ''}"></i>`).join('')}</span></div>
      <div>${m.q}</div><div class="small"><b>সঠিক উত্তর:</b> (${OL[m.a]}) ${m.o[m.a]}</div>${m.x ? `<details class="small"><summary style="cursor:pointer;color:var(--accent)">ব্যাখ্যা</summary><div style="margin-top:4px">${m.x}</div></details>` : ''}
      <div class="row" style="gap:6px"><span class="small muted">ভুলের কারণ:</span>${REASONS.map(([k, n]) => `<button class="rtag ${M.reason === k ? 'on' : ''}" data-act="mistReason" data-id="${id}" data-r="${k}">${n}</button>`).join('')}</div>
      ${m.l && LMAP[m.l] ? `<button class="btn sm ghost" style="align-self:flex-start" data-act="lesson" data-id="${m.l}">${ico('book')}পাঠে যাও: ${LMAP[m.l].t}</button>` : ''}</div>`; }).join('')
      : `<div class="empty">${tab === 'open' ? 'কোনো চলমান ভুল নেই — দারুণ! কুইজ দিলে ভুলগুলো এখানে জমা হবে।' : 'এখনো কোনো প্রশ্ন আয়ত্ত হয়নি।'}</div>`}</div>`
  };
};

/* ---------- ব্যাজ ---------- */
function bestStreak() { const ks = Object.keys(S.days).filter(k => activeDay(S.days[k])).sort(); let best = 0, run = 0, prev = null; ks.forEach(k => { const d = dOf(k); run = prev && Math.round((d - prev) / DAY) === 1 ? run + 1 : 1; best = Math.max(best, run); prev = d; }); return best; }
function badges() {
  let corr = 0; for (const id in S.qs) corr += (S.qs[id] || {}).c || 0;
  const les = Object.keys(S.done).length, bs = Math.max(bestStreak(), streak()), fc = S.fcN || 0, mo = S.mistOk || 0, dl = Object.keys(S.daily || {}).length, x = xpInfo(), mg = !!(S.mega || Object.values(S.megaBy || {}).some(v => v && v.m)), qz = Object.keys(S.quiz || {}).length;
  return [['📘', 'প্রথম পাঠ', 'একটি পাঠ সম্পন্ন', les, 1], ['📚', 'পাঠপ্রেমী', '২৫টি পাঠ সম্পন্ন', les, 25], ['🏛', 'শতক', '১০০টি পাঠ সম্পন্ন', les, 100],
    ['✅', 'সঠিকের শুরু', '১০০টি সঠিক উত্তর', corr, 100], ['🎯', 'নিশানাবাজ', '৫০০টি সঠিক উত্তর', corr, 500], ['🧠', 'প্রশ্নজয়ী', '২০০০টি সঠিক উত্তর', corr, 2000],
    ['🔥', 'তিন দিনের ধারা', 'টানা ৩ দিন পড়া', bs, 3], ['⚡', 'সপ্তাহজয়ী', 'টানা ৭ দিন পড়া', bs, 7], ['🌋', 'মাসজয়ী', 'টানা ৩০ দিন পড়া', bs, 30],
    ['🃏', 'কার্ড মাস্টার', '১০০টি কার্ড রিভিউ', fc, 100], ['🩹', 'ভুল শোধরানো', 'ভুলের খাতার ১০টি আয়ত্ত', mo, 10], ['🌅', 'রোজকার চ্যালেঞ্জার', '৭টি আজকের চ্যালেঞ্জ', dl, 7],
    ['📝', 'প্রথম কুইজ', 'একটি উপ-অধ্যায়ের কুইজ', qz, 1], ['🏆', 'মেগা যোদ্ধা', 'একটি মেগা টেস্ট সম্পন্ন', mg ? 1 : 0, 1], ['⭐', 'দক্ষ', 'লেভেল ৫ এ পৌঁছানো', x.L, 5],
    ['🔖', 'সংগ্রাহক', '২০টি জিনিস ★ সংরক্ষণ', Object.keys(S.sv || {}).length, 20], ['🖍', 'হাইলাইটার', '২৫টি হাইলাইট', LESSONS_ALL.reduce((a, l) => a + (S.hl[l.id] || []).length, 0), 25], ['💡', 'ট্রিক শিকারি', '২০টি মনে রাখার ট্রিক আয়ত্ত', Object.keys(S.trk || {}).length, 20], ['🧙', 'স্মৃতির জাদুকর', '১০০টি ট্রিক আয়ত্ত', Object.keys(S.trk || {}).length, 100], ['🌟', 'তারকা', 'লেভেল ১০ এ পৌঁছানো', x.L, 10]];
}
VIEWS.badges = () => { const b = badges(), got = b.filter(x => x[3] >= x[4]).length;
  return { title: 'অর্জন', nav: 'practice', html: `<div class="wrap stack"><div><span class="eyebrow">ব্যাজ ও অর্জন</span><h1 class="h-sec">অর্জন · ${bn(got)}/${bn(b.length)}</h1></div>${bar(got / b.length * 100, 'a2')}
    <div class="badges">${b.map(([e, n, d, v, t]) => { const ok = v >= t; return `<div class="badge ${ok ? 'got' : ''}"><span class="be">${e}</span><b>${n}</b><small>${d}</small>${ok ? '<span class="chip ok">অর্জিত</span>' : `<span class="bar thin"><i style="width:${clamp(v / t, 0, 1) * 100}%"></i></span><small class="mono">${bn(Math.min(v, t))}/${bn(t)}</small>`}</div>`; }).join('')}</div></div>` }; };

Object.assign(ACT, {
  fcMode: b => { FC = null; go('flash', { sid: (cur.args.sid || 'all'), mode: b.dataset.k }, { replace: true }); },
  fcFlip: () => { if (!FC) return; FC.flip = !FC.flip; render(true); },
  srs: b => { const c = FC && FC.order[FC.i]; if (!c) return; const g = +b.dataset.g; S.srs = S.srs || {}; S.srs[c.id] = srsNext(S.srs[c.id], g); S.fc[c.id] = g >= 2 ? Math.min(3, (S.fc[c.id] || 0) + 1) : 0; S.fcN = (S.fcN || 0) + 1; touch('q', c.sid, 0.5);
    if (g === 0) FC.order.push(c); FC.order.splice(FC.i, 1); if (FC.i >= FC.order.length) FC.i = 0; FC.flip = false; render(true); },
  mistTab: b => { cur.args.tab = b.dataset.tab; cur.args.r = 'all'; render(); },
  mistR: b => { cur.args.r = b.dataset.r; render(true); },
  mistReason: b => { const M = S.mist[b.dataset.id]; if (!M) return; M.reason = M.reason === b.dataset.r ? '' : b.dataset.r; save(); render(true); }
});
HS.quick = (() => { const base = HS.quick; return () => base().replace(/<button class="qk[^"]*" data-act="quiz" data-id="wrong"[\s\S]*?<\/button>/, () => { const n = mistOf(false).length; return `<button class="qk" data-act="go" data-v="mistakes"><span class="ti">${ico('alert')}</span><b>ভুলের খাতা</b><small>${n ? bn(n) + 'টি চলমান · ৩ বার সঠিকে আয়ত্ত' : 'কোনো চলমান ভুল নেই'}</small></button>`; }).replace(/(<b>ফ্ল্যাশকার্ড<\/b><small>)[^<]*/, (_, a) => a + `আজ ${bn(fcDueCount())}টি রিভিউ বাকি`); })();

/* ═══════════════ PLUS (ধাপ ৩): টেস্ট বিল্ডার ও টাইমড টেস্ট · CQ ল্যাব ═══════════════ */
const mmss = ms => { const s = Math.max(0, Math.round(ms / 1000)); return bn(Math.floor(s / 60)) + ':' + bn(String(s % 60).padStart(2, '0')); };
const TB_DEF = { secs: 'all', n: 20, mix: 'std', tpq: 60, src: 'all', fb: 'end', pre: 'custom' };
const MIXES = { std: ['বোর্ড ধাঁচ ৩০:৫০:২০', { e: .3, m: .5, h: .2 }], easy: ['সহজ বেশি ৬০:৩০:১০', { e: .6, m: .3, h: .1 }], hard: ['কঠিন বেশি ১০:৪০:৫০', { e: .1, m: .4, h: .5 }], any: ['এলোমেলো', null] };
const PRESETS = { practice: ['প্র্যাকটিস', { n: 20, tpq: 60, fb: 'now', mix: 'std' }, 'সাথে সাথে উত্তর ও ব্যাখ্যা · থামানো যায়'], board: ['বোর্ড সিমুলেশন', { n: 25, tpq: 60, fb: 'end', mix: 'std' }, '২৫ প্রশ্ন · ২৫ মিনিট · শেষে ফল'], speed: ['স্পিড ড্রিল', { n: 10, tpq: 20, fb: 'end', mix: 'any' }, '১০ প্রশ্ন · প্রতিটি ২০ সেকেন্ড'], weak: ['দুর্বল টপিক', { n: 15, tpq: 60, fb: 'now', mix: 'any', src: 'wrong' }, 'ভুল ও কম আয়ত্ত প্রশ্ন থেকে'] };
function tbPool(o) {
  let secs = SECS.filter(s => s.allM.length && (o.secs === 'all' || o.secs.split(',').includes(s.id)));
  let ids = secs.reduce((a, s) => a.concat(s.allM), []);
  if (o.src === 'new') ids = ids.filter(id => !S.qs[id]); else if (o.src === 'wrong') ids = ids.filter(id => S.wrong[id] || (S.mist && S.mist[id] && !S.mist[id].ok) || (S.qs[id] && !S.qs[id].last));
  return ids;
}
function pickMix(ids, n, mix) {
  ids = shuffle(ids).sort((a, b) => (S.qs[a] ? 1 : 0) - (S.qs[b] ? 1 : 0));
  if (!mix) return ids.slice(0, n);
  const out = [], by = { e: [], m: [], h: [] }; ids.forEach(id => (by[MCQ[id].d] || by.m).push(id));
  ['e', 'm', 'h'].forEach(d => out.push(...by[d].splice(0, Math.round(n * mix[d]))));
  const rest = by.e.concat(by.m, by.h); while (out.length < n && rest.length) out.push(rest.shift());
  return shuffle(out.slice(0, n));
}
VIEWS.testBuild = () => {
  const o = S.tb = Object.assign({}, TB_DEF, S.tb || {}), pool = tbPool(o), run = S.test && !S.test.done;
  const secSel = o.secs === 'all' ? [] : o.secs.split(',');
  return { title: 'টেস্ট বিল্ডার', nav: 'practice', html: `<div class="wrap stack"><div><span class="eyebrow">অধ্যায় ${CH.no} · ${CH.t}</span><h1 class="h-sec">টেস্ট বিল্ডার</h1></div>
    ${run ? `<div class="card row" style="gap:10px;border-color:var(--accent-2)"><span style="font-size:24px">⏸</span><span style="flex:1;min-width:0"><b>একটি টেস্ট চলমান</b><br><span class="small muted">${bn(Object.keys(S.test.ans).length)}/${bn(S.test.items.length)} উত্তর · সময় বাকি ${mmss(S.test.dur - S.test.used)}</span></span><button class="btn primary sm" data-act="go" data-v="testRun">চালিয়ে যাও</button></div>` : ''}
    <div class="presets">${Object.entries(PRESETS).map(([k, [n, , d]]) => `<button class="pbtn ${o.pre === k ? 'on' : ''}" data-act="tbPre" data-k="${k}"><b>${n}</b><small>${d}</small></button>`).join('')}</div>
    <section class="card stack" style="gap:10px"><b>উপ-অধ্যায়</b><div class="chips"><button class="schip ${o.secs === 'all' ? 'on' : ''}" data-act="tbSec" data-id="all">পুরো অধ্যায়</button>${SECS.filter(s => s.allM.length).map(s => `<button class="schip ${secSel.includes(s.id) ? 'on' : ''}" data-act="tbSec" data-id="${s.id}">${s.cat === 'E' ? '★' : s.no} <b>${bn(s.allM.length)}</b></button>`).join('')}</div>
    <b>প্রশ্নের সংখ্যা</b><div class="seg">${[10, 20, 25, 30, 50].map(v => `<button data-act="tbSet" data-k="n" data-v="${v}" class="${o.n === v ? 'on' : ''}">${bn(v)}</button>`).join('')}</div>
    <b>কঠিনতার মিশ্রণ</b><div class="seg">${Object.entries(MIXES).map(([k, [n]]) => `<button data-act="tbSet" data-k="mix" data-v="${k}" class="${o.mix === k ? 'on' : ''}">${n}</button>`).join('')}</div>
    <b>প্রতি প্রশ্নে সময়</b><div class="seg">${[[20, '২০ সে.'], [36, '৩৬ সে.'], [60, '১ মি.'], [90, '১.৫ মি.'], [0, 'সময়হীন']].map(([v, n]) => `<button data-act="tbSet" data-k="tpq" data-v="${v}" class="${o.tpq === v ? 'on' : ''}">${n}</button>`).join('')}</div>
    <b>প্রশ্নের উৎস</b><div class="seg">${[['all', 'সব'], ['new', 'আগে না দেওয়া'], ['wrong', 'ভুল/দুর্বল']].map(([v, n]) => `<button data-act="tbSet" data-k="src" data-v="${v}" class="${o.src === v ? 'on' : ''}">${n}</button>`).join('')}</div>
    <b>উত্তর দেখানো</b><div class="seg">${[['now', 'সাথে সাথে'], ['end', 'শেষে']].map(([v, n]) => `<button data-act="tbSet" data-k="fb" data-v="${v}" class="${o.fb === v ? 'on' : ''}">${n}</button>`).join('')}</div></section>
    <div class="small muted">এই সেটিংসে প্রশ্নব্যাংকে আছে ${bn(pool.length)}টি প্রশ্ন${pool.length < o.n ? ` — <b style="color:var(--bad)">${bn(o.n)}টির কম, তাই ${bn(pool.length)}টি দিয়ে টেস্ট হবে</b>` : ''} · মোট সময় ${o.tpq ? mmss(Math.min(o.n, pool.length) * o.tpq * 1000) : 'সীমাহীন'} · নেগেটিভ মার্কিং নেই</div>
    <button class="btn primary block" data-act="tbStart" ${pool.length ? '' : 'disabled'}>${ico('play')}টেস্ট শুরু করো</button>
    <button class="btn block" data-act="go" data-v="testHistory">${ico('chart')}টেস্টের ইতিহাস (${bn((S.tests || []).length)})</button></div>` };
};
let TT = null;
function tSave() { if (S.test) save({ cloud: false }); }
VIEWS.testRun = () => {
  const T = S.test; if (!T || T.done) return VIEWS.testBuild();
  const id = T.items[T.i], m = MCQ[id], pick = T.ans[id], shown = T.fb === 'now' && pick != null;
  return { title: 'চলমান টেস্ট', eye: `প্রশ্ন ${bn(T.i + 1)}/${bn(T.items.length)}`, nav: 'practice', html: `<div class="wrap stack">
    <div class="row t-top"><span class="timer big ${T.dur && T.dur - T.used < 60000 ? 'low' : ''}" id="tTimer">${T.dur ? mmss(T.dur - T.used) : mmss(T.used)}</span><span class="small muted">${bn(Object.keys(T.ans).length)}/${bn(T.items.length)} উত্তর</span><span class="sp"></span>${T.fb === 'now' ? `<button class="btn sm" data-act="tPause">${ico('pause')}থামাও</button>` : ''}<button class="btn sm primary" data-act="tSubmit">জমা দাও</button></div>
    <div class="qcard" data-q="${id}"><div class="qhead"><span class="chip">প্রশ্ন ${bn(T.i + 1)}</span><span class="chip ${m.d}">${DL[m.d]}</span><span class="chip">${SMAP[m.sid].no}</span><span class="sp"></span><button class="btn sm ${T.mark[id] ? 'primary' : ''}" data-act="tMark">${ico('bm')}${T.mark[id] ? 'চিহ্নিত' : 'পরে দেখব'}</button></div>
    <div class="qtext">${m.q}</div><div class="opts">${m.o.map((o, i) => `<button class="opt ${pick === i ? 'sel' : ''} ${shown && i === m.a ? 'right' : ''} ${shown && pick === i && i !== m.a ? 'wrong' : ''}" data-act="tPick" data-i="${i}" ${shown ? 'disabled' : ''}><span class="ol">${OL[i]}</span><span>${o}</span></button>`).join('')}</div><div class="fb">${shown ? feedbackHTML(m, pick) : ''}</div></div>
    <div class="grid2"><button class="btn" data-act="tStep" data-d="-1" ${T.i ? '' : 'disabled'}>${ico('prev')}আগের</button><button class="btn" data-act="tStep" data-d="1">${T.i < T.items.length - 1 ? 'পরের' : 'প্রথমে'}${ico('next')}</button></div>
    <div class="card stack" style="gap:8px;padding:12px"><div class="row small"><b>প্রশ্ন-প্যালেট</b><span class="sp"></span><span class="pl-k a"></span>উত্তর<span class="pl-k m"></span>চিহ্নিত<span class="pl-k"></span>বাকি</div><div class="palette">${T.items.map((q, k) => `<button class="${T.ans[q] != null ? 'a' : ''} ${T.mark[q] ? 'm' : ''} ${k === T.i ? 'cur' : ''}" data-act="tJump" data-i="${k}">${bn(k + 1)}</button>`).join('')}</div></div></div>`,
    after() { T.qAt = Date.now(); let last = Date.now(); const iv = setInterval(() => { if (!S.test || S.test.done || T.paused) { last = Date.now(); return; } const now = Date.now(); T.used += now - last; last = now; const el = $('#tTimer'); if (el) { el.textContent = T.dur ? mmss(T.dur - T.used) : mmss(T.used); el.classList.toggle('low', T.dur && T.dur - T.used < 60000); } if (T.dur && T.used >= T.dur) { clearInterval(iv); toast('সময় শেষ — টেস্ট নিজে থেকেই জমা হলো'); tFinish(); } }, 1000); const sv = setInterval(tSave, 5000); cleanups.push(() => { clearInterval(iv); clearInterval(sv); if (S.test === T && !T.done && !T.paused) T.used += Date.now() - last; tSave(); }); }
  };
};
function tFinish() {
  const T = S.test; if (!T || T.done) return; cleanups.forEach(f => { try { f(); } catch (e) { } }); cleanups = []; T.done = true; let c = 0, w = 0;
  T.items.forEach(id => { const p = T.ans[id]; if (p == null) return; const ok = p === MCQ[id].a; if (ok) c++; else w++; if (T.fb !== 'now') recordQ(id, ok); });
  const rec = { id: 't' + Date.now(), at: T.at, ch: CH.id, n: T.items.length, c, w, s: T.items.length - c - w, p: c / T.items.length, dur: T.dur, used: T.used, items: T.items, ans: T.ans, times: T.times || {}, pre: T.pre };
  S.tests = (S.tests || []).concat([rec]).slice(-20); S.testsN = (S.testsN || 0) + 1; S.test = null; save(); touch('q', null, 0);
  go('testResult', { tid: rec.id }, { replace: true });
}
VIEWS.testResult = ({ tid }) => {
  const R = (S.tests || []).find(x => x.id === tid) || (S.tests || []).slice(-1)[0]; if (!R) return VIEWS.testBuild();
  const acc = R.c + R.w ? R.c / (R.c + R.w) : 0, bySec = {};
  R.items.forEach(id => { const m = MCQ[id]; if (!m) return; const b = bySec[m.sid] = bySec[m.sid] || [0, 0]; b[1]++; if (R.ans[id] === m.a) b[0]++; });
  return { title: 'টেস্টের ফল', nav: 'practice', html: `<div class="wrap stack">
    <div class="card row" style="gap:18px;align-items:center">${ring(R.p * 100, 128, 11, 'স্কোর')}<div style="flex:1;min-width:170px" class="stack" style="gap:4px"><b style="font-size:20px">${bn(R.c)}/${bn(R.n)} সঠিক · ${p2(R.p)}%</b><span class="small muted">ভুল ${bn(R.w)} · বাদ ${bn(R.s)} · নির্ভুলতা ${p2(acc)}%</span><span class="small muted">সময় ${mmss(R.used)}${R.dur ? ' / ' + mmss(R.dur) : ''} · প্রতি প্রশ্নে গড় ${bn(Math.round(R.used / R.n / 1000))} সে.</span><span class="small">${R.p >= .8 ? '🌟 চমৎকার! A+ এর পথে।' : R.p >= .6 ? '👍 ভালো — দুর্বল উপ-অধ্যায়গুলো ঝালিয়ে নাও।' : '📖 নিচের উপ-অধ্যায়গুলো আবার পড়ে আবার টেস্ট দাও।'}</span></div></div>
    <div class="card stack" style="gap:8px"><b>উপ-অধ্যায়ভিত্তিক</b>${Object.entries(bySec).map(([sid, [c, n]]) => `<div><div class="row small"><span class="mono muted">${SMAP[sid].no}</span><span style="flex:1;min-width:0">${SMAP[sid].t}</span><b>${bn(c)}/${bn(n)}</b>${c / n < .6 ? ' ⚠' : ''}</div>${bar(c / n * 100, c / n >= .6 ? 'ok' : '')}</div>`).join('')}</div>
    <details class="blk" open><summary><span class="bi">${ico('list')}</span>OMR রিভিউ ও ব্যাখ্যা<span class="chev">${ico('chev')}</span></summary><div class="bd stack" style="gap:10px">${R.items.map((id, k) => { const m = MCQ[id]; if (!m) return ''; const p = R.ans[id], ok = p === m.a; return `<div class="qa omr"><div class="q"><b>${bn(k + 1)}.</b> ${m.q} <span class="chip ${p == null ? '' : ok ? 'ok' : 'bad'}">${p == null ? 'বাদ' : ok ? 'সঠিক' : 'ভুল'}</span></div><div class="omr-row">${m.o.map((o, i) => `<span class="${i === m.a ? 'r' : ''} ${i === p && !ok ? 'w' : ''}"><i>${OL[i]}</i>${o}</span>`).join('')}</div>${m.x ? `<div class="small muted">${m.x}</div>` : ''}${readLink(m)}</div>`; }).join('')}</div></details>
    <div class="grid2"><button class="btn primary" data-act="go" data-v="testBuild">${ico('repeat')}নতুন টেস্ট</button><button class="btn" data-act="go" data-v="testHistory">${ico('chart')}ইতিহাস</button></div>
    <button class="btn" data-act="go" data-v="mistakes">${ico('alert')}ভুলগুলো ভুলের খাতায় দেখো</button></div>` };
};
VIEWS.testHistory = () => {
  const H = (S.tests || []).slice().reverse(), last10 = H.slice(0, 10).reverse();
  const best = H.reduce((a, x) => Math.max(a, x.p), 0);
  return { title: 'টেস্টের ইতিহাস', nav: 'practice', html: `<div class="wrap stack"><div><span class="eyebrow">শেষ ২০টি টেস্ট</span><h1 class="h-sec">টেস্টের ইতিহাস</h1></div>
    ${H.length ? `<div class="card stack" style="gap:8px"><div class="row small"><b>শেষ ১০ টেস্টের স্কোর</b><span class="sp"></span><span class="muted">সেরা ${p2(best)}%</span></div><div class="th-bars">${last10.map(x => `<span class="th-col"><span class="th-v">${bn(Math.round(x.p * 100))}</span><span class="th-bar"><i style="height:${Math.max(3, x.p * 100)}%" class="${x.p >= .8 ? 'hi' : x.p >= .6 ? 'mid' : ''}"></i></span><span class="th-d">${bn(dOf(dkey(new Date(x.at))).getDate())}</span></span>`).join('')}</div></div>
    <div class="lesson-list">${H.map(x => `<button class="li" data-act="go" data-v="testResult" data-tid="${x.id}"><span class="no">${bn(Math.round(x.p * 100))}%</span><span class="t">${(PRESETS[x.pre] || ['কাস্টম'])[0]} · অধ্যায় ${CHMAP[x.ch] ? CHMAP[x.ch].no : ''} · ${bn(x.c)}/${bn(x.n)}<small>${dateBn(new Date(x.at))} · ${mmss(x.used)}</small></span>${ico('next')}</button>`).join('')}</div>`
      : '<div class="empty">এখনো কোনো টেস্ট দেওয়া হয়নি।</div>'}<button class="btn primary" data-act="go" data-v="testBuild">${ico('play')}টেস্ট বিল্ডার</button></div>` };
};

/* ---------- CQ ল্যাব ---------- */
const CQM = [1, 2, 3, 4], CQL = ['জ্ঞান', 'অনুধাবন', 'প্রয়োগ', 'উচ্চতর দক্ষতা'], CQP = ['ক', 'খ', 'গ', 'ঘ'];
const RUB = [['সংজ্ঞা/তথ্যটি নির্ভুল ও সম্পূর্ণ?'], ['মূল ধারণাটি উল্লেখ করা হয়েছে?', 'কারণ/ব্যাখ্যা যুক্তিসহ লেখা হয়েছে?'], ['সঠিক সূত্র/নীতি লেখা হয়েছে?', 'উদ্দীপকের মান বসানো ও ধাপগুলো দেখানো হয়েছে?', 'উত্তর একক সহ সঠিক?'], ['উদ্দীপকের সাথে সংযোগ দেখানো হয়েছে?', 'একাধিক দিক বিশ্লেষণ/তুলনা করা হয়েছে?', 'যুক্তিসংগত সিদ্ধান্ত টানা হয়েছে?', 'প্রয়োজনে হিসাব/সমীকরণ দিয়ে সমর্থন?']];
const cqList = () => { const a = []; SECS.forEach(s => (s.Q.cq || []).forEach((c, i) => { if (c && c.p && c.p.length === 4) a.push({ id: s.id + 'q' + i, sid: s.id, c }); })); return a; };
const cqGet = id => cqList().find(x => x.id === id);
const cqSt = id => (S.cq || {})[id];
const cqTot = r => r && r.marks ? r.marks.reduce((a, b) => a + (b || 0), 0) : null;
VIEWS.cqLab = ({ f = 'all' }) => {
  let L = cqList(); const st = { todo: L.filter(x => !cqSt(x.id)), draft: L.filter(x => cqSt(x.id) && !cqSt(x.id).done), done: L.filter(x => cqSt(x.id) && cqSt(x.id).done) };
  if (f !== 'all') L = st[f];
  const avg = st.done.length ? st.done.reduce((a, x) => a + cqTot(cqSt(x.id)), 0) / st.done.length : 0;
  return { title: 'CQ ল্যাব', nav: 'practice', html: `<div class="wrap stack"><div><span class="eyebrow">সৃজনশীল প্রশ্নের লেখা-অনুশীলন · অধ্যায় ${CH.no}</span><h1 class="h-sec">CQ ল্যাব</h1><p class="small muted" style="margin:4px 0 0">উদ্দীপক পড়ে ক (জ্ঞান, ১), খ (অনুধাবন, ২), গ (প্রয়োগ, ৩), ঘ (উচ্চতর দক্ষতা, ৪) — মোট ১০ নম্বর। টাইমার চালিয়ে লেখো (বোর্ডে প্রতি CQ তে ~২৫ মিনিট), তারপর রুব্রিক মিলিয়ে নিজে নম্বর দাও ও মডেল উত্তরের সাথে তুলনা করো। লেখা প্রতি ৫ সেকেন্ডে নিজে থেকেই সংরক্ষিত হয়।</p></div>
    <div class="kv"><div><b>${bn(L.length && f === 'all' ? L.length : cqList().length)}</b><span>মোট CQ</span></div><div><b>${bn(st.done.length)}</b><span>মূল্যায়িত</span></div><div><b>${bn(st.draft.length)}</b><span>খসড়া/মূল্যায়ন বাকি</span></div><div><b>${st.done.length ? p2(avg / 10) + '%' : '০.০০%'}</b><span>গড় নম্বর (${st.done.length ? bn(avg.toFixed(1)) : '০'}/১০)</span></div></div>
    <div class="tabs">${[['all', 'সব'], ['todo', 'শুরু হয়নি'], ['draft', 'খসড়া'], ['done', 'মূল্যায়িত']].map(([k, n]) => `<button class="${f === k ? 'on' : ''}" data-act="cqF" data-f="${k}">${n} (${bn(k === 'all' ? cqList().length : st[k].length)})</button>`).join('')}</div>
    <div class="lesson-list">${L.map(x => { const r = cqSt(x.id), t = cqTot(r); return `<button class="li" data-act="go" data-v="${r && r.done ? 'cqReview' : 'cqWrite'}" data-cid="${x.id}"><span class="no">${SMAP[x.sid].no}</span><span class="t">${strip(x.c.s).slice(0, 90)}…<small>${r ? r.done ? `মূল্যায়িত · ${bn(t)}/১০ · ${p2(t / 10)}%` : 'খসড়া — লেখা চালিয়ে যাও' : 'শুরু হয়নি'}</small></span>${r && r.done ? `<span class="chip ${t >= 8 ? 'ok' : t >= 5 ? 'warn' : 'bad'}">${bn(t)}</span>` : ico('next')}</button>`; }).join('') || '<div class="empty">এই তালিকায় কিছু নেই।</div>'}</div></div>` };
};
VIEWS.cqWrite = ({ cid }) => {
  const x = cqGet(cid); if (!x) return VIEWS.cqLab({});
  S.cq = S.cq || {}; const r = S.cq[cid] = S.cq[cid] || { ans: ['', '', '', ''], used: 0, at: Date.now() };
  return { title: 'CQ লেখো', eye: SMAP[x.sid].no + ' · ' + SMAP[x.sid].t, nav: 'practice', html: `<div class="wrap stack">
    <div class="row t-top"><span class="timer big" id="cqTimer">${mmss(r.used)}</span><span class="small muted">লক্ষ্য ২৫:০০</span><span class="sp"></span><span class="small muted" id="cqSaved">সংরক্ষিত</span></div>
    <div class="card"><div class="eyebrow" style="margin-bottom:6px">উদ্দীপক</div><div>${x.c.s}</div></div>
    ${x.c.p.map((p, i) => `<div class="card stack" style="gap:6px"><div class="row" style="gap:6px"><span class="chip">${CQP[i]}</span><span class="small muted">${CQL[i]} · ${bn(CQM[i])} নম্বর</span><span class="sp"></span><span class="small muted mono" data-wc="${i}">${bn((r.ans[i] || '').trim().split(/\s+/).filter(Boolean).length)} শব্দ</span></div><div><b>${p[0]}</b></div><textarea class="inp cq-ta" data-cq="${i}" rows="${[3, 5, 7, 9][i]}" placeholder="এখানে উত্তর লেখো…">${esc(r.ans[i] || '')}</textarea></div>`).join('')}
    <div class="small muted">💡 ${['ক: এক-দুই বাক্যে সংজ্ঞা/তথ্য।', 'খ: মূল ধারণা + কারণ, দুটি পয়েন্ট।', 'গ: সূত্র → মান বসানো → ধাপ → একক সহ উত্তর।', 'ঘ: উদ্দীপকের সাথে সংযোগ, বিশ্লেষণ, সিদ্ধান্ত।'].join(' ')}</div>
    <button class="btn primary block" data-act="cqSubmit" data-cid="${cid}">${ico('check')}জমা দাও ও নিজে মূল্যায়ন করো</button></div>`,
    after() { let last = Date.now(), dirty = false; const iv = setInterval(() => { const now = Date.now(); r.used += now - last; last = now; const el = $('#cqTimer'); if (el) el.textContent = mmss(r.used); }, 1000);
      $$('.cq-ta').forEach(t => t.addEventListener('input', () => { const i = +t.dataset.cq; r.ans[i] = t.value; dirty = true; const w = $(`[data-wc="${i}"]`); if (w) w.textContent = bn(t.value.trim().split(/\s+/).filter(Boolean).length) + ' শব্দ'; const sv = $('#cqSaved'); if (sv) sv.textContent = 'লেখা হচ্ছে…'; }));
      const sv = setInterval(() => { if (dirty) { dirty = false; save({ cloud: false }); const e = $('#cqSaved'); if (e) e.textContent = 'সংরক্ষিত ✓'; } }, 5000);
      cleanups.push(() => { clearInterval(iv); clearInterval(sv); r.used += Date.now() - last; save({ cloud: false }); }); }
  };
};
VIEWS.cqReview = ({ cid }) => {
  const x = cqGet(cid), r = cqSt(cid); if (!x || !r) return VIEWS.cqLab({});
  r.marks = r.marks || [null, null, null, null]; r.chk = r.chk || {};
  const t = cqTot(r);
  return { title: 'CQ মূল্যায়ন', eye: SMAP[x.sid].no + ' · ' + SMAP[x.sid].t, nav: 'practice', html: `<div class="wrap stack">
    <div class="card row" style="gap:14px">${ring((t || 0) * 10, 96, 9, 'নম্বর')}<span style="flex:1;min-width:0"><b style="font-size:18px">${bn(t || 0)}/১০ · ${p2((t || 0) / 10)}%</b><br><span class="small muted">লিখতে সময় লেগেছে ${mmss(r.used)} · প্রতিটি অংশে রুব্রিক মিলিয়ে নম্বর বেছে নাও</span></span></div>
    <details class="card"><summary style="cursor:pointer;font-weight:600">উদ্দীপক</summary><div style="margin-top:6px">${x.c.s}</div></details>
    ${x.c.p.map((p, i) => `<div class="card stack" style="gap:8px"><div class="row" style="gap:6px"><span class="chip">${CQP[i]}</span><b style="flex:1;min-width:0">${p[0]}</b><span class="small muted">${CQL[i]}</span></div>
      <div class="cmp2"><div><div class="eyebrow">তোমার উত্তর</div><div class="yours">${r.ans[i] ? esc(r.ans[i]).replace(/\n/g, '<br>') : '<span class="muted">(লেখা হয়নি)</span>'}</div></div><div><div class="eyebrow">মডেল উত্তর</div><div class="model">${p[1]}</div></div></div>
      <div class="rub">${RUB[i].map((q, k) => `<label class="small"><input type="checkbox" data-act="cqChk" data-cid="${cid}" data-k="${i}-${k}" ${r.chk[i + '-' + k] ? 'checked' : ''}> ${q}</label>`).join('')}</div>
      <div class="row" style="gap:6px"><span class="small">নম্বর:</span>${Array.from({ length: CQM[i] + 1 }, (_, v) => `<button class="mk ${r.marks[i] === v ? 'on' : ''}" data-act="cqMark" data-cid="${cid}" data-i="${i}" data-v="${v}">${bn(v)}</button>`).join('')}<span class="small muted">/ ${bn(CQM[i])}</span></div></div>`).join('')}
    <div class="grid2"><button class="btn" data-act="go" data-v="cqWrite" data-cid="${cid}">${ico('pen')}উত্তর আবার লেখো</button><button class="btn primary" data-act="go" data-v="cqLab">${ico('list')}CQ তালিকা</button></div></div>` };
};
HSEC.splice(HSEC.findIndex(x => x[0] === 'level'), 0, ['cq', 'CQ অনুশীলন']);
HS.cq = () => { const L = cqList(); if (!L.length) return ''; const dr = L.filter(x => cqSt(x.id) && !cqSt(x.id).done), dn = L.filter(x => cqSt(x.id) && cqSt(x.id).done), nx = dr[0] || L.find(x => !cqSt(x.id));
  return `<div class="card stack" style="gap:8px;padding:14px"><div class="row"><b>CQ অনুশীলন</b><span class="sp"></span><button class="btn sm ghost" data-act="go" data-v="cqLab">সব (${bn(L.length)}) ›</button></div><div class="small muted">মূল্যায়িত ${bn(dn.length)} · খসড়া ${bn(dr.length)}${dn.length ? ' · গড় ' + p2(dn.reduce((a, x) => a + cqTot(cqSt(x.id)), 0) / dn.length / 10) + '%' : ''}</div>${nx ? `<button class="li" style="border:1px solid var(--line);border-radius:12px" data-act="go" data-v="cqWrite" data-cid="${nx.id}"><span class="no">${SMAP[nx.sid].no}</span><span class="t">${dr[0] ? 'খসড়া চালিয়ে যাও' : 'পরের প্রস্তাব'}<small>${strip(nx.c.s).slice(0, 70)}…</small></span>${ico('next')}</button>` : ''}</div>`; };
const _go = ACT.go;
Object.assign(ACT, {
  go: (b, e) => { if (b.dataset.cid || b.dataset.tid) { go(b.dataset.v, { cid: b.dataset.cid, tid: b.dataset.tid }); return; } _go(b, e); },
  tbPre: b => { const k = b.dataset.k, P = PRESETS[k]; S.tb = Object.assign({}, TB_DEF, S.tb || {}, P[1], { pre: k, src: P[1].src || 'all' }); save(); render(true); },
  tbSec: b => { const o = S.tb; const id = b.dataset.id; if (id === 'all') o.secs = 'all'; else { const a = o.secs === 'all' ? [] : o.secs.split(','); const i = a.indexOf(id); if (i >= 0) a.splice(i, 1); else a.push(id); o.secs = a.length ? a.join(',') : 'all'; } o.pre = 'custom'; save(); render(true); },
  tbSet: b => { const o = S.tb, k = b.dataset.k; o[k] = ['n', 'tpq'].includes(k) ? +b.dataset.v : b.dataset.v; o.pre = 'custom'; save(); render(true); },
  tbStart: b => { if (S.test && !S.test.done && !b.dataset.arm) { b.dataset.arm = 1; b.innerHTML = ico('alert') + 'আগের টেস্ট বাতিল হবে — আবার চাপো'; return; } const o = S.tb, items = pickMix(tbPool(o), o.n, MIXES[o.mix][1]); if (!items.length) return; S.test = { at: Date.now(), items, ans: {}, mark: {}, i: 0, dur: o.tpq ? items.length * o.tpq * 1000 : 0, used: 0, fb: o.fb, pre: o.pre, ch: CH.id }; save(); go('testRun'); },
  tPick: b => { const T = S.test, id = T.items[T.i], v = +b.dataset.i; if (T.fb === 'now' && T.ans[id] != null) return; T.ans[id] = v; if (T.fb === 'now') recordQ(id, v === MCQ[id].a); tSave(); if (T.fb !== 'now' && T.i < T.items.length - 1) { setTimeout(() => { T.i++; render(); }, 180); } render(true); },
  tStep: b => { const T = S.test; T.i = (T.i + +b.dataset.d + T.items.length) % T.items.length; tSave(); render(); },
  tJump: b => { S.test.i = +b.dataset.i; render(); },
  tMark: () => { const T = S.test, id = T.items[T.i]; if (T.mark[id]) delete T.mark[id]; else T.mark[id] = 1; tSave(); render(true); },
  tPause: b => { const T = S.test; T.paused = !T.paused; b.innerHTML = T.paused ? ico('play') + 'চালাও' : ico('pause') + 'থামাও'; toast(T.paused ? 'টেস্ট থামানো হয়েছে' : 'আবার চলছে'); },
  tSubmit: b => { const T = S.test, un = T.items.length - Object.keys(T.ans).length, mk = Object.keys(T.mark).length; if ((un || mk) && !b.dataset.arm) { b.dataset.arm = 1; b.textContent = `${un ? bn(un) + 'টি বাকি' : ''}${un && mk ? ', ' : ''}${mk ? bn(mk) + 'টি চিহ্নিত' : ''} — নিশ্চিত?`; return; } tFinish(); },
  cqF: b => { cur.args.f = b.dataset.f; render(true); },
  cqSubmit: b => { const r = cqSt(b.dataset.cid); if (!r) return; if (!r.sub) { r.sub = Date.now(); S.cqN = (S.cqN || 0) + 1; } save(); go('cqReview', { cid: b.dataset.cid }, { replace: true }); },
  cqMark: b => { const r = cqSt(b.dataset.cid); r.marks[+b.dataset.i] = +b.dataset.v; r.done = r.marks.every(v => v != null); save(); render(true); if (r.done) toast('মূল্যায়ন সংরক্ষিত · ' + bn(cqTot(r)) + '/১০'); },
  cqChk: (b, e) => { const r = cqSt(b.dataset.cid); r.chk[b.dataset.k] = b.checked ? 1 : 0; save({ cloud: false }); }
});


/* ═══════════════ PLUS (ধাপ ৪): খেলা — মিলাও · জোড়া খোঁজো · ৬০ সেকেন্ডের স্পিড কুইজ ═══════════════ */
let GM = null;
const short = (h, n) => { const t = strip(h).replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n - 1) + '…' : t; };
const gCards = n => shuffle(deckOf('all').filter(c => strip(c.f).length < 90 && strip(c.b).length < 110)).slice(0, n);
const GAMES = { match: ['🔗', 'মিলাও', 'বাম পাশের প্রশ্নের সাথে ডান পাশের উত্তর মেলাও — ৫ জোড়া, সময় ধরে'], memory: ['🧠', 'জোড়া খোঁজো', '১২টি উল্টানো কার্ড — প্রশ্ন ও উত্তরের জোড়া খুঁজে বের করো, কম চালে'], speed: ['⚡', 'স্পিড কুইজ', '৬০ সেকেন্ডে যত বেশি সঠিক — টানা সঠিকে কম্বো বোনাস'] };
function gEnd(kind, win, score, better) {
  S.gamesN = (S.gamesN || 0) + 1; if (win) S.gameWins = (S.gameWins || 0) + 1; S.best = S.best || {};
  const old = S.best[kind]; const isBest = old == null || better(score, old); if (isBest) S.best[kind] = score; save(); touch('q', null, 0);
  return isBest;
}
VIEWS.games = () => ({ title: 'খেলা', nav: 'practice', html: `<div class="wrap stack"><div><span class="eyebrow">খেলতে খেলতে শেখা · অধ্যায় ${CH.no}</span><h1 class="h-sec">খেলা</h1><p class="small muted" style="margin:4px 0 0">এই অধ্যায়ের ফ্ল্যাশকার্ড ও MCQ থেকে তৈরি। প্রতি খেলায় +৫ XP, জিতলে আরও +৫; ভুলগুলো ভুলের খাতায় যায়।</p></div>
  <div class="stack" style="gap:10px">${Object.entries(GAMES).map(([k, [e, n, d]]) => { const b = (S.best || {})[k]; return `<button class="card game-t" data-act="gStart" data-k="${k}"><span class="ge">${e}</span><span style="flex:1;min-width:0"><b>${n}</b><small>${d}</small><small class="mono">${b == null ? 'এখনো খেলা হয়নি' : 'সেরা: ' + (k === 'match' ? mmss(b) : k === 'memory' ? bn(b) + ' চাল' : bn(b) + ' পয়েন্ট')}</small></span>${ico('next')}</button>`; }).join('')}</div></div>` });
VIEWS.game = () => {
  if (!GM) return VIEWS.games();
  if (GM.k === 'match') {
    const done = GM.pairs.every(p => p.ok);
    return { title: 'মিলাও', nav: 'practice', html: `<div class="wrap stack"><div class="row t-top"><span class="timer big" id="gT">${mmss((GM.end || Date.now()) - GM.t0)}</span><span class="small muted">${bn(GM.pairs.filter(p => p.ok).length)}/৫ জোড়া · ভুল ${bn(GM.miss)}</span><span class="sp"></span><button class="btn sm" data-act="gStart" data-k="match">${ico('repeat')}নতুন</button></div>
      ${done ? `<div class="card" style="text-align:center"><div style="font-size:36px">🎉</div><b>সব মিলেছে! সময় ${mmss(GM.end - GM.t0)}${GM.best ? ' · নতুন সেরা!' : ''}</b></div>` : ''}
      <div class="match"><div>${GM.pairs.map((p, i) => `<button class="mt ${p.ok ? 'ok' : ''} ${GM.selL === i ? 'sel' : ''}" data-act="gL" data-i="${i}" ${p.ok ? 'disabled' : ''}>${short(p.f, 80)}</button>`).join('')}</div><div>${GM.right.map(i => { const p = GM.pairs[i]; return `<button class="mt r ${p.ok ? 'ok' : ''} ${GM.bad === i ? 'bad' : ''}" data-act="gR" data-i="${i}" ${p.ok ? 'disabled' : ''}>${short(p.b, 100)}</button>`; }).join('')}</div></div></div>`,
      after() { if (done) return; const iv = setInterval(() => { const e = $('#gT'); if (e) e.textContent = mmss(Date.now() - GM.t0); }, 500); cleanups.push(() => clearInterval(iv)); } };
  }
  if (GM.k === 'memory') {
    const done = GM.cards.every(c => c.ok);
    return { title: 'জোড়া খোঁজো', nav: 'practice', html: `<div class="wrap stack"><div class="row"><b>চাল: ${bn(GM.moves)}</b><span class="small muted">· মিলেছে ${bn(GM.cards.filter(c => c.ok).length / 2)}/৬</span><span class="sp"></span><button class="btn sm" data-act="gStart" data-k="memory">${ico('repeat')}নতুন</button></div>
      ${done ? `<div class="card" style="text-align:center"><div style="font-size:36px">🧠</div><b>সব জোড়া পাওয়া গেছে — ${bn(GM.moves)} চালে${GM.best ? ' · নতুন সেরা!' : ''}</b></div>` : ''}
      <div class="mem">${GM.cards.map((c, i) => `<button class="mc ${c.ok ? 'ok' : ''} ${c.open || c.ok ? 'open' : ''}" data-act="gM" data-i="${i}" ${c.ok ? 'disabled' : ''}><span class="mc-b">?</span><span class="mc-f ${c.side}">${c.t}</span></button>`).join('')}</div>
      <div class="small muted">নীল = প্রশ্ন, সবুজ = উত্তর। একটি প্রশ্ন ও তার উত্তর একসাথে খুললে জোড়া মিলবে।</div></div>` };
  }
  const m = MCQ[GM.q], left = Math.max(0, GM.t0 + 60000 - Date.now());
  return { title: 'স্পিড কুইজ', nav: 'practice', html: `<div class="wrap stack"><div class="row t-top"><span class="timer big ${left < 10000 ? 'low' : ''}" id="gT">${mmss(left)}</span><b>${bn(GM.score)} পয়েন্ট</b><span class="small muted">কম্বো ×${bn(1 + Math.floor(GM.combo / 3))} · ${bn(GM.c)}✓ ${bn(GM.w)}✗</span></div>
    ${GM.over ? `<div class="card" style="text-align:center"><div style="font-size:36px">⚡</div><b>সময় শেষ! ${bn(GM.score)} পয়েন্ট${GM.best ? ' · নতুন সেরা!' : ''}</b><div class="small muted">${bn(GM.c)}টি সঠিক, ${bn(GM.w)}টি ভুল · সর্বোচ্চ কম্বো ${bn(GM.maxc)}</div><button class="btn primary" data-act="gStart" data-k="speed" style="margin-top:10px">${ico('repeat')}আবার খেলো</button></div>`
      : `<div class="qcard"><div class="qtext">${m.q}</div><div class="opts">${m.o.map((o, i) => `<button class="opt" data-act="gS" data-i="${i}"><span class="ol">${OL[i]}</span><span>${o}</span></button>`).join('')}</div></div>${GM.flash ? `<div class="small ${GM.flash[0] ? 'okc' : 'badc'}">${GM.flash[1]}</div>` : ''}`}</div>`,
    after() { if (GM.over) return; const iv = setInterval(() => { const l = GM.t0 + 60000 - Date.now(), e = $('#gT'); if (e) { e.textContent = mmss(l); e.classList.toggle('low', l < 10000); } if (l <= 0) { clearInterval(iv); GM.over = true; GM.best = gEnd('speed', GM.score >= 100, GM.score, (a, b) => a > b); render(); } }, 250); cleanups.push(() => clearInterval(iv)); } };
};
const speedNext = () => { const ids = SECS.reduce((a, s) => a.concat(s.allM), []).filter(id => !/<br>\s*i\./.test(MCQ[id].q) && strip(MCQ[id].q).length < 160); GM.q = ids[Math.floor(Math.random() * ids.length)]; };
Object.assign(ACT, {
  gStart: b => { const k = b.dataset.k;
    if (k === 'match') { const c = gCards(5); if (c.length < 5) { toast('এই অধ্যায়ে যথেষ্ট কার্ড নেই'); return; } GM = { k, pairs: c.map(x => ({ f: x.f, b: x.b, sid: x.sid, ok: 0 })), right: shuffle([0, 1, 2, 3, 4]), selL: null, miss: 0, t0: Date.now() }; }
    else if (k === 'memory') { const c = gCards(6); if (c.length < 6) { toast('এই অধ্যায়ে যথেষ্ট কার্ড নেই'); return; } GM = { k, cards: shuffle(c.reduce((a, x, i) => a.concat([{ p: i, t: short(x.f, 46), side: 'q' }, { p: i, t: short(x.b, 46), side: 'a' }]), [])), moves: 0, open: [] }; }
    else { GM = { k, t0: Date.now(), score: 0, combo: 0, maxc: 0, c: 0, w: 0 }; speedNext(); }
    if (cur.name === 'game') render(); else go('game'); },
  gL: b => { GM.selL = +b.dataset.i; GM.bad = null; render(true); },
  gR: b => { if (GM.selL == null) { toast('আগে বাম পাশের একটি বেছে নাও'); return; } const i = +b.dataset.i; if (i === GM.selL) { GM.pairs[i].ok = 1; GM.selL = null; if (GM.pairs.every(p => p.ok)) { GM.end = Date.now(); GM.best = gEnd('match', true, GM.end - GM.t0, (a, c) => a < c); } } else { GM.miss++; GM.bad = i; } render(true); },
  gM: b => { const i = +b.dataset.i, C = GM.cards; if (C[i].open || GM.lock) return; C[i].open = 1; GM.open.push(i); render(true);
    if (GM.open.length === 2) { GM.moves++; const [x, y] = GM.open; GM.lock = true; setTimeout(() => { if (C[x].p === C[y].p && C[x].side !== C[y].side) { C[x].ok = C[y].ok = 1; } C[x].open = C[y].open = 0; GM.open = []; GM.lock = false; if (C.every(c => c.ok)) GM.best = gEnd('memory', true, GM.moves, (a, c) => a < c); render(true); }, 750); } },
  gS: b => { if (GM.over) return; const m = MCQ[GM.q], ok = +b.dataset.i === m.a; recordQ(m.id, ok); if (ok) { GM.c++; GM.combo++; GM.maxc = Math.max(GM.maxc, GM.combo); GM.score += 10 * (1 + Math.floor((GM.combo - 1) / 3)); GM.flash = [1, '✓ সঠিক' + (GM.combo >= 3 ? ' · কম্বো ' + bn(GM.combo) : '')]; } else { GM.w++; GM.combo = 0; GM.flash = [0, '✗ সঠিক: (' + OL[m.a] + ') ' + short(m.o[m.a], 60)]; } speedNext(); render(true); }
});

/* ═══════════════ উৎসাহ ও ধরে রাখা: উদযাপন · স্ট্রিক রক্ষাকবচ · আজকের তথ্য · কম্বো ═══════════════ */
const CF_COL = ['#ff6b6b', '#ffd43b', '#51cf66', '#339af0', '#cc5de8', '#ff922b', '#22b8cf'];
function celebrate(e, t, sub, btn) {
  const old = $('#celebrate'); if (old) old.remove();
  const w = document.createElement('div'); w.className = 'celebrate'; w.id = 'celebrate';
  const red = document.documentElement.dataset.motion === 'reduce' || matchMedia('(prefers-reduced-motion: reduce)').matches;
  let cf = ''; if (!red) for (let i = 0; i < 46; i++) cf += `<i class="cf" style="left:${Math.random() * 100}%;background:${CF_COL[i % 7]};--dx:${(Math.random() - .5) * 160}px;--rot:${Math.round(Math.random() * 720 - 360)}deg;animation-duration:${1.6 + Math.random() * 1.8}s;animation-delay:${Math.random() * .4}s"></i>`;
  w.innerHTML = `${cf}<div class="cb-card"><span class="cb-e">${e}</span><b class="cb-t">${t}</b><span class="cb-s">${sub}</span><div class="row" style="justify-content:center;gap:8px">${btn || ''}<button class="btn primary" data-cb-close>দারুণ!</button></div></div>`;
  w.addEventListener('click', ev => { if (ev.target === w || ev.target.closest('[data-cb-close]') || ev.target.closest('[data-act]')) w.remove(); });
  document.body.appendChild(w);
  try { navigator.vibrate && navigator.vibrate([30, 40, 30]); } catch (er) { }
}
/* মাইলফলক: লেভেল-আপ, নতুন ব্যাজ, থিম আনলক — প্রথমবার চালু হলে আগের অর্জনগুলো চুপচাপ নথিভুক্ত হয় */
let msT = null, msQ = [];
function msState() { return S.ms || (S.ms = { L: 0, B: {} }); }
function msInit() { const m = msState(); if (!m.init) { m.L = xpInfo().L; badges().forEach(b => { if (b[3] >= b[4]) m.B[b[1]] = 1; }); m.init = 1; save({ cloud: false }); } }
function msSoon() { clearTimeout(msT); msT = setTimeout(msCheck, 700); }
function msCheck() {
  const m = msState(); if (!m.init) return msInit(); let ch = false;
  const x = xpInfo();
  if (x.L > m.L) { const unl = []; /* সব থিম খোলা */ m.L = x.L; ch = true; msQ.push(['🚀', `লেভেল ${bn(x.L)} · ${x.name}!`, `অভিনন্দন! মোট ${bn(x.xp)} XP অর্জিত।${unl.length ? ` 🎨 নতুন থিম খুলেছে: ${unl.join(', ')}` : ''}`, unl.length ? '<button class="btn" data-act="themeSheet">থিম দেখো</button>' : '']); }
  badges().forEach(b => { if (b[3] >= b[4] && !m.B[b[1]]) { m.B[b[1]] = 1; ch = true; msQ.push([b[0], `নতুন ব্যাজ: ${b[1]}`, b[2], '<button class="btn" data-act="go" data-v="badges">সব ব্যাজ</button>']); } });
  if (ch) save({ cloud: false });
  msNext();
}
function msNext() { if ($('#celebrate') || !msQ.length) return; const [e, t, s2, b] = msQ.shift(); celebrate(e, t, s2, b); const w = $('#celebrate'); if (w) new MutationObserver((r, o) => { if (!document.body.contains(w)) { o.disconnect(); setTimeout(msNext, 300); } }).observe(document.body, { childList: true }); }
/* স্ট্রিক রক্ষাকবচ: টানা ৭ দিনে একটি (সর্বোচ্চ ২); একদিন বাদ গেলে নিজে থেকেই ধারা রক্ষা করে */
function frzCheck() {
  const F = S.frz || (S.frz = { n: 0, used: {}, earned: {} }); F.used = F.used || {}; F.earned = F.earned || {};
  const day = i => { const d = new Date(); d.setDate(d.getDate() - i); return dkey(d); };
  const act = k => activeDay(S.days[k]) || !!F.used[k];
  const y = day(1);
  if (!act(y) && F.n > 0 && act(day(2))) { F.used[y] = 1; F.n--; save(); setTimeout(() => celebrate('🧊', 'রক্ষাকবচ তোমার ধারা বাঁচিয়েছে!', `গতকাল পড়া হয়নি, তবু ${bn(streak())} দিনের ধারা অটুট। আজ অন্তত একটি পাঠ পড়ো।`), 900); }
  const sk = streak(), t = day(0);
  if (sk > 0 && sk % 7 === 0 && activeDay(S.days[t]) && !F.earned[t] && F.n < 2) { F.earned[t] = 1; F.n++; save(); celebrate('🧊', 'নতুন স্ট্রিক রক্ষাকবচ!', `টানা ${bn(sk)} দিন পড়ার পুরস্কার। কোনো দিন পড়া বাদ গেলে এটি তোমার ধারা রক্ষা করবে (এখন আছে ${bn(F.n)}টি)।`); }
}
const _touch0 = touch;
touch = function (kind, sid, n, c) { _touch0(kind, sid, n, c); try { frzCheck(); } catch (e) { } };
ACT.frzInfo = () => { const F = S.frz || {}; openSheet(`<div class="stack" style="gap:10px"><h2 class="h-card">🧊 স্ট্রিক রক্ষাকবচ</h2><p style="margin:0">টানা <b>৭ দিন</b> পড়লে একটি রক্ষাকবচ পাবে (সর্বোচ্চ ২টি জমা রাখা যায়)। কোনো দিন একেবারে পড়া না হলে পরদিন অ্যাপ খুললেই একটি রক্ষাকবচ নিজে থেকে খরচ হয়ে তোমার ধারা অটুট রাখবে।</p><div class="stat-strip"><div class="mini"><b>${bn(F.n || 0)}/২</b><span>জমা আছে</span></div><div class="mini">${ico('fire', 'muted')}<b>${bn(streak())}</b><span>বর্তমান ধারা</span></div><div class="mini"><b>${bn(Object.keys(F.used || {}).length)}</b><span>এ পর্যন্ত ব্যবহৃত</span></div></div><p class="small muted" style="margin:0">একটি দিন "সক্রিয়" ধরা হয় যদি অন্তত ১টি পাঠ সম্পন্ন হয়, বা ৩টি প্রশ্নের উত্তর দাও, বা ৫ মিনিট পড়ো।</p><button class="btn" data-act="closeSheet">ঠিক আছে</button></div>`); };
if (!ACT.closeSheet) ACT.closeSheet = () => closeSheet();
/* আজকের মজার তথ্য — প্রতিদিন নতুন, যেকোনো অধ্যায়ের পাঠ থেকে */
let factOff = 0;
function factPick() { const pool = []; LESSONS.forEach(l => (l.mf || []).forEach(f => pool.push([l, f]))); if (!pool.length) return null; const d = new Date(), seed = d.getFullYear() * 400 + d.getMonth() * 31 + d.getDate(); return pool[(seed * 7919 + factOff * 104729) % pool.length]; }
HS.fact = () => { const p = factPick(); if (!p) return ''; const [l, f] = p; return `<div class="card fact-card"><span class="fe">💡</span><span style="flex:1;min-width:0"><b>আজকের মজার তথ্য</b><p>${f}</p><span class="row" style="gap:6px;flex-wrap:wrap"><button class="btn sm" data-act="lesson" data-id="${l.id}">${ico('book')}${short(l.t, 34)}</button><button class="btn sm" data-act="factNext">আরেকটি ›</button></span></span></div>`; };
ACT.factNext = () => { factOff++; render(true); };
/* কুইজে টানা সঠিকের কম্বো */
let comboN = 0;
function comboHit(ok) { comboN = ok ? comboN + 1 : 0; if ([3, 5, 10, 15, 20].includes(comboN)) { const el = document.createElement('div'); el.className = 'combo-pop'; el.textContent = `🔥 টানা ${bn(comboN)}টি সঠিক!`; document.body.appendChild(el); setTimeout(() => el.remove(), 1400); } }
