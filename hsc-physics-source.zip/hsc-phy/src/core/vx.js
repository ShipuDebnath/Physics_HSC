/* ═══════════════════════════════════════════════════════════════════
   CORE · VX — ভিজ্যুয়াল টুলকিট (সব অধ্যায়ের চিত্র/সিমুলেশনে ব্যবহারযোগ্য)
   window.VIS = চিত্রের রেজিস্ট্রি  (VIS.key = { t, k, cap, html(), mount(el) })
   window.VX  = সহায়ক ফাংশন: svg, cv, fit, anim, seg, onSeg, rng, sci, bn,
                 arrow, drag, এবং পরমাণু/ইলেকট্রন বিন্যাসের হেল্পার (EL, occ, cfg …)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
'use strict';
const V = window.VIS = window.VIS || {};
const X = window.VX = window.VX || {};
const BND = '০১২৩৪৫৬৭৮৯';
X.bn = s => String(s).replace(/\d/g, d => BND[d]);
X.C = () => { const s = getComputedStyle(document.documentElement); const g = n => s.getPropertyValue(n).trim(); return { fg: g('--fg'), mu: g('--muted'), ln: g('--line-strong'), line: g('--line'), acc: g('--accent'), a2: g('--accent-2'), sf: g('--surface'), s2: g('--surface-2'), s3: g('--surface-3'), bg: g('--bg'), ok: g('--ok'), bad: g('--bad'), font: g('--font-body') || 'sans-serif', mono: g('--font-mono') || 'monospace', spec: g('--spec-bg') }; };
X.rm = () => { const m = document.documentElement.dataset.motion; return m === 'reduce' || (m !== 'full' && matchMedia('(prefers-reduced-motion: reduce)').matches); };
X.ico = (n) => (window.ico ? window.ico(n) : '');
X.cv = (label, h) => `<div class="cv"><canvas role="img" aria-label="${label}" style="width:100%;${h ? 'height:' + h + 'px' : ''}"></canvas></div>`;
X.fit = (c, hf) => {
  const W = Math.max(260, Math.floor(c.parentElement.getBoundingClientRect().width));
  const H = Math.round(hf(W)); const d = Math.min(2, window.devicePixelRatio || 1);
  c.width = Math.round(W * d); c.height = Math.round(H * d); c.style.height = H + 'px';
  const g = c.getContext('2d'); g.setTransform(d, 0, 0, d, 0, 0); return { W, H, g };
};
X.anim = (el, step, opt = {}) => {
  let raf = 0, vis = false, last = 0, alive = true, paused = opt.paused != null ? opt.paused : X.rm();
  const tick = t => { raf = 0; if (!alive) return; const dt = last ? Math.min(0.05, (t - last) / 1000) : 0.016; last = t; step(paused ? 0 : dt, t); if (vis && !paused && document.visibilityState === 'visible') raf = requestAnimationFrame(tick); else last = 0; };
  const kick = () => { if (alive && !raf) raf = requestAnimationFrame(tick); };
  const io = new IntersectionObserver(es => { vis = es[es.length - 1].isIntersecting; if (vis) kick(); }, { threshold: 0.01 });
  io.observe(el);
  const vh = () => { if (document.visibilityState === 'visible') kick(); };
  document.addEventListener('visibilitychange', vh);
  return { stop() { alive = false; cancelAnimationFrame(raf); io.disconnect(); document.removeEventListener('visibilitychange', vh); }, pause(p) { paused = p; last = 0; kick(); }, get paused() { return paused; }, draw: kick };
};
X.pp = (root, A) => { const b = root.querySelector('[data-pp]'); if (!b) return; const upd = () => { b.innerHTML = A.paused ? X.ico('play') + 'চালাও' : X.ico('pause') + 'থামাও'; }; b.onclick = () => { A.pause(!A.paused); upd(); }; upd(); };
X.onResize = (el, fn) => { let w = el.getBoundingClientRect().width; const ro = new ResizeObserver(() => { const nw = el.getBoundingClientRect().width; if (Math.abs(nw - w) > 2) { w = nw; fn(); } }); ro.observe(el); return () => ro.disconnect(); };
X.sup = n => String(n).replace(/[-0-9+]/g, c => ({ '-': '⁻', '+': '⁺' }[c] || '⁰¹²³⁴⁵⁶⁷⁸⁹'[+c]));
X.sub = n => String(n).replace(/[0-9]/g, c => '₀₁₂₃₄₅₆₇₈₉'[+c]);
X.sci = (x, d = 3) => {
  if (x === 0) return '0'; if (!isFinite(x)) return '∞';
  const e = Math.floor(Math.log10(Math.abs(x)));
  if (e >= -3 && e <= 5) return String(+x.toPrecision(d));
  let m = x / Math.pow(10, e); let mm = m.toFixed(d - 1);
  if (Math.abs(+mm) >= 10) { mm = (m / 10).toFixed(d - 1); return mm + '×10' + X.sup(e + 1); }
  return mm + '×10' + X.sup(e);
};
X.wl = function (w) {
  let r = 0, g = 0, b = 0;
  if (w >= 380 && w < 440) { r = -(w - 440) / 60; b = 1; } else if (w >= 440 && w < 490) { g = (w - 440) / 50; b = 1; }
  else if (w >= 490 && w < 510) { g = 1; b = -(w - 510) / 20; } else if (w >= 510 && w < 580) { r = (w - 510) / 70; g = 1; }
  else if (w >= 580 && w < 645) { r = 1; g = -(w - 645) / 65; } else if (w >= 645 && w <= 780) { r = 1; }
  let f = 0; if (w >= 380 && w < 420) f = 0.3 + 0.7 * (w - 380) / 40; else if (w >= 420 && w <= 700) f = 1; else if (w > 700 && w <= 780) f = 0.3 + 0.7 * (780 - w) / 80;
  const c = x => Math.round(255 * Math.pow(Math.max(0, x * f), 0.8));
  return `rgb(${c(r)},${c(g)},${c(b)})`;
};
X.seg = (name, items, on) => `<div class="seg" data-seg="${name}">${items.map(([k, n]) => `<button type="button" data-k="${k}" class="${String(k) === String(on) ? 'on' : ''}">${n}</button>`).join('')}</div>`;
X.onSeg = (root, name, fn) => { const s = root.querySelector(`[data-seg="${name}"]`); if (!s) return; s.addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; s.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); fn(b.dataset.k); }); };
X.svg = (w, h, inner, label, style = '') => `<svg class="dg" viewBox="0 0 ${w} ${h}" role="img" aria-label="${label || ''}" style="max-width:${Math.min(640, w * 1.5)}px;margin:0 auto;${style}">${inner}</svg>`;
X.arrow = id => `<marker id="${id}" viewBox="0 0 10 10" refX="8.5" refY="5" markerWidth="6.5" markerHeight="6.5" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" class="f-fg"/></marker>`;
X.arrowC = (id, color) => `<marker id="${id}" viewBox="0 0 10 10" refX="8.5" refY="5" markerWidth="6.5" markerHeight="6.5" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="${color}"/></marker>`;
X.rng = seed => () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
X.drag = (c, onMove) => {
  let down = false, lx = 0, ly = 0;
  c.addEventListener('pointerdown', e => { down = true; lx = e.clientX; ly = e.clientY; try { c.setPointerCapture(e.pointerId); } catch (_) { } });
  c.addEventListener('pointermove', e => { if (!down) return; onMove(e.clientX - lx, e.clientY - ly); lx = e.clientX; ly = e.clientY; });
  const up = () => { down = false; }; c.addEventListener('pointerup', up); c.addEventListener('pointercancel', up);
  return () => down;
};

/* ---------- element data (Z 1–30) ---------- */
X.EL = [
  ['H', 'হাইড্রোজেন', 1, 1.008], ['He', 'হিলিয়াম', 4, 4.003], ['Li', 'লিথিয়াম', 7, 6.94], ['Be', 'বেরিলিয়াম', 9, 9.012], ['B', 'বোরন', 11, 10.81],
  ['C', 'কার্বন', 12, 12.011], ['N', 'নাইট্রোজেন', 14, 14.007], ['O', 'অক্সিজেন', 16, 15.999], ['F', 'ফ্লোরিন', 19, 18.998], ['Ne', 'নিয়ন', 20, 20.180],
  ['Na', 'সোডিয়াম', 23, 22.990], ['Mg', 'ম্যাগনেসিয়াম', 24, 24.305], ['Al', 'অ্যালুমিনিয়াম', 27, 26.982], ['Si', 'সিলিকন', 28, 28.085], ['P', 'ফসফরাস', 31, 30.974],
  ['S', 'সালফার', 32, 32.06], ['Cl', 'ক্লোরিন', 35, 35.45], ['Ar', 'আর্গন', 40, 39.948], ['K', 'পটাশিয়াম', 39, 39.098], ['Ca', 'ক্যালসিয়াম', 40, 40.078],
  ['Sc', 'স্ক্যান্ডিয়াম', 45, 44.956], ['Ti', 'টাইটেনিয়াম', 48, 47.867], ['V', 'ভ্যানাডিয়াম', 51, 50.942], ['Cr', 'ক্রোমিয়াম', 52, 51.996], ['Mn', 'ম্যাঙ্গানিজ', 55, 54.938],
  ['Fe', 'আয়রন (লোহা)', 56, 55.845], ['Co', 'কোবাল্ট', 59, 58.933], ['Ni', 'নিকেল', 58, 58.693], ['Cu', 'কপার (তামা)', 63, 63.546], ['Zn', 'জিংক (দস্তা)', 64, 65.38]
];
X.ORDER = [['1s', 2], ['2s', 2], ['2p', 6], ['3s', 2], ['3p', 6], ['4s', 2], ['3d', 10], ['4p', 6]];
X.occ = (Z, exc = true) => {
  const o = {}; let left = Z;
  for (const [s, c] of X.ORDER) { if (left <= 0) break; const k = Math.min(c, left); o[s] = k; left -= k; }
  if (exc && Z === 24) { o['4s'] = 1; o['3d'] = 5; }
  if (exc && Z === 29) { o['4s'] = 1; o['3d'] = 10; }
  return o;
};
X.cfg = (Z, mode = 'n', exc = true) => {
  const o = X.occ(Z, exc);
  const keys = mode === 'n' ? ['1s', '2s', '2p', '3s', '3p', '3d', '4s', '4p'] : X.ORDER.map(x => x[0]);
  return keys.filter(k => o[k]).map(k => k + X.sup(o[k])).join(' ');
};
X.core = Z => {
  const cores = [[18, 'Ar'], [10, 'Ne'], [2, 'He']];
  for (const [n, s] of cores) { if (Z > n) { const full = X.cfg(Z, 'n').split(' '); const coreLen = X.cfg(n, 'n').split(' ').length; return '[' + s + '] ' + full.slice(coreLen).join(' '); } }
  return X.cfg(Z, 'n');
};
X.shells = Z => { const o = X.occ(Z); const sh = [0, 0, 0, 0]; for (const k in o) sh[+k[0] - 1] += o[k]; while (sh.length && !sh[sh.length - 1]) sh.pop(); return sh; };
X.unpaired = Z => { const o = X.occ(Z); let u = 0; for (const k in o) { const orbs = { s: 1, p: 3, d: 5 }[k[1]]; const e = o[k]; u += e <= orbs ? e : 2 * orbs - e; } return u; };
/* ---------- full periodic table (Z 1–118) — used from chapter 3 on ---------- */
X.PT = ('H হাইড্রোজেন 1.008|He হিলিয়াম 4.003|Li লিথিয়াম 6.94|Be বেরিলিয়াম 9.012|B বোরন 10.81|C কার্বন 12.01|N নাইট্রোজেন 14.01|O অক্সিজেন 16.00|F ফ্লোরিন 19.00|Ne নিয়ন 20.18|' +
  'Na সোডিয়াম 22.99|Mg ম্যাগনেসিয়াম 24.31|Al অ্যালুমিনিয়াম 26.98|Si সিলিকন 28.09|P ফসফরাস 30.97|S সালফার 32.06|Cl ক্লোরিন 35.45|Ar আর্গন 39.95|K পটাশিয়াম 39.10|Ca ক্যালসিয়াম 40.08|' +
  'Sc স্ক্যান্ডিয়াম 44.96|Ti টাইটেনিয়াম 47.87|V ভ্যানাডিয়াম 50.94|Cr ক্রোমিয়াম 52.00|Mn ম্যাঙ্গানিজ 54.94|Fe আয়রন 55.85|Co কোবাল্ট 58.93|Ni নিকেল 58.69|Cu কপার 63.55|Zn জিংক 65.38|' +
  'Ga গ্যালিয়াম 69.72|Ge জার্মেনিয়াম 72.63|As আর্সেনিক 74.92|Se সেলেনিয়াম 78.97|Br ব্রোমিন 79.90|Kr ক্রিপ্টন 83.80|Rb রুবিডিয়াম 85.47|Sr স্ট্রনশিয়াম 87.62|Y ইট্রিয়াম 88.91|Zr জিরকোনিয়াম 91.22|' +
  'Nb নাইওবিয়াম 92.91|Mo মলিবডেনাম 95.95|Tc টেকনিশিয়াম (98)|Ru রুথেনিয়াম 101.07|Rh রোডিয়াম 102.91|Pd প্যালাডিয়াম 106.42|Ag সিলভার 107.87|Cd ক্যাডমিয়াম 112.41|In ইন্ডিয়াম 114.82|Sn টিন 118.71|' +
  'Sb অ্যান্টিমনি 121.76|Te টেলুরিয়াম 127.60|I আয়োডিন 126.90|Xe জেনন 131.29|Cs সিজিয়াম 132.91|Ba বেরিয়াম 137.33|La ল্যান্থানাম 138.91|Ce সিরিয়াম 140.12|Pr প্রাসিওডিমিয়াম 140.91|Nd নিওডিমিয়াম 144.24|' +
  'Pm প্রমিথিয়াম (145)|Sm সামারিয়াম 150.36|Eu ইউরোপিয়াম 151.96|Gd গ্যাডোলিনিয়াম 157.25|Tb টার্বিয়াম 158.93|Dy ডিসপ্রোসিয়াম 162.50|Ho হলমিয়াম 164.93|Er আরবিয়াম 167.26|Tm থুলিয়াম 168.93|Yb ইটারবিয়াম 173.05|' +
  'Lu লুটেশিয়াম 174.97|Hf হ্যাফনিয়াম 178.49|Ta ট্যানটালাম 180.95|W টাংস্টেন 183.84|Re রেনিয়াম 186.21|Os অসমিয়াম 190.23|Ir ইরিডিয়াম 192.22|Pt প্লাটিনাম 195.08|Au গোল্ড 196.97|Hg মার্কারি 200.59|' +
  'Tl থ্যালিয়াম 204.38|Pb লেড 207.2|Bi বিসমাথ 208.98|Po পোলোনিয়াম (209)|At অ্যাস্টাটিন (210)|Rn রেডন (222)|Fr ফ্রান্সিয়াম (223)|Ra রেডিয়াম (226)|Ac অ্যাক্টিনিয়াম (227)|Th থোরিয়াম 232.04|' +
  'Pa প্রোট্যাকটিনিয়াম 231.04|U ইউরেনিয়াম 238.03|Np নেপচুনিয়াম (237)|Pu প্লুটোনিয়াম (244)|Am অ্যামেরিসিয়াম (243)|Cm কুরিয়াম (247)|Bk বার্কেলিয়াম (247)|Cf ক্যালিফোর্নিয়াম (251)|Es আইনস্টাইনিয়াম (252)|Fm ফার্মিয়াম (257)|' +
  'Md মেন্ডেলেভিয়াম (258)|No নোবেলিয়াম (259)|Lr লরেনসিয়াম (266)|Rf রাদারফোর্ডিয়াম (267)|Db ডুবনিয়াম (268)|Sg সিবোর্গিয়াম (269)|Bh বোরিয়াম (270)|Hs হ্যাসিয়াম (277)|Mt মাইটনেরিয়াম (278)|Ds ডার্মস্টাডটিয়াম (281)|' +
  'Rg রন্টজেনিয়াম (282)|Cn কোপারনিসিয়াম (285)|Nh নিহোনিয়াম (286)|Fl ফ্লেরোভিয়াম (289)|Mc মস্কোভিয়াম (290)|Lv লিভারমোরিয়াম (293)|Ts টেনেসিন (294)|Og ওগানেসন (294)').split('|').map((r, i) => {
  const [sym, name, mass] = r.split(' '); const Z = i + 1;
  const per = Z <= 2 ? 1 : Z <= 10 ? 2 : Z <= 18 ? 3 : Z <= 36 ? 4 : Z <= 54 ? 5 : Z <= 86 ? 6 : 7;
  let g = null, f = false;
  if (per === 1) g = Z === 1 ? 1 : 18;
  else if (per <= 3) { const k = Z - (per === 2 ? 2 : 10); g = k <= 2 ? k : k + 10; }
  else if (per <= 5) g = Z - (per === 4 ? 18 : 36);
  else { const k = Z - (per === 6 ? 54 : 86); if (k <= 3) g = k; else if (k <= 17) f = true; else g = k - 14; }
  const block = f ? 'f' : (g <= 2 || Z === 2) ? 's' : g >= 13 ? 'p' : 'd';
  const MTL = [5, 14, 32, 33, 51, 52], NM = [1, 6, 7, 8, 15, 16, 34];
  const cat = f ? (per === 6 ? 'lan' : 'act') : g === 18 ? 'noble' : g === 17 ? 'hal' : MTL.includes(Z) ? 'mtl' : NM.includes(Z) ? 'nm' : g === 1 ? 'alk' : g === 2 ? 'ae' : g === 12 ? 'zn' : block === 'd' ? 'tr' : 'post';
  return { Z, sym, name, mass, per, g, block, cat };
});
X.PTCAT = { alk: ['ক্ষার ধাতু', '#E8775C'], ae: ['মৃৎক্ষার ধাতু', '#E9A53B'], tr: ['অবস্থান্তর ধাতু', '#C9A25C'], zn: ['১২ নং গ্রুপ (d-ব্লক)', '#B9B07A'], post: ['অন্যান্য ধাতু', '#8AA0B3'], mtl: ['ধাতুকল্প', '#5FB09A'], nm: ['অধাতু', '#6FA8DC'], hal: ['হ্যালোজেন', '#4FB6C9'], noble: ['নিষ্ক্রিয় গ্যাস', '#A88BD8'], lan: ['ল্যান্থানাইড', '#D78DB8'], act: ['অ্যাক্টিনাইড', '#C77FA0'] };
X.PTBLK = { s: '#E8775C', p: '#5B9BD5', d: '#E3B04B', f: '#B784C7' };
/* properties for Z 1–56 (null = not defined/not comparable). IE₁ kJ mol⁻¹; Pauling EN; EA kJ mol⁻¹ (energy released);
   radius pm (metallic radius for metals, covalent radius for non-metals — the usual textbook set) */
X.IE1 = [1312, 2372, 520, 899, 801, 1086, 1402, 1314, 1681, 2081, 496, 738, 578, 787, 1012, 1000, 1251, 1521, 419, 590, 633, 659, 651, 653, 717, 763, 760, 737, 746, 906, 579, 762, 947, 941, 1140, 1351, 403, 550, 600, 640, 652, 684, 702, 710, 720, 804, 731, 868, 558, 709, 834, 869, 1008, 1170, 376, 503];
X.EN = [2.20, null, 0.98, 1.57, 2.04, 2.55, 3.04, 3.44, 3.98, null, 0.93, 1.31, 1.61, 1.90, 2.19, 2.58, 3.16, null, 0.82, 1.00, 1.36, 1.54, 1.63, 1.66, 1.55, 1.83, 1.88, 1.91, 1.90, 1.65, 1.81, 2.01, 2.18, 2.55, 2.96, 3.00, 0.82, 0.95, 1.22, 1.33, 1.6, 2.16, 1.9, 2.2, 2.28, 2.20, 1.93, 1.69, 1.78, 1.96, 2.05, 2.1, 2.66, 2.6, 0.79, 0.89];
X.EA = [73, 0, 60, 0, 27, 122, 0, 141, 328, 0, 53, 0, 42, 134, 72, 200, 349, 0, 48, 2, 18, 8, 51, 65, 0, 15, 64, 112, 119, 0, 41, 119, 78, 195, 325, 0, 47, 5, 30, 41, 86, 72, 53, 101, 110, 54, 126, 0, 37, 107, 101, 190, 295, 0, 46, 14];
X.RAD = [37, null, 152, 112, 88, 77, 74, 73, 72, null, 186, 160, 143, 117, 110, 104, 99, null, 227, 197, 162, 147, 134, 128, 127, 126, 125, 124, 128, 134, 135, 122, 121, 117, 114, null, 248, 215, 180, 160, 146, 139, 136, 134, 134, 137, 144, 151, 167, 140, 141, 137, 133, null, 265, 222];
/* subshell filling (Madelung order) with the common exceptions */
X.SUBS = ['1s', '2s', '2p', '3s', '3p', '4s', '3d', '4p', '5s', '4d', '5p', '6s', '4f', '5d', '6p', '7s', '5f', '6d', '7p'];
X.EXC = { 24: { '4s': 1, '3d': 5 }, 29: { '4s': 1, '3d': 10 }, 41: { '5s': 1, '4d': 4 }, 42: { '5s': 1, '4d': 5 }, 44: { '5s': 1, '4d': 7 }, 45: { '5s': 1, '4d': 8 }, 46: { '5s': 0, '4d': 10 }, 47: { '5s': 1, '4d': 10 },
  57: { '4f': 0, '5d': 1 }, 58: { '4f': 1, '5d': 1 }, 64: { '4f': 7, '5d': 1 }, 78: { '6s': 1, '5d': 9 }, 79: { '6s': 1, '5d': 10 }, 89: { '5f': 0, '6d': 1 }, 90: { '5f': 0, '6d': 2 }, 91: { '5f': 2, '6d': 1 }, 92: { '5f': 3, '6d': 1 }, 93: { '5f': 4, '6d': 1 }, 96: { '5f': 7, '6d': 1 }, 103: { '6d': 0, '7p': 1 } };
X.occZ = (Z, exc = true) => {
  const cap = { s: 2, p: 6, d: 10, f: 14 }, o = {}; let left = Z;
  for (const s of X.SUBS) { if (left <= 0) break; const k = Math.min(cap[s[1]], left); o[s] = k; left -= k; }
  if (exc && X.EXC[Z]) Object.assign(o, X.EXC[Z]);
  for (const k in o) if (!o[k]) delete o[k];
  return o;
};
X.cfgZ = (Z, short = true, exc = true) => {
  const o = X.occZ(Z, exc), ord = Object.keys(o).sort((a, b) => (+a[0] - +b[0]) || ('spdf'.indexOf(a[1]) - 'spdf'.indexOf(b[1])));
  if (!short) return ord.map(k => k + X.sup(o[k])).join(' ');
  const cores = [[86, 'Rn'], [54, 'Xe'], [36, 'Kr'], [18, 'Ar'], [10, 'Ne'], [2, 'He']];
  for (const [n, s] of cores) if (Z > n) { const co = X.occZ(n, false); const rest = ord.filter(k => !co[k] || co[k] !== o[k]); return '[' + s + '] ' + rest.map(k => k + X.sup(o[k])).join(' '); }
  return ord.map(k => k + X.sup(o[k])).join(' ');
};
})();
